System.register(['vue', '@Obsidian/Controls/rockFormField', '@Obsidian/Utility/component', '@Obsidian/ValidationRules'], (function (exports) {
  'use strict';
  var defineComponent, ref, reactive, computed, nextTick, watch, openBlock, createBlock, unref, isRef, withCtx, createElementVNode, normalizeClass, createElementBlock, Fragment, renderList, withDirectives, vModelText, RockFormField, useVModelPassthrough, rulesPropType, normalizeRules;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      reactive = module.reactive;
      computed = module.computed;
      nextTick = module.nextTick;
      watch = module.watch;
      openBlock = module.openBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      isRef = module.isRef;
      withCtx = module.withCtx;
      createElementVNode = module.createElementVNode;
      normalizeClass = module.normalizeClass;
      createElementBlock = module.createElementBlock;
      Fragment = module.Fragment;
      renderList = module.renderList;
      withDirectives = module.withDirectives;
      vModelText = module.vModelText;
    }, function (module) {
      RockFormField = module["default"];
    }, function (module) {
      useVModelPassthrough = module.useVModelPassthrough;
    }, function (module) {
      rulesPropType = module.rulesPropType;
      normalizeRules = module.normalizeRules;
    }],
    execute: (function () {

      function _unsupportedIterableToArray(o, minLen) {
        if (!o) return;
        if (typeof o === "string") return _arrayLikeToArray(o, minLen);
        var n = Object.prototype.toString.call(o).slice(8, -1);
        if (n === "Object" && o.constructor) n = o.constructor.name;
        if (n === "Map" || n === "Set") return Array.from(o);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
      }
      function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length) len = arr.length;
        for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
        return arr2;
      }
      function _createForOfIteratorHelper(o, allowArrayLike) {
        var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
        if (!it) {
          if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
            if (it) o = it;
            var i = 0;
            var F = function () {};
            return {
              s: F,
              n: function () {
                if (i >= o.length) return {
                  done: true
                };
                return {
                  done: false,
                  value: o[i++]
                };
              },
              e: function (e) {
                throw e;
              },
              f: F
            };
          }
          throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        var normalCompletion = true,
          didErr = false,
          err;
        return {
          s: function () {
            it = it.call(o);
          },
          n: function () {
            var step = it.next();
            normalCompletion = step.done;
            return step;
          },
          e: function (e) {
            didErr = true;
            err = e;
          },
          f: function () {
            try {
              if (!normalCompletion && it.return != null) it.return();
            } finally {
              if (didErr) throw err;
            }
          }
        };
      }

      var _hoisted_1 = {
        class: "control-wrapper"
      };
      var _hoisted_2 = ["onUpdate:modelValue", "autofocus", "disabled", "id", "maxlength", "onInput", "onFocus"];
      var script = exports('default', defineComponent({
        name: 'codeBox',
        props: {
          modelValue: {
            type: String,
            required: false,
            default: null
          },
          allowedChars: {
            type: Object,
            required: false,
            default: /^[a-zA-Z0-9]$/
          },
          disabled: {
            type: Boolean,
            required: false,
            default: false
          },
          maxLength: {
            type: Number,
            required: true
          },
          modelModifiers: {
            type: Object,
            required: false,
            default: null
          },
          rules: rulesPropType,
          updateOnComplete: {
            type: Boolean,
            required: false,
            default: false
          }
        },
        emits: ["update:modelValue", "complete"],
        setup(__props, _ref) {
          var emit = _ref.emit;
          var props = __props;
          var internalModelValue = useVModelPassthrough(props, "modelValue", emit);
          var codeContainer = ref(undefined);
          var characters = reactive([]);
          setCharactersFromModelValue();
          var internalRules = computed(() => normalizeRules(props.rules));
          var isRequired = computed(() => internalRules.value.includes("required"));
          function _onInput(event, index) {
            if (!isInputEvent(event)) {
              return;
            }
            var input = getCodeInputAt(index);
            if (!input || input !== event.target) {
              return;
            }
            var modifiedString = applyModifications(input.value);
            var modifiedCharacters = modifiedString.split("");
            var lastFilledIndex = -1;
            for (var i = 0; i < modifiedCharacters.length; i++) {
              if (index + i < props.maxLength) {
                lastFilledIndex = index + i;
                characters[lastFilledIndex] = modifiedCharacters[i];
              }
            }
            tryEmitCode();
            nextTick(() => {
              if (lastFilledIndex !== -1) {
                var nextInput = lastFilledIndex < props.maxLength - 2 ? getCodeInputAt(lastFilledIndex + 1) : getCodeInputAt(lastFilledIndex);
                if (nextInput) {
                  nextInput.focus();
                }
              } else if (event.inputType === "deleteContentBackward") {
                var prevInput = index === 0 ? getCodeInputAt(index) : getCodeInputAt(index - 1);
                if (prevInput) {
                  prevInput.focus();
                }
              }
            });
          }
          function _onFocus(index) {
            var input = getCodeInputAt(index);
            if (input) {
              input.select();
            }
          }
          function applyModifications(codeCharacter) {
            var _props$modelModifiers;
            if (codeCharacter && (_props$modelModifiers = props.modelModifiers) !== null && _props$modelModifiers !== void 0 && _props$modelModifiers.capitalize) {
              return codeCharacter.toUpperCase();
            }
            return codeCharacter;
          }
          function getCodeInputAt(index) {
            return codeContainer.value.children[index];
          }
          function isCodeComplete() {
            var _iterator = _createForOfIteratorHelper(characters),
              _step;
            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var character = _step.value;
                if (character == null || character == undefined) {
                  return false;
                }
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }
            return true;
          }
          function isInputEvent(event) {
            return !!event && typeof event === "object" && "inputType" in event;
          }
          function setCharactersFromModelValue() {
            if (!characters.length || props.modelValue != characters.join("")) {
              if (props.modelValue) {
                for (var index = 0; index < props.maxLength; index++) {
                  characters[index] = applyModifications(props.modelValue.charAt(index));
                }
                var newModelValue = characters.join("");
                if (props.modelValue != newModelValue) {
                  nextTick(() => {
                    tryEmitCode();
                  });
                }
              } else {
                for (var _index = 0; _index < props.maxLength; _index++) {
                  characters[_index] = null;
                }
              }
            }
          }
          function tryEmitCode() {
            var isComplete = isCodeComplete();
            if (!props.updateOnComplete || isComplete) {
              var code = characters.join("");
              emit("update:modelValue", code);
              if (isComplete) {
                emit("complete", code);
              }
              return true;
            }
            return false;
          }
          watch(() => props.modelValue, () => {
            setCharactersFromModelValue();
          });
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(RockFormField), {
              modelValue: unref(internalModelValue),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(internalModelValue) ? internalModelValue.value = $event : null),
              name: "codebox",
              rules: __props.rules
            }, {
              default: withCtx(_ref2 => {
                var uniqueId = _ref2.uniqueId;
                  _ref2.field;
                return [createElementVNode("div", {
                  class: normalizeClass(['form-group rock-code-box', unref(isRequired) ? 'required' : ''])
                }, [createElementVNode("div", _hoisted_1, [createElementVNode("div", {
                  class: "d-flex",
                  ref_key: "codeContainer",
                  ref: codeContainer
                }, [(openBlock(true), createElementBlock(Fragment, null, renderList(characters, (character, index) => {
                  return withDirectives((openBlock(), createElementBlock("input", {
                    "onUpdate:modelValue": $event => characters[index] = $event,
                    autocomplete: "one-time-code",
                    autofocus: index === 0,
                    class: normalizeClass("form-control flex-grow-1 flex-sm-grow-0 flex-shrink-1 ".concat(index > 0 ? 'ml-1' : '')),
                    disabled: __props.disabled,
                    id: "".concat(uniqueId, "-").concat(index),
                    key: index,
                    maxlength: __props.maxLength,
                    type: "text",
                    onInput: $event => _onInput($event, index),
                    onFocus: $event => _onFocus(index)
                  }, null, 42, _hoisted_2)), [[vModelText, characters[index]]]);
                }), 128))], 512)])], 2)];
              }),
              _: 1
            }, 8, ["modelValue", "rules"]);
          };
        }
      }));

      function styleInject(css, ref) {
        if (ref === void 0) ref = {};
        var insertAt = ref.insertAt;
        if (!css || typeof document === 'undefined') {
          return;
        }
        var head = document.head || document.getElementsByTagName('head')[0];
        var style = document.createElement('style');
        style.type = 'text/css';
        if (insertAt === 'top') {
          if (head.firstChild) {
            head.insertBefore(style, head.firstChild);
          } else {
            head.appendChild(style);
          }
        } else {
          head.appendChild(style);
        }
        if (style.styleSheet) {
          style.styleSheet.cssText = css;
        } else {
          style.appendChild(document.createTextNode(css));
        }
      }

      var css_248z = ".rock-code-box input[data-v-388368c2]{font-size:24px;height:64px;text-align:center;width:47px}";
      styleInject(css_248z);

      script.__scopeId = "data-v-388368c2";
      script.__file = "src/Security/codeBox.obs";

    })
  };
}));
//# sourceMappingURL=codeBox.obs.js.map
