System.register(['vue', '@Obsidian/Utility/block', '@Obsidian/Utility/guid', '@Obsidian/Controls/transitionVerticalCollapse.obs', '@Obsidian/Utility/component', '@Obsidian/Controls/categoryPicker.obs', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Controls/panel.obs', '@Obsidian/Controls/rockButton.obs', '@Obsidian/Controls/sectionHeader.obs', '@Obsidian/Controls/textBox.obs', '@Obsidian/Directives/shortcut', '@Obsidian/Enums/Communication/communicationType', '@Obsidian/SystemGuids/entityType', '@Obsidian/Utility/dom', '@Obsidian/Controls/loadingIndicator.obs', '@Obsidian/Controls/buttonGroup.obs', '@Obsidian/Controls/highlightLabel.obs', '@Obsidian/Controls/Internal/pushNotificationMobilePreview.obs', '@Obsidian/Controls/Internal/smsMobilePreview.obs', '@Obsidian/Controls/modal.obs', '@Obsidian/Utility/rockDateTime', '@Obsidian/Utility/numberUtils', '@Obsidian/Utility/linq', '@Obsidian/Controls/emailEditor', '@Obsidian/Controls/buttonDropDownList.obs', '@Obsidian/Controls/dropDownList.obs', '@Obsidian/Controls/helpBlock.obs', '@Obsidian/Controls/personPicker.obs', '@Obsidian/Controls/rockLabel.obs', '@Obsidian/Controls/emailBox.obs', '@Obsidian/Utility/tooltip', '@Obsidian/Controls/conditionalWell.obs', '@Obsidian/Controls/fileUploader.obs', '@Obsidian/Controls/rockForm.obs', '@Obsidian/Utility/util', '@Obsidian/Controls/keyValueList.obs', '@Obsidian/Controls/pagePicker.obs', '@Obsidian/Controls/radioButtonList.obs', '@Obsidian/Controls/smsMessageEditor.obs', '@Obsidian/Controls/structuredContentEditor.obs', '@Obsidian/Controls/urlLinkBox.obs', '@Obsidian/Enums/Blocks/Communication/CommunicationEntryWizard/pushOpenAction', '@Obsidian/Enums/Cms/siteType', '@Obsidian/Controls/checkBox.obs', '@Obsidian/Controls/staticFormControl.obs', '@Obsidian/SystemGuids/binaryFiletype', '@Obsidian/Utility/stringUtils', '@Obsidian/Controls/progressBar.obs', '@Obsidian/Controls/numberBox.obs', '@Obsidian/Controls/switch.obs', '@Obsidian/Controls/phoneNumberBox.obs', '@Obsidian/Utility/file', '@Obsidian/Utility/promiseUtils', '@Obsidian/Controls/grid', '@Obsidian/Utility/phone', '@Obsidian/Controls/dateTimePicker.obs', '@Obsidian/Enums/Communication/segmentCriteria', '@Obsidian/Enums/Communication/communicationStatus', '@Obsidian/Utility/realTime', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/cancellation'], (function (exports) {
  'use strict';
  var provide, inject, defineComponent, ref, computed, onMounted, onBeforeUnmount, openBlock, createElementBlock, Fragment, renderSlot, createElementVNode, normalizeClass, unref, useCssVars, renderList, toDisplayString, createVNode, withCtx, createCommentVNode, createBlock, createTextVNode, isRef, withDirectives, pushScopeId, popScopeId, nextTick, watch, onUnmounted, normalizeStyle, mergeProps, createSlots, withModifiers, vShow, shallowRef, usePersonPreferences, useInvokeBlockAction, useConfigurationValues, getSecurityGrant, provideSecurityGrant, useReloadBlock, onConfigurationValuesChanged, toGuidOrNull, areEqual, newGuid, emptyGuid, TransitionVerticalCollapse, useVModelPassthrough, CategoryPicker, NotificationBox, Panel, RockButton, SectionHeader, TextBox, vShortcut, CommunicationType, EntityType, scrollElementStartToTop, isHTMLElement, LoadingIndicator, ButtonGroup, HighlightLabel, PushNotificationMobilePreview, SmsMobilePreview, Modal, RockDateTime, toNumberOrNull, Enumerable, EmailEditor, ButtonDropDownList, DropDownList, HelpBlock, PersonPicker, RockLabel, EmailBox, tooltip, ConditionalWell, FileUploader, RockForm, isNullish, debounceAsync, KeyValueList, PagePicker, RadioButtonList, SmsMessageEditor, StructuredContentEditor, UrlLinkBox, PushOpenAction, SiteType, CheckBox, StaticFormControl, BinaryFiletype, truncate, pluralize, asCommaAnd, splitCase, isNullOrWhiteSpace, createHashSha256, ProgressBar, NumberBox, Switch, PhoneNumberBox, resizeImageFileProcessor, isPromise, Grid, Column, textValueFilter, DeleteColumn, formatPhoneNumber, DateTimePicker, SegmentCriteria, SegmentCriteriaDescription, CommunicationStatus, getTopic, AlertType, CancellationTokenSource, CancellationTokenNone;
  return {
    setters: [function (module) {
      provide = module.provide;
      inject = module.inject;
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      onMounted = module.onMounted;
      onBeforeUnmount = module.onBeforeUnmount;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      Fragment = module.Fragment;
      renderSlot = module.renderSlot;
      createElementVNode = module.createElementVNode;
      normalizeClass = module.normalizeClass;
      unref = module.unref;
      useCssVars = module.useCssVars;
      renderList = module.renderList;
      toDisplayString = module.toDisplayString;
      createVNode = module.createVNode;
      withCtx = module.withCtx;
      createCommentVNode = module.createCommentVNode;
      createBlock = module.createBlock;
      createTextVNode = module.createTextVNode;
      isRef = module.isRef;
      withDirectives = module.withDirectives;
      pushScopeId = module.pushScopeId;
      popScopeId = module.popScopeId;
      nextTick = module.nextTick;
      watch = module.watch;
      onUnmounted = module.onUnmounted;
      normalizeStyle = module.normalizeStyle;
      mergeProps = module.mergeProps;
      createSlots = module.createSlots;
      withModifiers = module.withModifiers;
      vShow = module.vShow;
      shallowRef = module.shallowRef;
    }, function (module) {
      usePersonPreferences = module.usePersonPreferences;
      useInvokeBlockAction = module.useInvokeBlockAction;
      useConfigurationValues = module.useConfigurationValues;
      getSecurityGrant = module.getSecurityGrant;
      provideSecurityGrant = module.provideSecurityGrant;
      useReloadBlock = module.useReloadBlock;
      onConfigurationValuesChanged = module.onConfigurationValuesChanged;
    }, function (module) {
      toGuidOrNull = module.toGuidOrNull;
      areEqual = module.areEqual;
      newGuid = module.newGuid;
      emptyGuid = module.emptyGuid;
    }, function (module) {
      TransitionVerticalCollapse = module.default;
    }, function (module) {
      useVModelPassthrough = module.useVModelPassthrough;
    }, function (module) {
      CategoryPicker = module.default;
    }, function (module) {
      NotificationBox = module.default;
    }, function (module) {
      Panel = module.default;
    }, function (module) {
      RockButton = module.default;
    }, function (module) {
      SectionHeader = module.default;
    }, function (module) {
      TextBox = module.default;
    }, function (module) {
      vShortcut = module.vShortcut;
    }, function (module) {
      CommunicationType = module.CommunicationType;
    }, function (module) {
      EntityType = module.EntityType;
    }, function (module) {
      scrollElementStartToTop = module.scrollElementStartToTop;
      isHTMLElement = module.isHTMLElement;
    }, function (module) {
      LoadingIndicator = module.default;
    }, function (module) {
      ButtonGroup = module.default;
    }, function (module) {
      HighlightLabel = module.default;
    }, function (module) {
      PushNotificationMobilePreview = module.default;
    }, function (module) {
      SmsMobilePreview = module.default;
    }, function (module) {
      Modal = module.default;
    }, function (module) {
      RockDateTime = module.RockDateTime;
    }, function (module) {
      toNumberOrNull = module.toNumberOrNull;
    }, function (module) {
      Enumerable = module.Enumerable;
    }, function (module) {
      EmailEditor = module.default;
    }, function (module) {
      ButtonDropDownList = module.default;
    }, function (module) {
      DropDownList = module.default;
    }, function (module) {
      HelpBlock = module.default;
    }, function (module) {
      PersonPicker = module.default;
    }, function (module) {
      RockLabel = module.default;
    }, function (module) {
      EmailBox = module.default;
    }, function (module) {
      tooltip = module.tooltip;
    }, function (module) {
      ConditionalWell = module.default;
    }, function (module) {
      FileUploader = module.default;
    }, function (module) {
      RockForm = module.default;
    }, function (module) {
      isNullish = module.isNullish;
      debounceAsync = module.debounceAsync;
    }, function (module) {
      KeyValueList = module.default;
    }, function (module) {
      PagePicker = module.default;
    }, function (module) {
      RadioButtonList = module.default;
    }, function (module) {
      SmsMessageEditor = module.default;
    }, function (module) {
      StructuredContentEditor = module.default;
    }, function (module) {
      UrlLinkBox = module.default;
    }, function (module) {
      PushOpenAction = module.PushOpenAction;
    }, function (module) {
      SiteType = module.SiteType;
    }, function (module) {
      CheckBox = module.default;
    }, function (module) {
      StaticFormControl = module.default;
    }, function (module) {
      BinaryFiletype = module.BinaryFiletype;
    }, function (module) {
      truncate = module.truncate;
      pluralize = module.pluralize;
      asCommaAnd = module.asCommaAnd;
      splitCase = module.splitCase;
      isNullOrWhiteSpace = module.isNullOrWhiteSpace;
      createHashSha256 = module.createHashSha256;
    }, function (module) {
      ProgressBar = module.default;
    }, function (module) {
      NumberBox = module.default;
    }, function (module) {
      Switch = module.default;
    }, function (module) {
      PhoneNumberBox = module.default;
    }, function (module) {
      resizeImageFileProcessor = module.resizeImageFileProcessor;
    }, function (module) {
      isPromise = module.isPromise;
    }, function (module) {
      Grid = module.default;
      Column = module.Column;
      textValueFilter = module.textValueFilter;
      DeleteColumn = module.DeleteColumn;
    }, function (module) {
      formatPhoneNumber = module.formatPhoneNumber;
    }, function (module) {
      DateTimePicker = module.default;
    }, function (module) {
      SegmentCriteria = module.SegmentCriteria;
      SegmentCriteriaDescription = module.SegmentCriteriaDescription;
    }, function (module) {
      CommunicationStatus = module.CommunicationStatus;
    }, function (module) {
      getTopic = module.getTopic;
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      CancellationTokenSource = module.CancellationTokenSource;
      CancellationTokenNone = module.CancellationTokenNone;
    }],
    execute: (function () {

      function ownKeys(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          r && (o = o.filter(function (r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
          })), t.push.apply(t, o);
        }
        return t;
      }
      function _objectSpread2(e) {
        for (var r = 1; r < arguments.length; r++) {
          var t = null != arguments[r] ? arguments[r] : {};
          r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
            _defineProperty(e, r, t[r]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
          });
        }
        return e;
      }
      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }
      function _defineProperty(obj, key, value) {
        key = _toPropertyKey(key);
        if (key in obj) {
          Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
          });
        } else {
          obj[key] = value;
        }
        return obj;
      }
      function _unsupportedIterableToArray(o, minLen) {
        if (!o) return;
        if (typeof o === "string") return _arrayLikeToArray(o, minLen);
        var n = Object.prototype.toString.call(o).slice(8, -1);
        if (n === "Object" && o.constructor) n = o.constructor.name;
        if (n === "Map" || n === "Set") return Array.from(o);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
      }
      function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length) len = arr.length;
        for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
        return arr2;
      }
      function _createForOfIteratorHelper(o, allowArrayLike) {
        var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
        if (!it) {
          if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
            if (it) o = it;
            var i = 0;
            var F = function () {};
            return {
              s: F,
              n: function () {
                if (i >= o.length) return {
                  done: true
                };
                return {
                  done: false,
                  value: o[i++]
                };
              },
              e: function (e) {
                throw e;
              },
              f: F
            };
          }
          throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        var normalCompletion = true,
          didErr = false,
          err;
        return {
          s: function () {
            it = it.call(o);
          },
          n: function () {
            var step = it.next();
            normalCompletion = step.done;
            return step;
          },
          e: function (e) {
            didErr = true;
            err = e;
          },
          f: function () {
            try {
              if (!normalCompletion && it.return != null) it.return();
            } finally {
              if (didErr) throw err;
            }
          }
        };
      }
      function _toPrimitive(input, hint) {
        if (typeof input !== "object" || input === null) return input;
        var prim = input[Symbol.toPrimitive];
        if (prim !== undefined) {
          var res = prim.call(input, hint || "default");
          if (typeof res !== "object") return res;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return (hint === "string" ? String : Number)(input);
      }
      function _toPropertyKey(arg) {
        var key = _toPrimitive(arg, "string");
        return typeof key === "symbol" ? key : String(key);
      }

      var breakpointHelperInjectionKey = Symbol("breakpoint-helper");
      function provideBreakpointHelper(value) {
        provide(breakpointHelperInjectionKey, value);
      }
      function use(key) {
        var result = inject(key);
        if (result === undefined) {
          throw "Attempted to access ".concat(key.toString(), " before a value was provided.");
        }
        return result;
      }
      function useBreakpointHelper() {
        return use(breakpointHelperInjectionKey);
      }
      function usePersonPreferencesHelper() {
        var personPreferences = usePersonPreferences().blockPreferences;
        var personPreferenceKey = {
          communicationTemplateGuid: "CommunicationTemplateGuid"
        };
        return {
          getCommunicationTemplateGuid() {
            return toGuidOrNull(personPreferences.getValue(personPreferenceKey.communicationTemplateGuid));
          },
          setCommuncationTemplateGuid(value) {
            return _asyncToGenerator(function* () {
              personPreferences.setValue(personPreferenceKey.communicationTemplateGuid, value !== null && value !== void 0 ? value : "");
              yield personPreferences.save();
            })();
          }
        };
      }
      function useInvokeBlockActionHelper() {
        var invokeBlockAction = useInvokeBlockAction();
        return {
          cancelMetricsReminder(communicationGuid) {
            return invokeBlockAction("CancelMetricsReminder", {
              communicationGuid: communicationGuid
            });
          },
          checkShortLinkToken(bag) {
            return invokeBlockAction("CheckShortLinkToken", {
              bag
            });
          },
          getShortLinkPageId(pageGuid) {
            return invokeBlockAction("GetShortLinkPageId", {
              pageGuid
            });
          },
          saveMetricsReminder(bag) {
            return invokeBlockAction("SaveMetricsReminder", {
              bag
            });
          },
          getCommunicationTemplate(communicationTemplateGuid) {
            return invokeBlockAction("GetCommunicationTemplate", {
              communicationTemplateGuid
            });
          },
          getEmailPreviewHtml(bag, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId) {
            return invokeBlockAction("GetEmailPreviewHtml", {
              bag,
              previewAsPersonAliasGuid,
              previewAsPersonalizationSegmentId
            });
          },
          getPushPreview(bag, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId) {
            return invokeBlockAction("GetPushPreview", {
              bag,
              previewAsPersonAliasGuid,
              previewAsPersonalizationSegmentId
            });
          },
          getSmsPreview(bag, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId) {
            return invokeBlockAction("GetSmsPreview", {
              bag,
              previewAsPersonAliasGuid,
              previewAsPersonalizationSegmentId
            });
          },
          getRecipient(personAliasGuid) {
            return invokeBlockAction("GetRecipient", {
              personAliasGuid
            });
          },
          getRecipients(bag, cancellationToken) {
            return invokeBlockAction("GetRecipients", {
              bag
            }, undefined, cancellationToken);
          },
          getSegmentDataViews(communicationListGroupGuid) {
            return invokeBlockAction("GetSegmentDataViews", {
              communicationListGroupGuid
            });
          },
          subscribeToRealTime(request) {
            return invokeBlockAction("SubscribeToRealTime", request);
          },
          sendTest(bag) {
            return invokeBlockAction("SendTest", {
              bag
            });
          },
          save(bag) {
            return invokeBlockAction("Save", {
              bag
            });
          },
          send(bag) {
            return invokeBlockAction("Send", {
              bag
            });
          },
          saveAsCommunicationTemplate(bag) {
            return invokeBlockAction("SaveAsCommunicationTemplate", {
              bag
            });
          },
          saveCommunicationTemplate(bag) {
            return invokeBlockAction("SaveCommunicationTemplate", {
              bag
            });
          }
        };
      }
      function get(value) {
        return value;
      }
      function useCache(_ref) {
        var maxSize = _ref.maxSize;
        var cache = new Map();
        var usageQueue = new Set();
        function updateUsage(key) {
          usageQueue.delete(key);
          usageQueue.add(key);
        }
        function has(key) {
          return cache.has(key);
        }
        function get(key) {
          if (!cache.has(key)) {
            return;
          }
          updateUsage(key);
          return cache.get(key);
        }
        function set(key, value) {
          if (cache.size >= maxSize && !cache.has(key)) {
            var oldestKey = usageQueue.values().next().value;
            if (oldestKey !== undefined) {
              cache.delete(oldestKey);
              usageQueue.delete(oldestKey);
            }
          }
          cache.set(key, value);
          updateUsage(key);
        }
        function remove(key) {
          cache.delete(key);
          usageQueue.delete(key);
        }
        function clear() {
          cache.clear();
          usageQueue.clear();
        }
        return {
          has,
          get,
          set,
          remove,
          clear
        };
      }

      var script$i = defineComponent({
        __name: 'breakpointObserver.partial',
        emits: ["breakpointHelper"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var emit = __emit;
          var breakpointDisplays = {
            "xs": "none",
            "sm": "inline",
            "md": "inline-block",
            "lg": "block",
            "xl": "table"
          };
          var displayBreakpoints = {
            "none": "xs",
            "inline": "sm",
            "inline-block": "md",
            "block": "lg",
            "table": "xl"
          };
          var classes = Object.keys(breakpointDisplays).map(breakpoint => breakpoint).map(breakpoint => breakpoint === "xs" ? "d-".concat(breakpointDisplays[breakpoint]) : "d-".concat(breakpoint, "-").concat(breakpointDisplays[breakpoint]));
          var breakpointHelperDiv = ref();
          var breakpointHelper = ref(createBreakpointHelper("unknown"));
          function createBreakpointHelper(breakpoint) {
            return {
              breakpoint: breakpoint,
              isXs: breakpoint === "xs",
              isSm: breakpoint === "sm",
              isMd: breakpoint === "md",
              isLg: breakpoint === "lg",
              isXl: breakpoint === "xl",
              isXsOrSmaller: breakpoint === "xs",
              isSmOrSmaller: ["xs", "sm"].includes(breakpoint),
              isMdOrSmaller: ["xs", "sm", "md"].includes(breakpoint),
              isLgOrSmaller: ["xs", "sm", "md", "lg"].includes(breakpoint),
              isXlOrSmaller: true,
              isXsOrLarger: true,
              isSmOrLarger: ["sm", "md", "lg", "xl"].includes(breakpoint),
              isMdOrLarger: ["md", "lg", "xl"].includes(breakpoint),
              isLgOrLarger: ["lg", "xl"].includes(breakpoint),
              isXlOrLarger: breakpoint === "xl"
            };
          }
          function checkBreakpoint() {
            var _displayBreakpoints$d;
            if (!breakpointHelperDiv.value) {
              return;
            }
            var display = getComputedStyle(breakpointHelperDiv.value).display;
            var newBreakpoint = (_displayBreakpoints$d = displayBreakpoints[display]) !== null && _displayBreakpoints$d !== void 0 ? _displayBreakpoints$d : "unknown";
            if (newBreakpoint !== breakpointHelper.value.breakpoint) {
              breakpointHelper.value = createBreakpointHelper(newBreakpoint);
              emit("breakpointHelper", breakpointHelper.value);
            }
          }
          provideBreakpointHelper(computed(() => breakpointHelper.value));
          onMounted(() => {
            checkBreakpoint();
            addEventListener("resize", checkBreakpoint);
          });
          onBeforeUnmount(() => {
            removeEventListener("resize", checkBreakpoint);
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock(Fragment, null, [renderSlot(_ctx.$slots, "default"), createElementVNode("div", {
              ref_key: "breakpointHelperDiv",
              ref: breakpointHelperDiv,
              style: {
                "visibility": "collapse !important"
              },
              class: normalizeClass(unref(classes))
            }, null, 2)], 64);
          };
        }
      });

      script$i.__file = "src/Communication/CommunicationEntryWizard/breakpointObserver.partial.obs";

      var _hoisted_1$c = {
        class: "communication-template-item-grid"
      };
      var _hoisted_2$c = ["onClick"];
      var _hoisted_3$b = {
        class: "communication-template-item-preview"
      };
      var _hoisted_4$a = ["src"];
      var _hoisted_5$a = {
        class: "communication-template-item-text"
      };
      var _hoisted_6$8 = {
        key: 0,
        class: "communication-template-item-grid"
      };
      var _hoisted_7$8 = ["onClick"];
      var _hoisted_8$8 = {
        class: "communication-template-item-preview"
      };
      var _hoisted_9$8 = ["src"];
      var _hoisted_10$7 = {
        class: "communication-template-item-text"
      };
      var _hoisted_11$7 = {
        key: 1,
        class: "text-muted"
      };
      var script$h = defineComponent({
        __name: 'communicationTemplateGrid.partial',
        props: {
          communicationTemplates: {
            type: Object,
            required: true
          },
          communicationTemplateGuid: {
            type: String,
            required: true
          },
          isCollapsed: {
            type: Boolean,
            default: false
          }
        },
        emits: ["update:communicationTemplateGuid"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          useCssVars(_ctx => ({
            "4d7ce98d-colsPerRow": colsPerRow.value
          }));
          var props = __props;
          var emit = __emit;
          var breakpointHelper = useBreakpointHelper();
          var internalCommunicationTemplateGuid = useVModelPassthrough(props, "communicationTemplateGuid", emit);
          var colsPerRow = computed(() => {
            if (breakpointHelper.value.isMdOrLarger) {
              return 3;
            } else if (breakpointHelper.value.isSmOrLarger) {
              return 2;
            } else {
              return 1;
            }
          });
          var topCommunicationTemplates = computed(() => {
            return props.communicationTemplates.slice(0, colsPerRow.value);
          });
          var bottomCommunicationTemplates = computed(() => {
            return props.communicationTemplates.slice(colsPerRow.value);
          });
          return (_ctx, _cache) => {
            return __props.communicationTemplates.length ? (openBlock(), createElementBlock(Fragment, {
              key: 0
            }, [createElementVNode("div", _hoisted_1$c, [(openBlock(true), createElementBlock(Fragment, null, renderList(topCommunicationTemplates.value, communicationTemplate => {
              var _communicationTemplat;
              return openBlock(), createElementBlock("div", {
                key: "".concat(communicationTemplate.guid).concat(communicationTemplate.name),
                class: normalizeClass({
                  'communication-template-item': true,
                  'selected': unref(areEqual)(communicationTemplate.guid, unref(internalCommunicationTemplateGuid))
                }),
                onClick: $event => internalCommunicationTemplateGuid.value = communicationTemplate.guid
              }, [createElementVNode("div", _hoisted_3$b, [createElementVNode("img", {
                src: (_communicationTemplat = communicationTemplate.imageUrl) !== null && _communicationTemplat !== void 0 ? _communicationTemplat : '/Assets/Images/communication-template-default.svg',
                width: "100%"
              }, null, 8, _hoisted_4$a)]), createElementVNode("div", _hoisted_5$a, [createElementVNode("label", null, toDisplayString(communicationTemplate.name), 1), createElementVNode("p", null, toDisplayString(communicationTemplate.description), 1)])], 10, _hoisted_2$c);
            }), 128))]), createVNode(unref(TransitionVerticalCollapse), null, {
              default: withCtx(() => [!__props.isCollapsed ? (openBlock(), createElementBlock("div", _hoisted_6$8, [(openBlock(true), createElementBlock(Fragment, null, renderList(bottomCommunicationTemplates.value, communicationTemplate => {
                var _communicationTemplat2;
                return openBlock(), createElementBlock("div", {
                  key: "".concat(communicationTemplate.guid).concat(communicationTemplate.name),
                  class: normalizeClass({
                    'communication-template-item': true,
                    'selected': unref(areEqual)(communicationTemplate.guid, unref(internalCommunicationTemplateGuid))
                  }),
                  onClick: $event => internalCommunicationTemplateGuid.value = communicationTemplate.guid
                }, [createElementVNode("div", _hoisted_8$8, [createElementVNode("img", {
                  src: (_communicationTemplat2 = communicationTemplate.imageUrl) !== null && _communicationTemplat2 !== void 0 ? _communicationTemplat2 : '/Assets/Images/communication-template-default.svg',
                  width: "100%"
                }, null, 8, _hoisted_9$8)]), createElementVNode("div", _hoisted_10$7, [createElementVNode("label", null, toDisplayString(communicationTemplate.name), 1), createElementVNode("p", null, toDisplayString(communicationTemplate.description), 1)])], 10, _hoisted_7$8);
              }), 128))])) : createCommentVNode("v-if", true)]),
              _: 1
            })], 64)) : (openBlock(), createElementBlock("div", _hoisted_11$7, " No templates found. "));
          };
        }
      });

      function styleInject(css, ref) {
        if (ref === void 0) ref = {};
        var insertAt = ref.insertAt;
        if (!css || typeof document === 'undefined') {
          return;
        }
        var head = document.head || document.getElementsByTagName('head')[0];
        var style = document.createElement('style');
        style.type = 'text/css';
        if (insertAt === 'top') {
          if (head.firstChild) {
            head.insertBefore(style, head.firstChild);
          } else {
            head.appendChild(style);
          }
        } else {
          head.appendChild(style);
        }
        if (style.styleSheet) {
          style.styleSheet.cssText = css;
        } else {
          style.appendChild(document.createTextNode(css));
        }
      }

      var css_248z$b = ".communication-template-item-grid[data-v-4d7ce98d]{display:grid;gap:var(--spacing-large);grid-template-columns:repeat(var(--4d7ce98d-colsPerRow),1fr);margin-top:var(--spacing-large)}.communication-template-item[data-v-4d7ce98d]{border:1px solid var(--color-interface-soft);border-radius:var(--border-radius-base);cursor:pointer;display:grid;gap:var(--spacing-medium);grid-template-columns:3fr 2fr;height:192px;min-height:192px;overflow:hidden;padding:var(--spacing-medium);padding-bottom:0}.communication-template-item.selected[data-v-4d7ce98d]{border:var(--focus-state-border);box-shadow:var(--focus-state-shadow)}.communication-template-item-text label[data-v-4d7ce98d]{margin-bottom:var(--spacing-xsmall)}.communication-template-item-text p[data-v-4d7ce98d]{font-size:var(--font-size-small)}";
      styleInject(css_248z$b);

      script$h.__scopeId = "data-v-4d7ce98d";
      script$h.__file = "src/Communication/CommunicationEntryWizard/communicationTemplateGrid.partial.obs";

      var _withScopeId$7 = n => (pushScopeId("data-v-4fc16a70"), n = n(), popScopeId(), n);
      var _hoisted_1$b = {
        class: "panel-body-contents"
      };
      var _hoisted_2$b = {
        class: "filter-bar d-sm-flex flex-row justify-content-between"
      };
      var _hoisted_3$a = _withScopeId$7(() => createElementVNode("span", {
        class: "input-group-addon"
      }, [createElementVNode("i", {
        class: "ti ti-search"
      })], -1));
      var _hoisted_4$9 = {
        class: "category-picker-container"
      };
      var _hoisted_5$9 = {
        class: "templates-section well-section"
      };
      var _hoisted_6$7 = {
        class: "templates-section-header"
      };
      var _hoisted_7$7 = {
        class: "templates-section"
      };
      var _hoisted_8$7 = {
        class: "templates-section-header"
      };
      var _hoisted_9$7 = {
        key: 0,
        class: "ti ti-rotate-clockwise-2 ti-spin"
      };
      var script$g = defineComponent({
        __name: 'chooseTemplateStep.partial',
        props: {
          allowedMediums: {
            type: Object,
            required: true
          },
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          communicationTemplateDetail: {
            type: Object,
            required: true
          },
          communicationTemplateGuid: {
            type: String,
            required: true
          },
          communicationTemplates: {
            type: Object,
            required: true
          },
          communicationType: {
            type: Number,
            required: true
          },
          isFetchingCommunicationTemplate: {
            type: Boolean,
            required: true
          },
          title: {
            type: String,
            required: true
          },
          nextStepTitle: {
            type: String,
            required: true
          }
        },
        emits: ["nextStep", "previousStep", "update:communicationTemplateGuid"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var isErrorMessageShown = ref(false);
          var errorMessageElement = ref();
          var chooseTemplateStepElement = ref();
          var searchFilter = ref("");
          var categoryFilter = ref();
          var areStarterTemplatesExpanded = ref(false);
          var internalCommunicationTemplateGuid = useVModelPassthrough(props, "communicationTemplateGuid", emit);
          var filteredCommunicationTemplates = computed(() => {
            var _categoryFilter$value;
            var templates = props.communicationTemplates;
            var searchText = searchFilter.value;
            var searchRegex = tryGetRegExp(searchText);
            if (searchRegex) {
              templates = templates.filter(communicationTemplate => {
                return communicationTemplate.name && searchRegex.test(communicationTemplate.name) || communicationTemplate.description && searchRegex.test(communicationTemplate.description);
              });
            } else {
              var searchTextLowerCase = searchText.toLocaleLowerCase();
              templates = templates.filter(communicationTemplate => {
                return communicationTemplate.name && communicationTemplate.name.toLocaleLowerCase().indexOf(searchTextLowerCase) >= 0 || communicationTemplate.description && communicationTemplate.description.toLocaleLowerCase().indexOf(searchTextLowerCase) >= 0;
              });
            }
            var categoryGuid = toGuidOrNull((_categoryFilter$value = categoryFilter.value) === null || _categoryFilter$value === void 0 ? void 0 : _categoryFilter$value.value);
            if (categoryGuid) {
              templates = templates.filter(communicationTemplate => {
                return areEqual(communicationTemplate.categoryGuid, categoryGuid);
              });
            }
            if (props.communicationType === CommunicationType.Email || props.communicationType === CommunicationType.RecipientPreference && props.allowedMediums.includes(CommunicationType.Email)) {
              templates = templates.filter(communicationTemplate => {
                return communicationTemplate.isEmailSupported;
              });
            } else if (props.communicationType === CommunicationType.SMS || props.communicationType === CommunicationType.RecipientPreference && props.allowedMediums.includes(CommunicationType.SMS)) {
              templates = templates.filter(communicationTemplate => {
                return communicationTemplate.isSmsSupported;
              });
            }
            return templates;
          });
          var starterCommunicationTemplates = computed(() => {
            return filteredCommunicationTemplates.value.filter(communicationTemplate => {
              return communicationTemplate.isStarter;
            }).sort((a, b) => {
              if (a.communicationCount > b.communicationCount) {
                return -1;
              } else if (a.communicationCount < b.communicationCount) {
                return 1;
              } else {
                var _a$name, _b$name;
                return ((_a$name = a.name) !== null && _a$name !== void 0 ? _a$name : "").localeCompare((_b$name = b.name) !== null && _b$name !== void 0 ? _b$name : "");
              }
            });
          });
          var moreCommunicationTemplates = computed(() => {
            return filteredCommunicationTemplates.value.filter(communicationTemplate => {
              return !communicationTemplate.isStarter;
            }).sort((a, b) => {
              var _a$name2, _b$name2;
              return ((_a$name2 = a.name) !== null && _a$name2 !== void 0 ? _a$name2 : "").localeCompare((_b$name2 = b.name) !== null && _b$name2 !== void 0 ? _b$name2 : "");
            });
          });
          var isRegex = /\/(.+)\/(.*)/;
          function tryGetRegExp(pattern) {
            try {
              var match = pattern.match(isRegex);
              if (match && match.length) {
                return new RegExp(match[1], match[2]);
              }
            } catch (_unused) {}
          }
          function moveNext() {
            if (!props.isFetchingCommunicationTemplate) {
              emit("nextStep");
            } else {
              var watchOnce = watch(() => props.isFetchingCommunicationTemplate, newValue => {
                if (!newValue) {
                  emit("nextStep");
                  watchOnce();
                }
              });
            }
          }
          function onPreviousClicked() {
            emit("previousStep");
          }
          function onNextStepClicked() {
            if (!internalCommunicationTemplateGuid.value) {
              isErrorMessageShown.value = true;
              nextTick(() => {
                if (errorMessageElement.value) {
                  scrollElementStartToTop(errorMessageElement.value);
                }
              });
            } else {
              isErrorMessageShown.value = false;
              moveNext();
            }
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", {
              ref_key: "chooseTemplateStepElement",
              ref: chooseTemplateStepElement,
              class: "choose-template-step"
            }, [createVNode(unref(Panel), {
              hasFullscreen: "",
              hasNoBodyPadding: "",
              panelBodyCssClass: "panel-body-wizard",
              title: __props.title,
              type: "block"
            }, {
              default: withCtx(() => [createElementVNode("div", _hoisted_1$b, [createElementVNode("div", _hoisted_2$b, [createVNode(unref(TextBox), {
                modelValue: searchFilter.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => searchFilter.value = $event),
                disableLabel: true,
                placeholder: "Search templates…"
              }, {
                inputGroupPrepend: withCtx(() => [_hoisted_3$a]),
                _: 1
              }, 8, ["modelValue"]), createElementVNode("div", _hoisted_4$9, [createVNode(unref(CategoryPicker), {
                modelValue: categoryFilter.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => categoryFilter.value = $event),
                blankValue: "All Categories",
                disableLabel: true,
                entityTypeGuid: unref(EntityType).CommunicationTemplate,
                multiple: false
              }, null, 8, ["modelValue", "entityTypeGuid"])])]), createElementVNode("div", {
                ref_key: "errorMessageElement",
                ref: errorMessageElement
              }, [isErrorMessageShown.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: "warning"
              }, {
                default: withCtx(() => [createTextVNode(" Please select a template. ")]),
                _: 1
              })) : createCommentVNode("v-if", true)], 512), createElementVNode("div", _hoisted_5$9, [createElementVNode("div", _hoisted_6$7, [createVNode(unref(SectionHeader), {
                title: "Starter Templates",
                description: "These templates will help you quickly get started with your communication.",
                isSeparatorHidden: true
              }, {
                actions: withCtx(() => [starterCommunicationTemplates.value.length > 3 ? (openBlock(), createBlock(unref(RockButton), {
                  key: 0,
                  btnType: "link",
                  class: "expand-action",
                  isSquare: true,
                  onClick: _cache[2] || (_cache[2] = $event => areStarterTemplatesExpanded.value = !areStarterTemplatesExpanded.value)
                }, {
                  default: withCtx(() => [createElementVNode("i", {
                    class: normalizeClass({
                      'ti ti-chevron-down': !areStarterTemplatesExpanded.value,
                      'ti ti-chevron-up': areStarterTemplatesExpanded.value
                    })
                  }, null, 2)]),
                  _: 1
                })) : createCommentVNode("v-if", true)]),
                _: 1
              })]), createVNode(unref(script$h), {
                communicationTemplateGuid: unref(internalCommunicationTemplateGuid),
                "onUpdate:communicationTemplateGuid": _cache[3] || (_cache[3] = $event => isRef(internalCommunicationTemplateGuid) ? internalCommunicationTemplateGuid.value = $event : null),
                communicationTemplates: starterCommunicationTemplates.value,
                isCollapsed: !areStarterTemplatesExpanded.value
              }, null, 8, ["communicationTemplateGuid", "communicationTemplates", "isCollapsed"])]), createElementVNode("div", _hoisted_7$7, [createElementVNode("div", _hoisted_8$7, [createVNode(unref(SectionHeader), {
                title: "More Templates",
                description: "These are all the custom templates available to your organization.",
                isSeparatorHidden: true
              })]), createVNode(unref(script$h), {
                communicationTemplateGuid: unref(internalCommunicationTemplateGuid),
                "onUpdate:communicationTemplateGuid": _cache[4] || (_cache[4] = $event => isRef(internalCommunicationTemplateGuid) ? internalCommunicationTemplateGuid.value = $event : null),
                communicationTemplates: moreCommunicationTemplates.value
              }, null, 8, ["communicationTemplateGuid", "communicationTemplates"])])])]),
              footerActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                onClick: onPreviousClicked
              }, {
                default: withCtx(() => [createTextVNode("Previous")]),
                _: 1
              })), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowLeft']])]),
              footerSecondaryActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                btnType: "primary",
                disabled: __props.isFetchingCommunicationTemplate,
                onClick: onNextStepClicked
              }, {
                default: withCtx(() => [__props.isFetchingCommunicationTemplate ? (openBlock(), createElementBlock("i", _hoisted_9$7)) : createCommentVNode("v-if", true), createTextVNode(" " + toDisplayString(__props.nextStepTitle ? "Next: ".concat(__props.nextStepTitle) : 'Next'), 1)]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowRight']])]),
              _: 1
            }, 8, ["title"])], 512);
          };
        }
      });

      var css_248z$a = "[data-v-4fc16a70] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}[data-v-4fc16a70] .panel-body-wizard .actions{margin:0}.panel-body-contents[data-v-4fc16a70]{display:flex;flex:1;flex-direction:column;overflow-x:hidden;overflow-y:auto;padding:var(--panel-body-padding)}.category-picker-container[data-v-4fc16a70]{min-width:225px}.templates-section[data-v-4fc16a70]{margin:var(--spacing-xlarge) 0}.templates-section>*+[data-v-4fc16a70]{margin-top:var(--spacing-large)}.well-section[data-v-4fc16a70]{background-color:var(--color-interface-softer);border:1px solid var(--color-interface-soft);border-left:none;border-right:none;margin:0 calc(0px - var(--panel-body-padding));padding:var(--spacing-xlarge) var(--panel-body-padding)}.expand-action[data-v-4fc16a70]{color:var(--text-color)}";
      styleInject(css_248z$a);

      script$g.__scopeId = "data-v-4fc16a70";
      script$g.__file = "src/Communication/CommunicationEntryWizard/chooseTemplateStep.partial.obs";

      var _hoisted_1$a = {
        class: "confirmation-preview-panel email"
      };
      var _hoisted_2$a = {
        class: "email-preview"
      };
      var _hoisted_3$9 = {
        class: "email-header"
      };
      var _hoisted_4$8 = {
        class: "row"
      };
      var _hoisted_5$8 = {
        class: "col-xs-6"
      };
      var _hoisted_6$6 = {
        class: "col-xs-6"
      };
      var _hoisted_7$6 = {
        class: "row"
      };
      var _hoisted_8$6 = {
        class: "col-xs-6"
      };
      var _hoisted_9$6 = {
        class: "col-xs-6"
      };
      var _hoisted_10$6 = {
        class: "email-body"
      };
      var _hoisted_11$6 = ["srcdoc"];
      var script$f = defineComponent({
        __name: 'emailPreview.partial',
        props: {
          bccEmails: {
            type: String,
            required: true
          },
          ccEmails: {
            type: String,
            required: true
          },
          fromAddress: {
            type: String,
            required: true
          },
          fromName: {
            type: String,
            required: true
          },
          message: {
            type: String,
            required: true
          },
          replyToEmail: {
            type: String,
            required: true
          },
          subject: {
            type: String,
            required: true
          },
          to: {
            type: String,
            required: true
          }
        },
        setup(__props) {
          var iframeElement = ref();
          watch(iframeElement, iframe => {
            if (iframe) {
              iframe.addEventListener("load", () => {
                var _iframe$contentWindow, _iframe$contentWindow2;
                var minHeight = 450;
                var iframeContentHeight = (_iframe$contentWindow = (_iframe$contentWindow2 = iframe.contentWindow) === null || _iframe$contentWindow2 === void 0 ? void 0 : _iframe$contentWindow2.document.body.scrollHeight) !== null && _iframe$contentWindow !== void 0 ? _iframe$contentWindow : minHeight;
                iframe.style.height = iframeContentHeight + "px";
                iframe.style.minHeight = "".concat(minHeight, "px");
              });
            }
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1$a, [createElementVNode("div", _hoisted_2$a, [createElementVNode("div", _hoisted_3$9, [createElementVNode("h3", null, toDisplayString(__props.fromName) + " <" + toDisplayString(__props.fromAddress) + ">", 1), createElementVNode("h4", null, "Subject: " + toDisplayString(__props.subject), 1), createElementVNode("div", _hoisted_4$8, [createElementVNode("div", _hoisted_5$8, " To: " + toDisplayString(__props.to), 1), createElementVNode("div", _hoisted_6$6, " CC: " + toDisplayString(__props.ccEmails || 'N/A'), 1)]), createElementVNode("div", _hoisted_7$6, [createElementVNode("div", _hoisted_8$6, [__props.replyToEmail ? (openBlock(), createElementBlock(Fragment, {
              key: 0
            }, [createTextVNode(" Reply To: " + toDisplayString(__props.replyToEmail), 1)], 64)) : createCommentVNode("v-if", true)]), createElementVNode("div", _hoisted_9$6, " BCC: " + toDisplayString(__props.bccEmails || 'N/A'), 1)])]), createElementVNode("div", _hoisted_10$6, [createElementVNode("iframe", {
              ref_key: "iframeElement",
              ref: iframeElement,
              srcdoc: __props.message
            }, null, 8, _hoisted_11$6)])])]);
          };
        }
      });

      var css_248z$9 = ".confirmation-preview-panel[data-v-7f18e4df]{align-items:flex-start;background-color:var(--color-interface-soft);display:flex;padding:var(--spacing-medium);width:100%}.confirmation-preview-panel.email[data-v-7f18e4df]{max-height:880px;min-height:880px;overflow-y:auto}.email-preview[data-v-7f18e4df]{padding-right:var(--spacing-medium);width:100%}.email-header[data-v-7f18e4df]{background-color:var(--color-interface-softest);border-bottom:1px solid var(--color-interface-soft);flex:0;padding:var(--spacing-large)}.email-header h3[data-v-7f18e4df]{color:var(--color-info-strong)}.email-body[data-v-7f18e4df]{display:flex}.email-body iframe[data-v-7f18e4df]{width:100%}";
      styleInject(css_248z$9);

      script$f.__scopeId = "data-v-7f18e4df";
      script$f.__file = "src/Communication/CommunicationEntryWizard/emailPreview.partial.obs";

      var script$e = defineComponent({
        __name: 'overlay.partial',
        props: {
          targetSelector: {
            type: String,
            required: true
          },
          isVisible: {
            type: Boolean,
            default: false,
            required: true
          },
          displayDelayMs: {
            type: Number,
            default: 0
          },
          zIndex: {
            type: Object,
            default: "auto"
          },
          isAbsolute: {
            type: Boolean,
            default: true
          },
          backgroundColor: {
            type: String,
            default: "var(--modal-backdrop-background)"
          }
        },
        setup(__props) {
          useCssVars(_ctx => ({
            "4d001587-zIndex": __props.zIndex,
            "4d001587-backgroundColor": __props.backgroundColor
          }));
          var props = __props;
          var timeoutId;
          var internalIsVisible = ref(props.isVisible);
          var overlayStyles = ref({});
          function updateOverlayStyles() {
            var target = document.querySelector(props.targetSelector);
            if (!target) {
              overlayStyles.value = {};
              return;
            }
            if (!props.isAbsolute) {
              var rect = target.getBoundingClientRect();
              overlayStyles.value = {
                position: "fixed",
                top: "".concat(rect.top, "px"),
                left: "".concat(rect.left, "px"),
                width: "".concat(rect.width, "px"),
                height: "".concat(rect.height, "px")
              };
            } else {
              var _target$ownerDocument;
              var targetPosition = (_target$ownerDocument = target.ownerDocument.defaultView) === null || _target$ownerDocument === void 0 ? void 0 : _target$ownerDocument.getComputedStyle(target).position;
              if (!targetPosition || ["relative", "absolute", "fixed"].includes(targetPosition)) {
                target.style.position = "relative";
              }
              overlayStyles.value = {
                position: "absolute",
                top: "0",
                left: "0",
                width: "100%",
                height: "100%"
              };
            }
          }
          watch(() => props.isVisible, isVisible => {
            if (isVisible) {
              if (timeoutId) {
                clearTimeout(timeoutId);
              }
              updateOverlayStyles();
              timeoutId = setTimeout(() => {
                internalIsVisible.value = true;
              }, props.displayDelayMs);
            } else {
              if (timeoutId) {
                clearTimeout(timeoutId);
              }
              internalIsVisible.value = false;
            }
          });
          onMounted(() => {
            updateOverlayStyles();
            window.addEventListener("scroll", updateOverlayStyles);
            window.addEventListener("resize", updateOverlayStyles);
          });
          onUnmounted(() => {
            window.removeEventListener("scroll", updateOverlayStyles);
            window.removeEventListener("resize", updateOverlayStyles);
          });
          return (_ctx, _cache) => {
            return internalIsVisible.value ? (openBlock(), createElementBlock("div", {
              key: 0,
              style: normalizeStyle(overlayStyles.value),
              class: "overlay"
            }, [renderSlot(_ctx.$slots, "default")], 4)) : createCommentVNode("v-if", true);
          };
        }
      });

      var css_248z$8 = ".overlay[data-v-4d001587]{align-items:center;background-color:var(--4d001587-backgroundColor);display:flex;justify-content:center;pointer-events:auto;z-index:var(--4d001587-zIndex)}";
      styleInject(css_248z$8);

      script$e.__scopeId = "data-v-4d001587";
      script$e.__file = "src/Communication/CommunicationEntryWizard/overlay.partial.obs";

      var script$d = defineComponent({
        __name: 'loadingOverlay.partial',
        props: {
          targetSelector: {
            type: String,
            required: true
          },
          isAbsolute: {
            type: Boolean,
            default: true
          },
          isVisible: {
            type: Boolean,
            default: false,
            required: true
          },
          displayDelayMs: {
            type: Number,
            default: 800
          },
          zIndex: {
            type: Object,
            default: 1000
          }
        },
        setup(__props) {
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(script$e), mergeProps({
              displayDelayMs: __props.displayDelayMs,
              isAbsolute: __props.isAbsolute,
              isVisible: __props.isVisible,
              targetSelector: __props.targetSelector,
              zIndex: __props.zIndex
            }, _ctx.$attrs), {
              default: withCtx(() => [createVNode(unref(LoadingIndicator))]),
              _: 1
            }, 16, ["displayDelayMs", "isAbsolute", "isVisible", "targetSelector", "zIndex"]);
          };
        }
      });

      script$d.__file = "src/Communication/CommunicationEntryWizard/loadingOverlay.partial.obs";

      var PreviewAsType = function (PreviewAsType) {
        PreviewAsType["Person"] = "Preview As Person";
        PreviewAsType["Segment"] = "Preview As Segment";
        return PreviewAsType;
      }({});

      var _withScopeId$6 = n => (pushScopeId("data-v-4a356274"), n = n(), popScopeId(), n);
      var _hoisted_1$9 = {
        class: "confirmation-step"
      };
      var _hoisted_2$9 = {
        class: "confirmation-panel-title"
      };
      var _hoisted_3$8 = {
        class: "select-view"
      };
      var _hoisted_4$7 = {
        class: "panel-body-contents"
      };
      var _hoisted_5$7 = {
        class: "row d-md-flex"
      };
      var _hoisted_6$5 = {
        class: "col-xs-12 col-md-4 confirmation-detail-panel"
      };
      var _hoisted_7$5 = _withScopeId$6(() => createElementVNode("dt", null, "Topic", -1));
      var _hoisted_8$5 = _withScopeId$6(() => createElementVNode("dt", null, "Medium", -1));
      var _hoisted_9$5 = _withScopeId$6(() => createElementVNode("dt", null, "Recipient List", -1));
      var _hoisted_10$5 = _withScopeId$6(() => createElementVNode("dt", null, "Segments", -1));
      var _hoisted_11$5 = _withScopeId$6(() => createElementVNode("dt", null, "When To Send", -1));
      var _hoisted_12$5 = _withScopeId$6(() => createElementVNode("dt", null, "Date", -1));
      var _hoisted_13$5 = _withScopeId$6(() => createElementVNode("dt", null, "Time", -1));
      var _hoisted_14$5 = _withScopeId$6(() => createElementVNode("hr", null, null, -1));
      var _hoisted_15$5 = _withScopeId$6(() => createElementVNode("dt", null, "Attachments", -1));
      var _hoisted_16$5 = {
        key: 0
      };
      var _hoisted_17$4 = _withScopeId$6(() => createElementVNode("dt", null, "Attachments", -1));
      var _hoisted_18$3 = {
        key: 0
      };
      var _hoisted_19$2 = _withScopeId$6(() => createElementVNode("dt", null, "Bulk Communication", -1));
      var _hoisted_20$2 = {
        width: "0",
        height: "0",
        style: {
          "position": "absolute"
        }
      };
      var _hoisted_21$1 = _withScopeId$6(() => createElementVNode("defs", null, [createCommentVNode(" Define the path "), createElementVNode("path", {
        id: "triangle-slide-path",
        d: "M0 629 L337 629 L337 50 C250 50, 150 150, 150 300 C150 450, 50 550, 0 629Z"
      }), createCommentVNode(" Define the clipPath referencing the path "), createElementVNode("clipPath", {
        id: "triangle-slide"
      }, [createElementVNode("use", {
        "xlink:href": "#triangle-slide-path"
      })])], -1));
      var _hoisted_22$1 = [_hoisted_21$1];
      var View = function (View) {
        View["Email"] = "Email";
        View["SMS"] = "SMS";
        View["Push"] = "Push";
        return View;
      }(View || {});
      var script$c = defineComponent({
        __name: 'confirmationStep.partial',
        props: {
          allowedMediums: {
            type: Object,
            required: true
          },
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          bccEmails: {
            type: String,
            required: true
          },
          ccEmails: {
            type: String,
            required: true
          },
          communicationListGroupName: {
            type: String,
            required: true
          },
          communicationName: {
            type: String,
            required: true
          },
          communicationTopicValueName: {
            type: Object,
            required: true
          },
          communicationType: {
            type: Number,
            required: true
          },
          emailAttachmentNames: {
            type: Object,
            required: true
          },
          emailTo: {
            type: Object,
            required: true
          },
          fromAddress: {
            type: String,
            required: true
          },
          fromName: {
            type: String,
            required: true
          },
          futureSendDateTime: {
            type: String,
            required: true
          },
          isBulkCommunication: {
            type: Boolean,
            required: true
          },
          message: {
            type: String,
            required: true
          },
          previewAsPersonAlias: {
            type: Object,
            required: true
          },
          previewAsPersonalizationSegment: {
            type: Object,
            required: true
          },
          previewAsType: {
            type: String,
            required: true
          },
          previewEmailProcessor: {
            type: Object,
            required: true
          },
          previewPushProcessor: {
            type: Object,
            required: true
          },
          previewSmsProcessor: {
            type: Object,
            required: true
          },
          pushMessage: {
            type: String,
            required: true
          },
          pushTitle: {
            type: String,
            required: true
          },
          recipientsLabel: {
            type: String,
            required: true
          },
          replyToEmail: {
            type: String,
            required: true
          },
          segmentNames: {
            type: Object,
            required: true
          },
          smsAttachmentLinks: {
            type: Object,
            required: true
          },
          smsAttachmentNames: {
            type: Object,
            required: true
          },
          smsFromNumberName: {
            type: String,
            required: true
          },
          smsMessage: {
            type: String,
            required: true
          },
          subject: {
            type: String,
            required: true
          },
          title: {
            type: String,
            required: true
          }
        },
        emits: ["nextStep", "previousStep", "sendTestCommunication", "saveCommunication", "sendCommunication"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var breakpointHelper = useBreakpointHelper();
          var isSaveSuccessMessageShown = ref(false);
          var isSendSuccessMessageShown = ref(false);
          var isSaving = ref(false);
          var isSending = ref(false);
          var selectedView = ref(getView());
          var isSendModalShown = ref(false);
          var isPreviewLoading = ref(false);
          var messagePreview = ref(props.message);
          var pushMessagePreview = ref(props.pushMessage);
          var smsMessagePreview = ref(props.smsMessage);
          var viewItems = computed(() => {
            if (props.communicationType === CommunicationType.RecipientPreference) {
              return [{
                value: View.Email,
                text: View.Email
              }, {
                value: View.SMS,
                text: View.SMS
              }];
            } else if (props.communicationType === CommunicationType.Email) {
              return [{
                value: View.Email,
                text: View.Email
              }];
            } else if (props.communicationType === CommunicationType.SMS) {
              return [{
                value: View.SMS,
                text: View.SMS
              }];
            } else if (props.communicationType === CommunicationType.PushNotification) {
              return [{
                value: View.Push,
                text: View.Push
              }];
            } else {
              return [];
            }
          });
          var futureSendRockDateTime = computed(() => {
            if (props.futureSendDateTime) {
              return RockDateTime.parseISO(props.futureSendDateTime);
            } else {
              return null;
            }
          });
          var whenToSendDate = computed(() => {
            if (futureSendRockDateTime.value) {
              return futureSendRockDateTime.value.toASPString("dddd, MMM. d, yyyy");
            } else {
              return null;
            }
          });
          var whenToSendTime = computed(() => {
            if (futureSendRockDateTime.value) {
              return futureSendRockDateTime.value.toASPString("h:mm tt");
            } else {
              return null;
            }
          });
          function getView() {
            switch (props.communicationType) {
              case CommunicationType.SMS:
                return View.SMS;
              case CommunicationType.PushNotification:
                return View.Push;
              case CommunicationType.Email:
                return View.Email;
              case CommunicationType.RecipientPreference:
                if (props.allowedMediums.includes(CommunicationType.Email)) {
                  return View.Email;
                } else if (props.allowedMediums.includes(CommunicationType.SMS)) {
                  return View.SMS;
                } else if (props.allowedMediums.includes(CommunicationType.PushNotification)) {
                  return View.Push;
                }
                break;
            }
            console.error("Communication type unknown. Displaying email preview.");
            return View.Email;
          }
          function loadPreviewIfNecessary() {
            return _loadPreviewIfNecessary.apply(this, arguments);
          }
          function _loadPreviewIfNecessary() {
            _loadPreviewIfNecessary = _asyncToGenerator(function* () {
              var viewsEnumerable = Enumerable.from(viewItems.value).select(vi => vi.value);
              if (viewsEnumerable.any(v => v === View.Email)) {
                isPreviewLoading.value = true;
                try {
                  var _props$previewAsPerso, _props$previewAsPerso2;
                  var result = yield props.previewEmailProcessor(props.message, props.previewAsType === PreviewAsType.Person ? (_props$previewAsPerso = props.previewAsPersonAlias) === null || _props$previewAsPerso === void 0 ? void 0 : _props$previewAsPerso.value : null, props.previewAsType === PreviewAsType.Segment ? toNumberOrNull((_props$previewAsPerso2 = props.previewAsPersonalizationSegment) === null || _props$previewAsPerso2 === void 0 ? void 0 : _props$previewAsPerso2.value) : null);
                  messagePreview.value = result !== null && result !== void 0 ? result : props.message;
                } catch (_unused) {
                  messagePreview.value = props.message;
                } finally {
                  isPreviewLoading.value = false;
                }
              }
              if (viewsEnumerable.any(v => v === View.SMS)) {
                isPreviewLoading.value = true;
                try {
                  var _props$previewAsPerso3, _props$previewAsPerso4;
                  var _result = yield props.previewSmsProcessor(props.smsMessage, props.previewAsType === PreviewAsType.Person ? (_props$previewAsPerso3 = props.previewAsPersonAlias) === null || _props$previewAsPerso3 === void 0 ? void 0 : _props$previewAsPerso3.value : null, props.previewAsType === PreviewAsType.Segment ? toNumberOrNull((_props$previewAsPerso4 = props.previewAsPersonalizationSegment) === null || _props$previewAsPerso4 === void 0 ? void 0 : _props$previewAsPerso4.value) : null);
                  smsMessagePreview.value = _result !== null && _result !== void 0 ? _result : props.smsMessage;
                } catch (_unused2) {
                  smsMessagePreview.value = props.smsMessage;
                } finally {
                  isPreviewLoading.value = false;
                }
              }
              if (viewsEnumerable.any(v => v === View.Push)) {
                isPreviewLoading.value = true;
                try {
                  var _props$previewAsPerso5, _props$previewAsPerso6;
                  var _result2 = yield props.previewPushProcessor(props.pushMessage, props.previewAsType === PreviewAsType.Person ? (_props$previewAsPerso5 = props.previewAsPersonAlias) === null || _props$previewAsPerso5 === void 0 ? void 0 : _props$previewAsPerso5.value : null, props.previewAsType === PreviewAsType.Segment ? toNumberOrNull((_props$previewAsPerso6 = props.previewAsPersonalizationSegment) === null || _props$previewAsPerso6 === void 0 ? void 0 : _props$previewAsPerso6.value) : null);
                  pushMessagePreview.value = _result2 !== null && _result2 !== void 0 ? _result2 : props.pushMessage;
                } catch (_unused3) {
                  pushMessagePreview.value = props.pushMessage;
                } finally {
                  isPreviewLoading.value = false;
                }
              }
            });
            return _loadPreviewIfNecessary.apply(this, arguments);
          }
          function onPreviousClicked() {
            emit("previousStep");
          }
          function onSaveClicked() {
            if (isSaving.value) {
              return;
            }
            isSaving.value = true;
            emit("saveCommunication", {
              onSuccess() {
                isSaveSuccessMessageShown.value = true;
                isSaving.value = false;
              },
              onError() {
                isSaving.value = false;
              }
            });
          }
          function onSendClicked() {
            isSendModalShown.value = true;
          }
          function onConfirmSendClicked() {
            isSendModalShown.value = false;
            if (isSending.value) {
              return;
            }
            isSending.value = true;
            emit("sendCommunication", {
              onSuccess() {
                isSendSuccessMessageShown.value = true;
                isSending.value = false;
              },
              onError() {
                isSending.value = false;
              }
            });
          }
          watch([() => props.message, () => props.smsMessage, () => props.pushMessage, selectedView], _asyncToGenerator(function* () {
            yield loadPreviewIfNecessary();
          }));
          onMounted(_asyncToGenerator(function* () {
            yield loadPreviewIfNecessary();
          }));
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1$9, [createVNode(unref(Panel), {
              panelBodyCssClass: "panel-body-wizard",
              type: "block"
            }, createSlots({
              title: withCtx(() => [createElementVNode("div", _hoisted_2$9, [createElementVNode("span", null, toDisplayString(__props.title), 1), createVNode(unref(HighlightLabel), {
                labelType: "info"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.recipientsLabel), 1)]),
                _: 1
              })])]),
              subheaderLeft: withCtx(() => [createTextVNode(toDisplayString(__props.communicationName), 1)]),
              default: withCtx(() => [createElementVNode("div", _hoisted_4$7, [createElementVNode("div", _hoisted_5$7, [createElementVNode("div", _hoisted_6$5, [createElementVNode("dl", null, [__props.communicationTopicValueName ? (openBlock(), createElementBlock(Fragment, {
                key: 0
              }, [_hoisted_7$5, createElementVNode("dd", null, toDisplayString(__props.communicationTopicValueName), 1)], 64)) : createCommentVNode("v-if", true), _hoisted_8$5, createElementVNode("dd", null, toDisplayString(selectedView.value), 1), __props.communicationListGroupName ? (openBlock(), createElementBlock(Fragment, {
                key: 1
              }, [_hoisted_9$5, createElementVNode("dd", null, toDisplayString(__props.communicationListGroupName), 1)], 64)) : createCommentVNode("v-if", true), __props.segmentNames ? (openBlock(), createElementBlock(Fragment, {
                key: 2
              }, [_hoisted_10$5, createElementVNode("dd", null, toDisplayString(__props.segmentNames.join(', ')), 1)], 64)) : createCommentVNode("v-if", true), _hoisted_11$5, createElementVNode("dd", null, toDisplayString(__props.futureSendDateTime ? 'Later' : 'Now'), 1), __props.futureSendDateTime ? (openBlock(), createElementBlock(Fragment, {
                key: 3
              }, [_hoisted_12$5, createElementVNode("dd", null, toDisplayString(whenToSendDate.value), 1), _hoisted_13$5, createElementVNode("dd", null, toDisplayString(whenToSendTime.value), 1)], 64)) : createCommentVNode("v-if", true)]), _hoisted_14$5, createElementVNode("dl", null, [selectedView.value === View.Email && __props.emailAttachmentNames ? (openBlock(), createElementBlock(Fragment, {
                key: 0
              }, [_hoisted_15$5, createElementVNode("dd", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.emailAttachmentNames, (emailAttachmentName, index) => {
                return openBlock(), createElementBlock(Fragment, {
                  key: index
                }, [createTextVNode(toDisplayString(emailAttachmentName) + " ", 1), index < __props.emailAttachmentNames.length - 1 ? (openBlock(), createElementBlock("br", _hoisted_16$5)) : createCommentVNode("v-if", true)], 64);
              }), 128))])], 64)) : createCommentVNode("v-if", true), selectedView.value === View.SMS && __props.smsAttachmentNames ? (openBlock(), createElementBlock(Fragment, {
                key: 1
              }, [_hoisted_17$4, createElementVNode("dd", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.smsAttachmentNames, (smsAttachmentName, index) => {
                return openBlock(), createElementBlock(Fragment, {
                  key: index
                }, [createTextVNode(toDisplayString(smsAttachmentName) + " ", 1), index < __props.smsAttachmentNames.length - 1 ? (openBlock(), createElementBlock("br", _hoisted_18$3)) : createCommentVNode("v-if", true)], 64);
              }), 128))])], 64)) : createCommentVNode("v-if", true), _hoisted_19$2, createElementVNode("dd", null, toDisplayString(__props.isBulkCommunication ? 'Yes' : 'No'), 1)])]), selectedView.value === View.Email ? (openBlock(), createBlock(unref(script$f), {
                key: 0,
                bccEmails: __props.bccEmails,
                ccEmails: __props.ccEmails,
                fromAddress: __props.fromAddress,
                fromName: __props.fromName,
                message: messagePreview.value,
                replyToEmail: __props.replyToEmail,
                subject: __props.subject,
                to: __props.emailTo,
                class: "col-xs-12 col-md-8"
              }, null, 8, ["bccEmails", "ccEmails", "fromAddress", "fromName", "message", "replyToEmail", "subject", "to"])) : selectedView.value === View.SMS ? (openBlock(), createBlock(unref(SmsMobilePreview), {
                key: 1,
                class: normalizeClass(['col-xs-12 col-md-8', unref(breakpointHelper).breakpoint]),
                smsFromNumberName: __props.smsFromNumberName,
                smsAttachmentLinks: __props.smsAttachmentLinks,
                smsMessage: smsMessagePreview.value
              }, null, 8, ["class", "smsFromNumberName", "smsAttachmentLinks", "smsMessage"])) : selectedView.value === View.Push ? (openBlock(), createBlock(unref(PushNotificationMobilePreview), {
                key: 2,
                class: normalizeClass(['col-xs-12 col-md-8', unref(breakpointHelper).breakpoint]),
                pushMessage: pushMessagePreview.value,
                pushTitle: __props.pushTitle
              }, null, 8, ["class", "pushMessage", "pushTitle"])) : createCommentVNode("v-if", true)]), (openBlock(), createElementBlock("svg", _hoisted_20$2, [..._hoisted_22$1]))])]),
              footerActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                disabled: isSaving.value || isSending.value,
                onClick: _cache[1] || (_cache[1] = $event => onPreviousClicked())
              }, {
                default: withCtx(() => [createTextVNode("Previous")]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowLeft']])]),
              footerSecondaryActions: withCtx(() => [createVNode(unref(RockButton), {
                disabled: isSaving.value || isSending.value,
                onClick: onSaveClicked
              }, {
                default: withCtx(() => [createTextVNode(" Save as Draft ")]),
                _: 1
              }, 8, ["disabled"]), createVNode(unref(RockButton), {
                disabled: isSaving.value || isSending.value,
                btnType: "primary",
                onClick: onSendClicked
              }, {
                default: withCtx(() => [createTextVNode(" Send ")]),
                _: 1
              }, 8, ["disabled"])]),
              _: 2
            }, [__props.communicationType === unref(CommunicationType).RecipientPreference && viewItems.value.length > 1 ? {
              name: "subheaderRight",
              fn: withCtx(() => [createElementVNode("div", _hoisted_3$8, [createVNode(unref(ButtonGroup), {
                modelValue: selectedView.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => selectedView.value = $event),
                btnSize: "xs",
                disabled: isSaving.value || isSending.value,
                items: viewItems.value
              }, null, 8, ["modelValue", "disabled", "items"])])]),
              key: "0"
            } : undefined]), 1024), createVNode(unref(script$d), {
              isVisible: isSaving.value || isSending.value,
              targetSelector: ".confirmation-step"
            }, null, 8, ["isVisible"]), createVNode(unref(Modal), {
              modelValue: isSendModalShown.value,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => isSendModalShown.value = $event),
              cancelText: "Cancel",
              saveText: "Confirm",
              title: "Confirm Communication",
              onSave: onConfirmSendClicked
            }, {
              default: withCtx(() => [createTextVNode(" Are you sure you want to send this message to " + toDisplayString(__props.recipientsLabel.toLocaleLowerCase()) + "? ", 1)]),
              _: 1
            }, 8, ["modelValue"])]);
          };
        }
      });

      var css_248z$7 = "[data-v-4a356274] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}.panel-body-contents[data-v-4a356274]{flex:1;overflow-x:hidden;overflow-y:auto}[data-v-4a356274] .panel-sub-header{background-color:var(--color-interface-softer);border-color:var(--color-interface-soft)}.confirmation-panel-title[data-v-4a356274]{align-items:center;display:flex;justify-content:space-between}dl dt[data-v-4a356274]{font-weight:var(--font-weight-semibold)}dl dd[data-v-4a356274],dl dt[data-v-4a356274]{color:var(--color-interface-strong)}dl:not(.dl-horizontal) dt[data-v-4a356274]{margin-top:var(--spacing-small)}dl:not(.dl-horizontal) dt[data-v-4a356274]:first-child{margin-top:0}.select-view[data-v-4a356274] .btn-group{display:flex;flex-wrap:nowrap}[data-v-4a356274] .confirmation-preview-panel.xs{background:none;padding:0}";
      styleInject(css_248z$7);

      script$c.__scopeId = "data-v-4a356274";
      script$c.__file = "src/Communication/CommunicationEntryWizard/confirmationStep.partial.obs";

      var _withScopeId$5 = n => (pushScopeId("data-v-6467e05e"), n = n(), popScopeId(), n);
      var _hoisted_1$8 = {
        class: "preview-as"
      };
      var _hoisted_2$8 = {
        key: 1,
        class: "preview-as-segment"
      };
      var _hoisted_3$7 = {
        key: 0,
        class: "preview-as-segment-hint"
      };
      var _hoisted_4$6 = {
        key: 1,
        class: "preview-as-segment-error"
      };
      var _hoisted_5$6 = _withScopeId$5(() => createElementVNode("i", {
        class: "ti ti-alert-circle"
      }, null, -1));
      var script$b = defineComponent({
        __name: 'previewAs.partial',
        props: {
          isPreviewLoading: {
            type: Boolean,
            required: true
          },
          personalizationSegment: {
            type: Object,
            required: true
          },
          personalizationSegments: {
            type: Array,
            required: true
          },
          previewAsType: {
            type: String,
            required: true
          },
          previewAsPersonAlias: {
            type: Object,
            required: true
          }
        },
        emits: ["update:personalizationSegment", "update:previewAsPersonAlias", "update:previewAsType"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var internalPreviewAsPersonAlias = useVModelPassthrough(props, "previewAsPersonAlias", emit);
          var internalPreviewAsType = useVModelPassthrough(props, "previewAsType", emit);
          var previewAsPersonalizationSegmentIdOrEmptyString = computed({
            get() {
              var _props$personalizatio, _props$personalizatio2;
              return (_props$personalizatio = (_props$personalizatio2 = props.personalizationSegment) === null || _props$personalizatio2 === void 0 ? void 0 : _props$personalizatio2.value) !== null && _props$personalizatio !== void 0 ? _props$personalizatio : "";
            },
            set(value) {
              var _props$personalizatio3;
              var segment = (_props$personalizatio3 = props.personalizationSegments) === null || _props$personalizatio3 === void 0 ? void 0 : _props$personalizatio3.find(s => s.value === value);
              emit("update:personalizationSegment", segment);
            }
          });
          var previewAsTypes = computed(() => {
            return Enumerable.from([PreviewAsType.Person, PreviewAsType.Segment]).select(i => ({
              text: i,
              value: i
            })).toArray();
          });
          var previewAsPersonAliasOrUndefined = computed({
            get() {
              var _internalPreviewAsPer;
              return (_internalPreviewAsPer = internalPreviewAsPersonAlias.value) !== null && _internalPreviewAsPer !== void 0 ? _internalPreviewAsPer : undefined;
            },
            set(value) {
              internalPreviewAsPersonAlias.value = value;
            }
          });
          return (_ctx, _cache) => {
            var _props$personalizati, _props$personalizati2;
            return openBlock(), createElementBlock("div", _hoisted_1$8, [(_props$personalizati = __props.personalizationSegments) !== null && _props$personalizati !== void 0 && _props$personalizati.length ? (openBlock(), createElementBlock(Fragment, {
              key: 0
            }, [createVNode(unref(ButtonDropDownList), {
              modelValue: unref(internalPreviewAsType),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(internalPreviewAsType) ? internalPreviewAsType.value = $event : null),
              btnType: "link",
              items: previewAsTypes.value
            }, null, 8, ["modelValue", "items"]), __props.previewAsType === unref(PreviewAsType).Person ? (openBlock(), createBlock(unref(PersonPicker), {
              key: 0,
              modelValue: previewAsPersonAliasOrUndefined.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => previewAsPersonAliasOrUndefined.value = $event)
            }, null, 8, ["modelValue"])) : __props.previewAsType === unref(PreviewAsType).Segment ? (openBlock(), createElementBlock("div", _hoisted_2$8, [createVNode(unref(DropDownList), {
              modelValue: previewAsPersonalizationSegmentIdOrEmptyString.value,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => previewAsPersonalizationSegmentIdOrEmptyString.value = $event),
              items: (_props$personalizati2 = __props.personalizationSegments) !== null && _props$personalizati2 !== void 0 ? _props$personalizati2 : [],
              showBlankItem: false
            }, null, 8, ["modelValue", "items"]), !__props.isPreviewLoading ? (openBlock(), createElementBlock(Fragment, {
              key: 0
            }, [__props.previewAsPersonAlias ? (openBlock(), createElementBlock("div", _hoisted_3$7, [createTextVNode("Previewing As: " + toDisplayString(__props.previewAsPersonAlias.text) + " ", 1), createVNode(unref(HelpBlock), {
              text: "If a segment is selected, a random person from that segment will be used for preview. This person may not be an actual email recipient and might belong to other segments, which could affect personalization based on your settings."
            })])) : (openBlock(), createElementBlock("div", _hoisted_4$6, [_hoisted_5$6, createTextVNode(" Empty personalization segment ")]))], 64)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true)], 64)) : (openBlock(), createElementBlock(Fragment, {
              key: 1
            }, [createVNode(unref(RockLabel), null, {
              default: withCtx(() => [createTextVNode("Preview As Person")]),
              _: 1
            }), __props.previewAsType === unref(PreviewAsType).Person ? (openBlock(), createBlock(unref(PersonPicker), {
              key: 0,
              modelValue: previewAsPersonAliasOrUndefined.value,
              "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => previewAsPersonAliasOrUndefined.value = $event)
            }, null, 8, ["modelValue"])) : createCommentVNode("v-if", true)], 64))]);
          };
        }
      });

      var css_248z$6 = ".preview-as[data-v-6467e05e]{align-items:center;display:flex;flex-direction:row;gap:var(--spacing-small)}.preview-as-segment[data-v-6467e05e]{align-items:center;display:flex;flex-direction:row;gap:var(--spacing-large)}.preview-as-segment-hint[data-v-6467e05e]{color:var(--color-interface-medium);font-size:var(--font-size-small)}.preview-as-segment-error[data-v-6467e05e]{color:var(--color-danger-strong);font-size:var(--font-size-small)}";
      styleInject(css_248z$6);

      script$b.__scopeId = "data-v-6467e05e";
      script$b.__file = "src/Communication/CommunicationEntryWizard/previewAs.partial.obs";

      var _withScopeId$4 = n => (pushScopeId("data-v-00525b68"), n = n(), popScopeId(), n);
      var _hoisted_1$7 = {
        class: "email-editor-step"
      };
      var _hoisted_2$7 = {
        class: "email-editor-panel-title"
      };
      var _hoisted_3$6 = {
        class: "email-editor-panel-title-right"
      };
      var _hoisted_4$5 = _withScopeId$4(() => createElementVNode("i", {
        class: "ti ti-x",
        "aria-hidden": "true"
      }, null, -1));
      var _hoisted_5$5 = [_hoisted_4$5];
      var _hoisted_6$4 = ["innerHTML"];
      var _hoisted_7$4 = _withScopeId$4(() => createElementVNode("i", {
        class: "ti ti-x",
        "aria-hidden": "true"
      }, null, -1));
      var _hoisted_8$4 = [_hoisted_7$4];
      var _hoisted_9$4 = _withScopeId$4(() => createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      }, null, -1));
      var _hoisted_10$4 = ["disabled"];
      var _hoisted_11$4 = ["disabled"];
      var _hoisted_12$4 = {
        class: "panel-body-contents"
      };
      var _hoisted_13$4 = _withScopeId$4(() => createElementVNode("i", {
        class: "ti ti-send"
      }, null, -1));
      var _hoisted_14$4 = {
        class: "preview"
      };
      var _hoisted_15$4 = {
        class: "preview-toolbar"
      };
      var _hoisted_16$4 = ["srcdoc"];
      var script$a = defineComponent({
        __name: 'emailEditorStep.partial',
        props: {
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          communicationTemplateGuid: {
            type: String,
            required: true
          },
          communicationTemplates: {
            type: Object,
            required: true
          },
          imageComponentBinaryFileTypeGuid: {
            type: String,
            required: true
          },
          isFetchingRecipients: {
            type: Boolean,
            required: true
          },
          mergeFields: {
            type: Object,
            required: true
          },
          message: {
            type: String,
            required: true
          },
          nextStepTitle: {
            type: String,
            required: true
          },
          personalizationSegments: {
            type: Array,
            required: true
          },
          previewAsPersonAlias: {
            type: Object,
            required: true
          },
          previewAsPersonalizationSegment: {
            type: Object,
            required: true
          },
          previewAsType: {
            type: String,
            required: true
          },
          previewHtmlProcessor: {
            type: Object,
            required: true
          },
          recipientPersonIds: {
            type: Object,
            required: true
          },
          recipientsLabel: {
            type: String,
            required: true
          },
          shortLinkCheckToken: {
            type: Object,
            required: true
          },
          shortLinkGetPageId: {
            type: Object,
            required: true
          },
          shortLinkSites: {
            type: Object,
            required: true
          },
          shortLinkTokenMinLength: {
            type: Number
          },
          testEmailAddress: {
            type: String,
            required: true
          },
          title: {
            type: String,
            required: true
          },
          videoProviderNames: {
            type: Object,
            required: true
          }
        },
        emits: ["nextStep", "previousStep", "sendTestCommunication", "saveCommunication", "saveAsTemplate", "update:message", "update:communicationTemplateGuid", "update:testEmailAddress", "update:previewAsPersonAlias", "update:previewAsPersonalizationSegment", "update:previewAsType"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var emailEditorElement = ref(null);
          var previewElement = ref();
          var saveElement = ref();
          var previewHtml = ref("");
          var selectedComponentElement = ref();
          var isPreviewLoading = ref(false);
          var isPreviewOpen = ref(false);
          var previewDevice = ref("desktop");
          var isSaveSuccessMessageShown = ref(false);
          var isSendTestErrorMessageShown = ref(false);
          var sendTestErrorMessage = ref("");
          var isSaving = ref(false);
          var isSendingTest = ref(false);
          var isSendTestModalShown = ref(false);
          var getHtmlRequest = ref();
          var html = ref(props.message);
          var internalPreviewAsType = useVModelPassthrough(props, "previewAsType", emit);
          var internalPreviewAsPersonalizationSegment = useVModelPassthrough(props, "previewAsPersonalizationSegment", emit);
          var internalPreviewAsPersonAlias = useVModelPassthrough(props, "previewAsPersonAlias", emit);
          var internalTestEmailAddress = useVModelPassthrough(props, "testEmailAddress", emit);
          var isDisabled = computed(() => {
            return isSaving.value || isSendingTest.value || isPreviewLoading.value;
          });
          var refreshPreviewRequestKey = computed(() => {
            var _internalPreviewAsPer, _internalPreviewAsPer2, _internalPreviewAsPer3, _internalPreviewAsPer4;
            return internalPreviewAsType.value === "Preview As Person" ? "person:".concat((_internalPreviewAsPer = (_internalPreviewAsPer2 = internalPreviewAsPersonAlias.value) === null || _internalPreviewAsPer2 === void 0 ? void 0 : _internalPreviewAsPer2.value) !== null && _internalPreviewAsPer !== void 0 ? _internalPreviewAsPer : "") : "segment:".concat((_internalPreviewAsPer3 = (_internalPreviewAsPer4 = internalPreviewAsPersonalizationSegment.value) === null || _internalPreviewAsPer4 === void 0 ? void 0 : _internalPreviewAsPer4.value) !== null && _internalPreviewAsPer3 !== void 0 ? _internalPreviewAsPer3 : "");
          });
          function onSaveAsTemplate() {
            getHtmlRequest.value = {
              onSuccess(response) {
                var _emailEditorElement$v;
                var api = (_emailEditorElement$v = emailEditorElement.value) === null || _emailEditorElement$v === void 0 ? void 0 : _emailEditorElement$v.getApi();
                if (api) {
                  emit("saveAsTemplate", response, api);
                }
              }
            };
          }
          function onSendTestCommunication() {
            if (isSendingTest.value) {
              return;
            }
            isSendingTest.value = true;
            isSendTestErrorMessageShown.value = false;
            getHtmlRequest.value = {
              onSuccess(_ref2) {
                var html = _ref2.html;
                emit("sendTestCommunication", html, {
                  onSuccess() {
                    isSendingTest.value = false;
                  },
                  onError(error) {
                    isSendingTest.value = false;
                    isSendTestErrorMessageShown.value = true;
                    sendTestErrorMessage.value = error !== null && error !== void 0 ? error : "An error occurred while sending the test email.";
                  }
                });
              }
            };
            isSendTestModalShown.value = false;
          }
          function onPreviousClicked() {
            getHtmlRequest.value = {
              onSuccess(_ref3) {
                var html = _ref3.html;
                emit("update:message", html);
                emit("previousStep");
              }
            };
          }
          function onNextClicked() {
            getHtmlRequest.value = {
              onSuccess(_ref4) {
                var html = _ref4.html;
                emit("update:message", html);
                emit("nextStep");
              }
            };
          }
          function onSaveCommunication() {
            if (isSaving.value) {
              return;
            }
            isSaving.value = true;
            selectedComponentElement.value = null;
            getHtmlRequest.value = {
              onSuccess(_ref5) {
                var html = _ref5.html;
                emit("update:message", html);
                emit("saveCommunication", {
                  onSuccess() {
                    isSaveSuccessMessageShown.value = true;
                    isSaving.value = false;
                  },
                  onError() {
                    isSaving.value = false;
                  }
                });
              }
            };
          }
          function updatePreview() {
            selectedComponentElement.value = null;
            isPreviewLoading.value = true;
            getHtmlRequest.value = {
              onSuccess(_ref6) {
                return _asyncToGenerator(function* () {
                  var _internalPreviewAsPer5, _internalPreviewAsPer6;
                  var html = _ref6.html;
                  emit("update:message", html);
                  var previewAsPersonAliasGuid = internalPreviewAsType.value === PreviewAsType.Person ? toGuidOrNull((_internalPreviewAsPer5 = internalPreviewAsPersonAlias.value) === null || _internalPreviewAsPer5 === void 0 ? void 0 : _internalPreviewAsPer5.value) : null;
                  var previewAsPersonalizationSegmentId = internalPreviewAsType.value === PreviewAsType.Segment ? toNumberOrNull((_internalPreviewAsPer6 = internalPreviewAsPersonalizationSegment.value) === null || _internalPreviewAsPer6 === void 0 ? void 0 : _internalPreviewAsPer6.value) : null;
                  var result = yield props.previewHtmlProcessor(html, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId);
                  previewHtml.value = result !== null && result !== void 0 ? result : "";
                  isPreviewOpen.value = true;
                  isPreviewLoading.value = false;
                })();
              }
            };
          }
          function onClickPreview() {
            updatePreview();
          }
          function onKeyDownEscape(event) {
            if (event.key === "Escape") {
              console.debug("onKeyDownEscape");
              selectedComponentElement.value = null;
              event.stopImmediatePropagation();
            }
          }
          watch(refreshPreviewRequestKey, () => {
            updatePreview();
          });
          watch(saveElement, element => {
            if (element) {
              tooltip(element);
            }
          });
          watch(previewElement, element => {
            if (element) {
              tooltip(element);
            }
          });
          onMounted(_asyncToGenerator(function* () {
            window.removeEventListener("keydown", onKeyDownEscape);
            window.addEventListener("keydown", onKeyDownEscape);
          }));
          onUnmounted(() => {
            window.removeEventListener("keydown", onKeyDownEscape);
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1$7, [createVNode(unref(Panel), {
              hasFullscreen: "",
              headerSecondaryActions: [{
                title: 'Save As Template',
                type: 'default',
                handler: onSaveAsTemplate
              }],
              hasNoBodyPadding: "",
              panelBodyCssClass: "panel-body-wizard",
              type: "block"
            }, {
              title: withCtx(() => [createElementVNode("div", _hoisted_2$7, [createElementVNode("span", null, toDisplayString(__props.title), 1), createElementVNode("div", _hoisted_3$6, [isSaveSuccessMessageShown.value ? (openBlock(), createBlock(unref(HighlightLabel), {
                key: 0,
                labelType: "success"
              }, {
                default: withCtx(() => [createTextVNode(" The communication has been saved. "), createElementVNode("button", {
                  type: "button",
                  class: "close btn-dismiss-alert",
                  "aria-label": "Hide This Alert",
                  onClick: _cache[0] || (_cache[0] = withModifiers($event => isSaveSuccessMessageShown.value = false, ["prevent"]))
                }, [..._hoisted_5$5])]),
                _: 1
              })) : createCommentVNode("v-if", true), isSendTestErrorMessageShown.value ? (openBlock(), createBlock(unref(HighlightLabel), {
                key: 1,
                labelType: "danger",
                dismissible: true,
                onDismiss: _cache[2] || (_cache[2] = $event => isSendTestErrorMessageShown.value = false)
              }, {
                default: withCtx(() => [createElementVNode("div", {
                  innerHTML: sendTestErrorMessage.value,
                  style: {
                    "font-weight": "var(--font-weight-regular)"
                  }
                }, null, 8, _hoisted_6$4), createElementVNode("button", {
                  type: "button",
                  class: "close btn-dismiss-alert",
                  "aria-label": "Hide This Alert",
                  onClick: _cache[1] || (_cache[1] = withModifiers($event => isSendTestErrorMessageShown.value = false, ["prevent"]))
                }, [..._hoisted_8$4])]),
                _: 1
              })) : createCommentVNode("v-if", true), createVNode(unref(HighlightLabel), {
                labelType: "info"
              }, {
                default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock(Fragment, {
                  key: 0
                }, [_hoisted_9$4, createTextVNode(" Recipients")], 64)) : (openBlock(), createElementBlock(Fragment, {
                  key: 1
                }, [createTextVNode(toDisplayString(__props.recipientsLabel), 1)], 64))]),
                _: 1
              })])])]),
              headerActions: withCtx(() => [createElementVNode("span", {
                class: "action panel-action-preview clickable",
                disabled: isDisabled.value,
                onClick: onClickPreview
              }, [createElementVNode("i", {
                ref_key: "previewElement",
                ref: previewElement,
                "data-toggle": "tooltip",
                title: "Preview",
                class: "ti ti-eye"
              }, null, 512)], 8, _hoisted_10$4), createElementVNode("span", {
                class: "action panel-action-save clickable",
                disabled: isDisabled.value,
                onClick: onSaveCommunication
              }, [createElementVNode("i", {
                ref_key: "saveElement",
                ref: saveElement,
                "data-toggle": "tooltip",
                title: "Save Draft",
                class: "ti ti-device-floppy"
              }, null, 512)], 8, _hoisted_11$4)]),
              default: withCtx(() => [createElementVNode("div", _hoisted_12$4, [createVNode(unref(EmailEditor), {
                ref_key: "emailEditorElement",
                ref: emailEditorElement,
                html: html.value,
                getHtmlRequest: getHtmlRequest.value,
                imageComponentBinaryFileTypeGuid: __props.imageComponentBinaryFileTypeGuid,
                disabled: isDisabled.value,
                mergeFields: __props.mergeFields,
                shortLinkCheckToken: __props.shortLinkCheckToken,
                shortLinkGetPageId: __props.shortLinkGetPageId,
                shortLinkSites: __props.shortLinkSites,
                shortLinkTokenMinLength: __props.shortLinkTokenMinLength,
                recipientPersonIds: __props.recipientPersonIds,
                videoProviderNames: __props.videoProviderNames
              }, null, 8, ["html", "getHtmlRequest", "imageComponentBinaryFileTypeGuid", "disabled", "mergeFields", "shortLinkCheckToken", "shortLinkGetPageId", "shortLinkSites", "shortLinkTokenMinLength", "recipientPersonIds", "videoProviderNames"]), createVNode(unref(script$d), {
                isVisible: isDisabled.value,
                targetSelector: ".email-editor-step"
              }, null, 8, ["isVisible"])])]),
              footerActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                disabled: isDisabled.value,
                onClick: onPreviousClicked
              }, {
                default: withCtx(() => [createTextVNode("Previous")]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowLeft']])]),
              footerSecondaryActions: withCtx(() => [createVNode(unref(RockButton), {
                disabled: isDisabled.value,
                onClick: _cache[3] || (_cache[3] = $event => isSendTestModalShown.value = true)
              }, {
                default: withCtx(() => [_hoisted_13$4, createTextVNode(" Send Test ")]),
                _: 1
              }, 8, ["disabled"]), withDirectives((openBlock(), createBlock(unref(RockButton), {
                btnType: "primary",
                disabled: isDisabled.value,
                onClick: onNextClicked
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.nextStepTitle ? "Next: ".concat(__props.nextStepTitle) : 'Next'), 1)]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowRight']])]),
              _: 1
            }, 8, ["headerSecondaryActions"]), createVNode(unref(Modal), {
              modelValue: isPreviewOpen.value,
              "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => isPreviewOpen.value = $event),
              title: "Email Preview"
            }, {
              default: withCtx(() => [createElementVNode("div", _hoisted_14$4, [createElementVNode("div", _hoisted_15$4, [createVNode(unref(script$b), {
                previewAsType: unref(internalPreviewAsType),
                "onUpdate:previewAsType": _cache[4] || (_cache[4] = $event => isRef(internalPreviewAsType) ? internalPreviewAsType.value = $event : null),
                previewAsPersonAlias: unref(internalPreviewAsPersonAlias),
                "onUpdate:previewAsPersonAlias": _cache[5] || (_cache[5] = $event => isRef(internalPreviewAsPersonAlias) ? internalPreviewAsPersonAlias.value = $event : null),
                personalizationSegment: unref(internalPreviewAsPersonalizationSegment),
                "onUpdate:personalizationSegment": _cache[6] || (_cache[6] = $event => isRef(internalPreviewAsPersonalizationSegment) ? internalPreviewAsPersonalizationSegment.value = $event : null),
                isPreviewLoading: isPreviewLoading.value,
                personalizationSegments: __props.personalizationSegments
              }, null, 8, ["previewAsType", "previewAsPersonAlias", "personalizationSegment", "isPreviewLoading", "personalizationSegments"]), createVNode(unref(ButtonGroup), {
                modelValue: previewDevice.value,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => previewDevice.value = $event),
                items: [{
                  text: 'Desktop',
                  value: 'desktop'
                }, {
                  text: 'Mobile',
                  value: 'mobile'
                }]
              }, null, 8, ["modelValue"])]), createElementVNode("div", {
                class: normalizeClass(previewDevice.value === 'desktop' ? 'device-browser' : 'device-mobile')
              }, [createElementVNode("iframe", {
                srcdoc: previewHtml.value
              }, null, 8, _hoisted_16$4)], 2)])]),
              _: 1
            }, 8, ["modelValue"]), createVNode(unref(Modal), {
              modelValue: isSendTestModalShown.value,
              "onUpdate:modelValue": _cache[10] || (_cache[10] = $event => isSendTestModalShown.value = $event),
              saveText: "Send",
              onSave: onSendTestCommunication
            }, {
              default: withCtx(() => [createVNode(unref(EmailBox), {
                modelValue: unref(internalTestEmailAddress),
                "onUpdate:modelValue": _cache[9] || (_cache[9] = $event => isRef(internalTestEmailAddress) ? internalTestEmailAddress.value = $event : null),
                help: "This will temporarily change your email address during the test, but it will be changed back after the test is complete.",
                label: "Email",
                rules: "required"
              }, null, 8, ["modelValue"])]),
              _: 1
            }, 8, ["modelValue"])]);
          };
        }
      });

      var css_248z$5 = "@import \"/Styles/RockFont/style.css\";@import \"/Styles/Blocks/Shared/Devices.css\";[data-v-00525b68] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}.panel-body-contents[data-v-00525b68]{flex:1;overflow:hidden}[data-v-00525b68] .panel-sub-header{background-color:var(--color-interface-softer);border-color:var(--color-interface-soft)}[data-v-00525b68] .panel-body .actions:last-of-type{margin:0}.preview[data-v-00525b68]{align-items:center;display:flex;flex-direction:column;gap:var(--spacing-medium)}.preview>.btn-group[data-v-00525b68]{width:100%}.preview-toolbar[data-v-00525b68]{align-items:center;display:flex;flex-direction:row;justify-content:space-between;width:100%}.device-browser[data-v-00525b68]{height:568px;position:relative}.device-mobile[data-v-00525b68]{height:693px;position:relative}.preview iframe[data-v-00525b68]{height:100%;width:100%}[data-v-00525b68] .email-editor-side-panel-heading{background-color:var(--color-interface-softest)}.email-editor-panel-title[data-v-00525b68]{align-items:center;display:flex;justify-content:space-between}.email-editor-panel-title-right[data-v-00525b68]{display:flex;flex-direction:row;gap:var(--spacing-xsmall)}.btn-dismiss-alert[data-v-00525b68]{font-size:var(--font-size-xsmall)}.btn-dismiss-alert.close i[data-v-00525b68]{display:inline-block}";
      styleInject(css_248z$5);

      script$a.__scopeId = "data-v-00525b68";
      script$a.__file = "src/Communication/CommunicationEntryWizard/emailEditorStep.partial.obs";

      var _withScopeId$3 = n => (pushScopeId("data-v-efc8f4fc"), n = n(), popScopeId(), n);
      var _hoisted_1$6 = {
        class: "panel-body-contents"
      };
      var _hoisted_2$6 = {
        class: "row"
      };
      var _hoisted_3$5 = {
        class: "col-sm-6"
      };
      var _hoisted_4$4 = {
        class: "col-sm-6"
      };
      var _hoisted_5$4 = {
        class: "form-group"
      };
      var _hoisted_6$3 = {
        class: "text-primary"
      };
      var _hoisted_7$3 = {
        class: "row"
      };
      var _hoisted_8$3 = {
        class: "col-sm-4"
      };
      var _hoisted_9$3 = {
        class: "row"
      };
      var _hoisted_10$3 = {
        class: "col-sm-4"
      };
      var _hoisted_11$3 = {
        class: "col-sm-4"
      };
      var _hoisted_12$3 = _withScopeId$3(() => createElementVNode("p", {
        class: "text-muted note"
      }, "Note: Because Rock personalizes emails, CC and BCC recipients will receive one email per recipient.", -1));
      var _hoisted_13$3 = {
        class: "row"
      };
      var _hoisted_14$3 = {
        class: "col-sm-6"
      };
      var _hoisted_15$3 = {
        class: "attachment"
      };
      var _hoisted_16$3 = {
        class: "attachment-content"
      };
      var _hoisted_17$3 = ["href"];
      var _hoisted_18$2 = ["onClick"];
      var script$9 = defineComponent({
        __name: 'emailSettingsStep.partial',
        props: {
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          attachmentBinaryFileTypeGuid: {
            type: String,
            required: true
          },
          bccEmails: {
            type: String,
            required: true
          },
          ccEmails: {
            type: String,
            required: true
          },
          emailAttachmentBinaryFiles: {
            type: Object,
            required: true
          },
          fromEmail: {
            type: String,
            required: true
          },
          fromName: {
            type: String,
            required: true
          },
          message: {
            type: String,
            required: true
          },
          nextStepTitle: {
            type: String,
            required: true
          },
          replyToEmail: {
            type: String,
            required: true
          },
          subject: {
            type: String,
            required: true
          },
          title: {
            type: String,
            required: true
          }
        },
        emits: ["nextStep", "previousStep", "update:bccEmails", "update:ccEmails", "update:emailAttachmentBinaryFiles", "update:fromEmail", "update:fromName", "update:message", "update:replyToEmail", "update:subject"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var formId = "email-settings-step-form-".concat(newGuid());
          var emailSettingsStepElement = ref();
          var currentAttachment = ref();
          var areMoreOptionsShown = ref(!!props.replyToEmail || !!props.ccEmails || !!props.bccEmails);
          var messageIFrameElement = ref(document.createElement("iframe"));
          var emailPreviewElement = ref();
          var emailPreviewText = ref("");
          var internalBccEmails = useVModelPassthrough(props, "bccEmails", emit);
          var internalCcEmails = useVModelPassthrough(props, "ccEmails", emit);
          var internalEmailAttachmentBinaryFiles = useVModelPassthrough(props, "emailAttachmentBinaryFiles", emit);
          var internalFromEmail = useVModelPassthrough(props, "fromEmail", emit);
          var internalFromName = useVModelPassthrough(props, "fromName", emit);
          var internalMessage = useVModelPassthrough(props, "message", emit);
          var internalReplyToEmail = useVModelPassthrough(props, "replyToEmail", emit);
          var internalSubject = useVModelPassthrough(props, "subject", emit);
          function processMessage() {
            var _messageIFrameElement2;
            messageIFrameElement.value.addEventListener("load", () => {
              var _messageIFrameElement;
              var previewElement = (_messageIFrameElement = messageIFrameElement.value.contentDocument) === null || _messageIFrameElement === void 0 ? void 0 : _messageIFrameElement.querySelector("#preheader-text");
              if (isHTMLElement(previewElement)) {
                emailPreviewElement.value = previewElement;
                emailPreviewText.value = emailPreviewElement.value.innerText;
              } else {
                emailPreviewElement.value = null;
                emailPreviewText.value = "";
              }
            }, {
              once: true
            });
            messageIFrameElement.value.srcdoc = internalMessage.value;
            var previewElement = (_messageIFrameElement2 = messageIFrameElement.value.contentDocument) === null || _messageIFrameElement2 === void 0 ? void 0 : _messageIFrameElement2.querySelector("#preheader-text");
            if (isHTMLElement(previewElement)) {
              emailPreviewElement.value = previewElement;
              emailPreviewText.value = emailPreviewElement.value.innerText;
            } else {
              emailPreviewElement.value = null;
              emailPreviewText.value = "";
            }
          }
          function onPreviousClicked() {
            emit("previousStep");
          }
          function onFormSubmitted() {
            return _onFormSubmitted.apply(this, arguments);
          }
          function _onFormSubmitted() {
            _onFormSubmitted = _asyncToGenerator(function* () {
              var _messageIFrameElement3;
              if ((_messageIFrameElement3 = messageIFrameElement.value) !== null && _messageIFrameElement3 !== void 0 && _messageIFrameElement3.contentDocument && emailPreviewElement.value && emailPreviewText.value) {
                emailPreviewElement.value.innerText = emailPreviewText.value;
                emit("update:message", messageIFrameElement.value.contentDocument.documentElement.outerHTML);
                yield nextTick();
              }
              emit("nextStep");
            });
            return _onFormSubmitted.apply(this, arguments);
          }
          function onAttachmentAdded(attachment) {
            var _internalEmailAttachm;
            if (isNullish(attachment)) {
              return;
            }
            internalEmailAttachmentBinaryFiles.value = [...((_internalEmailAttachm = internalEmailAttachmentBinaryFiles.value) !== null && _internalEmailAttachm !== void 0 ? _internalEmailAttachm : []), attachment];
            currentAttachment.value = null;
          }
          function onAttachmentRemoved(attachment) {
            var _internalEmailAttachm2;
            if (isNullish(attachment)) {
              return;
            }
            internalEmailAttachmentBinaryFiles.value = (_internalEmailAttachm2 = internalEmailAttachmentBinaryFiles.value) === null || _internalEmailAttachm2 === void 0 ? void 0 : _internalEmailAttachm2.filter(a => attachment !== a);
          }
          watch(internalMessage, () => {
            processMessage();
          });
          onMounted(() => {
            messageIFrameElement.value.style.display = "none";
            document.body.append(messageIFrameElement.value);
            processMessage();
          });
          onUnmounted(() => {
            messageIFrameElement.value.remove();
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", {
              ref_key: "emailSettingsStepElement",
              ref: emailSettingsStepElement,
              class: "email-settings-step"
            }, [createVNode(unref(Panel), {
              hasFullscreen: "",
              panelBodyCssClass: "panel-body-wizard",
              title: __props.title,
              type: "block"
            }, {
              default: withCtx(() => [createElementVNode("div", _hoisted_1$6, [createVNode(unref(RockForm), {
                id: formId,
                onSubmit: onFormSubmitted
              }, {
                default: withCtx(() => [createElementVNode("div", _hoisted_2$6, [createElementVNode("div", _hoisted_3$5, [createVNode(unref(TextBox), {
                  modelValue: unref(internalFromName),
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(internalFromName) ? internalFromName.value = $event : null),
                  help: "<span class='tip tip-lava'></span>",
                  label: "From Name",
                  rules: "required"
                }, null, 8, ["modelValue"])]), createElementVNode("div", _hoisted_4$4, [createVNode(unref(EmailBox), {
                  modelValue: unref(internalFromEmail),
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => isRef(internalFromEmail) ? internalFromEmail.value = $event : null),
                  allowLava: true,
                  help: "<span class='tip tip-lava'></span>",
                  label: "From Address",
                  rules: "required"
                }, null, 8, ["modelValue"])])]), createElementVNode("div", _hoisted_5$4, [createElementVNode("a", {
                  class: "show-options-button",
                  role: "button",
                  onClick: _cache[2] || (_cache[2] = $event => areMoreOptionsShown.value = !areMoreOptionsShown.value)
                }, [createElementVNode("span", _hoisted_6$3, "Show " + toDisplayString(areMoreOptionsShown.value ? 'Less' : 'More') + " Options", 1), createTextVNode(), createElementVNode("i", {
                  class: normalizeClass({
                    'text-color': true,
                    'ti ti-chevron-up': areMoreOptionsShown.value,
                    'ti ti-chevron-down': !areMoreOptionsShown.value
                  })
                }, null, 2)])]), createVNode(unref(TransitionVerticalCollapse), null, {
                  default: withCtx(() => [areMoreOptionsShown.value ? (openBlock(), createBlock(unref(ConditionalWell), {
                    key: 0
                  }, {
                    default: withCtx(() => [createElementVNode("div", _hoisted_7$3, [createElementVNode("div", _hoisted_8$3, [createVNode(unref(EmailBox), {
                      modelValue: unref(internalReplyToEmail),
                      "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => isRef(internalReplyToEmail) ? internalReplyToEmail.value = $event : null),
                      allowLava: true,
                      help: "<span class='tip tip-lava'>",
                      label: "Reply To Address"
                    }, null, 8, ["modelValue"])])]), createElementVNode("div", _hoisted_9$3, [createElementVNode("div", _hoisted_10$3, [createVNode(unref(EmailBox), {
                      modelValue: unref(internalCcEmails),
                      "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => isRef(internalCcEmails) ? internalCcEmails.value = $event : null),
                      allowLava: true,
                      allowMultiple: true,
                      help: "Comma-delimited list of email addresses that will be copied on the email sent to every recipient. Lava can be used to access recipent data. <span class='tip tip-lava'></span>",
                      label: "CC List"
                    }, null, 8, ["modelValue"])]), createElementVNode("div", _hoisted_11$3, [createVNode(unref(EmailBox), {
                      modelValue: unref(internalBccEmails),
                      "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => isRef(internalBccEmails) ? internalBccEmails.value = $event : null),
                      allowLava: true,
                      allowMultiple: true,
                      help: "Comma-delimited list of email addresses that will be blind copied on the email sent to every recipient. Lava can be used to access recipent data. <span class='tip tip-lava'></span>",
                      label: "BCC List"
                    }, null, 8, ["modelValue"])])]), _hoisted_12$3]),
                    _: 1
                  })) : createCommentVNode("v-if", true)]),
                  _: 1
                }), createElementVNode("div", _hoisted_13$3, [createElementVNode("div", _hoisted_14$3, [createVNode(unref(TextBox), {
                  modelValue: unref(internalSubject),
                  "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => isRef(internalSubject) ? internalSubject.value = $event : null),
                  help: "<span class='tip tip-lava'></span>",
                  label: "Email Subject",
                  rules: "required"
                }, null, 8, ["modelValue"]), emailPreviewElement.value ? (openBlock(), createBlock(unref(TextBox), {
                  key: 0,
                  modelValue: emailPreviewText.value,
                  "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => emailPreviewText.value = $event),
                  help: "A short summary of the email which will show in the inbox before the email is opened.",
                  label: "Email Preview Text",
                  textMode: "multiline"
                }, null, 8, ["modelValue"])) : createCommentVNode("v-if", true), createVNode(unref(FileUploader), {
                  modelValue: currentAttachment.value,
                  "onUpdate:modelValue": [_cache[8] || (_cache[8] = $event => currentAttachment.value = $event), onAttachmentAdded],
                  binaryFileTypeGuid: __props.attachmentBinaryFileTypeGuid,
                  label: "Attachments",
                  uploadAsTemporary: true
                }, null, 8, ["modelValue", "binaryFileTypeGuid"]), createElementVNode("div", _hoisted_15$3, [createElementVNode("ul", _hoisted_16$3, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(internalEmailAttachmentBinaryFiles), binaryFileAttachment => {
                  return openBlock(), createElementBlock("li", null, [createElementVNode("a", {
                    href: "/GetFile.ashx?guid=".concat(binaryFileAttachment.value, "&fileName=").concat(binaryFileAttachment.text),
                    target: "_blank",
                    rel: "noopener noreferrer"
                  }, toDisplayString(binaryFileAttachment.text), 9, _hoisted_17$3), createTextVNode(), createElementVNode("a", null, [createElementVNode("i", {
                    class: "ti ti-x",
                    onClick: $event => onAttachmentRemoved(binaryFileAttachment)
                  }, null, 8, _hoisted_18$2)])]);
                }), 256))])])])])]),
                _: 1
              })])]),
              footerActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                onClick: onPreviousClicked
              }, {
                default: withCtx(() => [createTextVNode("Previous")]),
                _: 1
              })), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowLeft']])]),
              footerSecondaryActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                btnType: "primary",
                form: formId,
                type: "submit"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.nextStepTitle ? "Next: ".concat(__props.nextStepTitle) : 'Next'), 1)]),
                _: 1
              })), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowRight']])]),
              _: 1
            }, 8, ["title"])], 512);
          };
        }
      });

      var css_248z$4 = "[data-v-efc8f4fc] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}.panel-body-contents[data-v-efc8f4fc]{flex:1;overflow-x:hidden;overflow-y:auto}.note[data-v-efc8f4fc],.show-options-button[data-v-efc8f4fc]{font-size:var(--font-size-small)}";
      styleInject(css_248z$4);

      script$9.__scopeId = "data-v-efc8f4fc";
      script$9.__file = "src/Communication/CommunicationEntryWizard/emailSettingsStep.partial.obs";

      var _withScopeId$2 = n => (pushScopeId("data-v-50ff2db1"), n = n(), popScopeId(), n);
      var _hoisted_1$5 = {
        class: "push-notification-editor-step"
      };
      var _hoisted_2$5 = {
        class: "push-notification-editor-panel-title"
      };
      var _hoisted_3$4 = {
        class: "push-notification-editor-panel-title-right"
      };
      var _hoisted_4$3 = _withScopeId$2(() => createElementVNode("i", {
        class: "ti ti-x",
        "aria-hidden": "true"
      }, null, -1));
      var _hoisted_5$3 = [_hoisted_4$3];
      var _hoisted_6$2 = {
        class: "panel-body-contents"
      };
      var _hoisted_7$2 = {
        class: "row d-sm-flex"
      };
      var _hoisted_8$2 = {
        class: "col-xs-12 col-sm-5"
      };
      var _hoisted_9$2 = {
        class: "row"
      };
      var _hoisted_10$2 = {
        class: "col-sm-12"
      };
      var _hoisted_11$2 = {
        class: "row"
      };
      var _hoisted_12$2 = {
        class: "col-sm-12"
      };
      var _hoisted_13$2 = {
        class: "row"
      };
      var _hoisted_14$2 = {
        class: "col-sm-12"
      };
      var _hoisted_15$2 = {
        class: "row"
      };
      var _hoisted_16$2 = {
        class: "col-sm-12"
      };
      var _hoisted_17$2 = {
        class: "row"
      };
      var _hoisted_18$1 = {
        class: "col-xs-12"
      };
      var _hoisted_19$1 = {
        class: "col-xs-12 col-sm-7"
      };
      var _hoisted_20$1 = {
        class: "preview-as-wrapper"
      };
      var OpenAction = function (OpenAction) {
        OpenAction["OpenHomepage"] = "Open Homepage";
        OpenAction["SpecificPage"] = "Specific Page";
        OpenAction["ShowDetails"] = "Show Details";
        OpenAction["NoAction"] = "No Action";
        OpenAction["LinkToUrl"] = "Link to URL";
        return OpenAction;
      }(OpenAction || {});
      var script$8 = defineComponent({
        __name: 'pushNotificationEditorStep.partial',
        props: {
          applications: {
            type: Object,
            required: true
          },
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          isUsingRockMobilePushTransport: {
            type: Boolean,
            required: true
          },
          mergeFields: {
            type: Object,
            required: true
          },
          nextStepTitle: {
            type: String,
            required: true
          },
          personalizationSegments: {
            type: Array,
            required: true
          },
          previewAsPersonAlias: {
            type: Object,
            required: true
          },
          previewAsPersonalizationSegment: {
            type: Object,
            required: true
          },
          previewAsType: {
            type: String,
            required: true
          },
          previewProcessor: {
            type: Object,
            required: true
          },
          pushData: {
            type: String,
            required: true
          },
          pushMessage: {
            type: String,
            required: true
          },
          pushOpenAction: {
            type: Number,
            required: true
          },
          pushOpenMessageJson: {
            type: String,
            required: true
          },
          pushTitle: {
            type: String,
            required: true
          },
          recipientsLabel: {
            type: String,
            required: true
          },
          title: {
            type: String,
            required: true
          }
        },
        emits: ["nextStep", "previousStep", "sendTestCommunication", "saveCommunication", "update:communicationTemplateGuid", "update:previewAsPersonAlias", "update:previewAsPersonalizationSegment", "update:previewAsType", "update:pushData", "update:pushMessage", "update:pushOpenAction", "update:pushOpenMessageJson", "update:pushTitle"],
        setup(__props, _ref) {
          var _internalPushData$val, _internalPushData$val2, _internalPushData$val3, _internalPushData$val4, _internalPushData$val5, _internalPushData$val6;
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var formId = "push-editor-form-".concat(newGuid());
          var openActions = computed(() => {
            if (props.isUsingRockMobilePushTransport) {
              return [{
                text: OpenAction.OpenHomepage,
                value: OpenAction.OpenHomepage
              }, {
                text: OpenAction.SpecificPage,
                value: OpenAction.SpecificPage
              }, {
                text: OpenAction.ShowDetails,
                value: OpenAction.ShowDetails
              }];
            } else {
              return [{
                text: OpenAction.NoAction,
                value: OpenAction.NoAction
              }, {
                text: OpenAction.LinkToUrl,
                value: OpenAction.LinkToUrl
              }];
            }
          });
          var breakpointHelper = useBreakpointHelper();
          var saveElement = ref();
          var isSaveSuccessMessageShown = ref(false);
          var isSaving = ref(false);
          var isSendingTest = ref(false);
          var isPreviewLoading = ref(false);
          var internalPreviewAsPersonAlias = useVModelPassthrough(props, "previewAsPersonAlias", emit);
          var internalPreviewAsPersonalizationSegment = useVModelPassthrough(props, "previewAsPersonalizationSegment", emit);
          var internalPreviewAsType = useVModelPassthrough(props, "previewAsType", emit);
          var messagePreview = ref("");
          var internalPushMessage = useVModelPassthrough(props, "pushMessage", emit);
          var internalPushTitle = useVModelPassthrough(props, "pushTitle", emit);
          var internalPushOpenAction = useVModelPassthrough(props, "pushOpenAction", emit);
          var internalPushData = useVModelPassthrough(props, "pushData", emit);
          var mobilePage = ref((_internalPushData$val = internalPushData.value) === null || _internalPushData$val === void 0 ? void 0 : _internalPushData$val.mobilePage);
          var openAction = ref(getOpenAction(internalPushOpenAction.value, props.isUsingRockMobilePushTransport, mobilePage.value));
          var linkToPageUrl = ref((_internalPushData$val2 = (_internalPushData$val3 = internalPushData.value) === null || _internalPushData$val3 === void 0 ? void 0 : _internalPushData$val3.linkToPageUrl) !== null && _internalPushData$val2 !== void 0 ? _internalPushData$val2 : "");
          var mobilePageQueryStringItems = ref(recordAsKeyValueItems((_internalPushData$val4 = internalPushData.value) === null || _internalPushData$val4 === void 0 ? void 0 : _internalPushData$val4.mobilePageQueryString));
          var internalPushOpenMessageJson = useVModelPassthrough(props, "pushOpenMessageJson", emit);
          var mobileApplicationGuidOrEmptyString = ref((_internalPushData$val5 = (_internalPushData$val6 = internalPushData.value) === null || _internalPushData$val6 === void 0 ? void 0 : _internalPushData$val6.mobileApplicationGuid) !== null && _internalPushData$val5 !== void 0 ? _internalPushData$val5 : "");
          var commonMergeFields = ["Person.FirstName^First Name|ti ti-user", "Person.NickName^Nick Name|ti ti-user", "Person.FullName^Full Name|ti ti-user"];
          var refreshPreviewRequestKey = computed(() => {
            var _internalPreviewAsPer, _internalPreviewAsPer2, _internalPreviewAsPer3, _internalPreviewAsPer4;
            return internalPreviewAsType.value === "Preview As Person" ? "person:".concat((_internalPreviewAsPer = (_internalPreviewAsPer2 = internalPreviewAsPersonAlias.value) === null || _internalPreviewAsPer2 === void 0 ? void 0 : _internalPreviewAsPer2.value) !== null && _internalPreviewAsPer !== void 0 ? _internalPreviewAsPer : "") : "segment:".concat((_internalPreviewAsPer3 = (_internalPreviewAsPer4 = internalPreviewAsPersonalizationSegment.value) === null || _internalPreviewAsPer4 === void 0 ? void 0 : _internalPreviewAsPer4.value) !== null && _internalPreviewAsPer3 !== void 0 ? _internalPreviewAsPer3 : "");
          });
          function getOpenAction(pushOpenAction, isUsingRockMobilePushTransport, mobilePage) {
            switch (pushOpenAction) {
              case PushOpenAction.LinkToMobilePage:
                if (mobilePage) {
                  return OpenAction.SpecificPage;
                } else {
                  return OpenAction.OpenHomepage;
                }
              case PushOpenAction.LinkToUrl:
                return OpenAction.LinkToUrl;
              case PushOpenAction.ShowDetails:
                return OpenAction.ShowDetails;
              case PushOpenAction.NoAction:
              default:
                if (isUsingRockMobilePushTransport) {
                  return OpenAction.OpenHomepage;
                } else {
                  return OpenAction.NoAction;
                }
            }
          }
          function recordAsKeyValueItems(record) {
            if (isNullish(record)) {
              return undefined;
            }
            var items = [];
            for (var key in record) {
              if (key) {
                items.push({
                  key,
                  value: record[key]
                });
              }
            }
            return items;
          }
          function keyValueItemsAsRecord(items) {
            if (items === undefined) {
              return undefined;
            }
            var record = {};
            var _iterator = _createForOfIteratorHelper(items),
              _step;
            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var item = _step.value;
                if (item.key && item.value) {
                  record[item.key] = item.value;
                }
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }
            return record;
          }
          function updatePreview() {
            return _updatePreview.apply(this, arguments);
          }
          function _updatePreview() {
            _updatePreview = _asyncToGenerator(function* () {
              var _internalPreviewAsPer5, _internalPreviewAsPer6;
              isPreviewLoading.value = true;
              var previewAsPersonAliasGuid = internalPreviewAsType.value === PreviewAsType.Person ? toGuidOrNull((_internalPreviewAsPer5 = internalPreviewAsPersonAlias.value) === null || _internalPreviewAsPer5 === void 0 ? void 0 : _internalPreviewAsPer5.value) : null;
              var previewAsPersonalizationSegmentId = internalPreviewAsType.value === PreviewAsType.Segment ? toNumberOrNull((_internalPreviewAsPer6 = internalPreviewAsPersonalizationSegment.value) === null || _internalPreviewAsPer6 === void 0 ? void 0 : _internalPreviewAsPer6.value) : null;
              var result = yield props.previewProcessor(internalPushMessage.value, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId);
              messagePreview.value = result !== null && result !== void 0 ? result : "";
              isPreviewLoading.value = false;
            });
            return _updatePreview.apply(this, arguments);
          }
          var updatePreviewDebounced = debounceAsync(function () {
            var _ref2 = _asyncToGenerator(function* (cancellationToken) {
              if (cancellationToken.isCancellationRequested) {
                return;
              }
              yield updatePreview();
            });
            return function (_x) {
              return _ref2.apply(this, arguments);
            };
          }(), {
            delay: 500
          });
          function onUrlUpdated() {
            internalPushData.value = _objectSpread2(_objectSpread2({}, internalPushData.value), {}, {
              linkToPageUrl: linkToPageUrl.value
            });
          }
          function onMobilePageUpdated() {
            internalPushData.value = _objectSpread2(_objectSpread2({}, internalPushData.value), {}, {
              mobilePage: mobilePage.value
            });
          }
          function onMobilePageQueryStringItemsUpdated() {
            internalPushData.value = _objectSpread2(_objectSpread2({}, internalPushData.value), {}, {
              mobilePageQueryString: keyValueItemsAsRecord(mobilePageQueryStringItems.value)
            });
          }
          function onMobileApplicationGuidUpdated() {
            internalPushData.value = _objectSpread2(_objectSpread2({}, internalPushData.value), {}, {
              mobileApplicationGuid: toGuidOrNull(mobileApplicationGuidOrEmptyString.value)
            });
          }
          watch(openAction, () => {
            switch (openAction.value) {
              case OpenAction.LinkToUrl:
                internalPushOpenAction.value = PushOpenAction.LinkToUrl;
                internalPushData.value = {
                  mobileApplicationGuid: toGuidOrNull(mobileApplicationGuidOrEmptyString.value),
                  linkToPageUrl: linkToPageUrl.value
                };
                break;
              case OpenAction.OpenHomepage:
                internalPushOpenAction.value = PushOpenAction.LinkToMobilePage;
                internalPushData.value = {
                  mobileApplicationGuid: toGuidOrNull(mobileApplicationGuidOrEmptyString.value),
                  mobilePage: null
                };
                break;
              case OpenAction.ShowDetails:
                internalPushOpenAction.value = PushOpenAction.ShowDetails;
                internalPushData.value = {
                  mobileApplicationGuid: toGuidOrNull(mobileApplicationGuidOrEmptyString.value)
                };
                break;
              case OpenAction.SpecificPage:
                internalPushOpenAction.value = PushOpenAction.LinkToMobilePage;
                internalPushData.value = {
                  mobileApplicationGuid: toGuidOrNull(mobileApplicationGuidOrEmptyString.value),
                  mobilePage: mobilePage.value,
                  mobilePageQueryString: keyValueItemsAsRecord(mobilePageQueryStringItems.value)
                };
                break;
              case OpenAction.NoAction:
              default:
                internalPushOpenAction.value = PushOpenAction.NoAction;
                internalPushData.value = {
                  mobileApplicationGuid: toGuidOrNull(mobileApplicationGuidOrEmptyString.value)
                };
                break;
            }
          });
          function onPreviousClicked() {
            emit("previousStep");
          }
          function onSaveCommunication() {
            if (isSaving.value) {
              return;
            }
            isSaving.value = true;
            emit("saveCommunication", {
              onSuccess() {
                isSaveSuccessMessageShown.value = true;
                isSaving.value = false;
              },
              onError() {
                isSaving.value = false;
              }
            });
          }
          watch(saveElement, element => {
            if (element) {
              tooltip(element);
            }
          });
          watch(internalPushMessage, _asyncToGenerator(function* () {
            yield updatePreviewDebounced();
          }));
          watch(refreshPreviewRequestKey, _asyncToGenerator(function* () {
            yield updatePreview();
          }));
          updatePreview();
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1$5, [createVNode(unref(Panel), {
              hasFullscreen: true,
              panelBodyCssClass: "panel-body-wizard",
              type: "block"
            }, {
              title: withCtx(() => [createElementVNode("div", _hoisted_2$5, [createElementVNode("span", null, toDisplayString(__props.title), 1), createElementVNode("div", _hoisted_3$4, [isSaveSuccessMessageShown.value ? (openBlock(), createBlock(unref(HighlightLabel), {
                key: 0,
                labelType: "success",
                dismissible: true
              }, {
                default: withCtx(() => [createTextVNode(" The communication has been saved. "), createElementVNode("button", {
                  type: "button",
                  class: "close btn-dismiss-alert",
                  "aria-label": "Hide This Alert",
                  onClick: _cache[0] || (_cache[0] = withModifiers($event => isSaveSuccessMessageShown.value = false, ["prevent"]))
                }, [..._hoisted_5$3])]),
                _: 1
              })) : createCommentVNode("v-if", true), createVNode(unref(HighlightLabel), {
                labelType: "info"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.recipientsLabel), 1)]),
                _: 1
              })])])]),
              headerActions: withCtx(() => [createElementVNode("span", {
                class: "action panel-action-save clickable",
                onClick: onSaveCommunication
              }, [createElementVNode("i", {
                ref_key: "saveElement",
                ref: saveElement,
                "data-toggle": "tooltip",
                title: "Save Draft",
                class: "ti ti-device-floppy"
              }, null, 512)])]),
              default: withCtx(() => [createElementVNode("div", _hoisted_6$2, [createElementVNode("div", _hoisted_7$2, [createElementVNode("div", _hoisted_8$2, [createVNode(unref(RockForm), {
                id: formId,
                onSubmit: _cache[9] || (_cache[9] = $event => _ctx.$emit('nextStep'))
              }, {
                default: withCtx(() => [createElementVNode("div", _hoisted_9$2, [createElementVNode("div", _hoisted_10$2, [createVNode(unref(DropDownList), {
                  modelValue: mobileApplicationGuidOrEmptyString.value,
                  "onUpdate:modelValue": [_cache[1] || (_cache[1] = $event => mobileApplicationGuidOrEmptyString.value = $event), onMobileApplicationGuidUpdated],
                  blankValue: "All Applications",
                  disabled: isSaving.value || isSendingTest.value,
                  items: __props.applications,
                  label: "Application"
                }, null, 8, ["modelValue", "disabled", "items"])])]), createElementVNode("div", _hoisted_11$2, [createElementVNode("div", _hoisted_12$2, [createVNode(unref(TextBox), {
                  modelValue: unref(internalPushTitle),
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => isRef(internalPushTitle) ? internalPushTitle.value = $event : null),
                  disabled: isSaving.value || isSendingTest.value,
                  label: "Title",
                  rules: "required"
                }, null, 8, ["modelValue", "disabled"])])]), createElementVNode("div", _hoisted_13$2, [createElementVNode("div", _hoisted_14$2, [createVNode(unref(SmsMessageEditor), {
                  modelValue: unref(internalPushMessage),
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => isRef(internalPushMessage) ? internalPushMessage.value = $event : null),
                  disabled: isSaving.value || isSendingTest.value,
                  editorHeight: 200,
                  isCharacterCountShown: true,
                  mergeFields: __props.mergeFields,
                  commonMergeFields: commonMergeFields,
                  rules: "required",
                  toolbarLabel: "Push Message"
                }, null, 8, ["modelValue", "disabled", "mergeFields"])])]), createElementVNode("div", _hoisted_15$2, [createElementVNode("div", _hoisted_16$2, [createVNode(unref(RadioButtonList), {
                  modelValue: openAction.value,
                  "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => openAction.value = $event),
                  disabled: isSaving.value || isSendingTest.value,
                  help: "Defines the open action for the message.",
                  horizontal: true,
                  items: openActions.value,
                  label: "Open Action"
                }, null, 8, ["modelValue", "disabled", "items"])])]), createElementVNode("div", _hoisted_17$2, [createElementVNode("div", _hoisted_18$1, [withDirectives(createVNode(unref(ConditionalWell), null, {
                  default: withCtx(() => [createVNode(unref(UrlLinkBox), {
                    modelValue: linkToPageUrl.value,
                    "onUpdate:modelValue": [_cache[5] || (_cache[5] = $event => linkToPageUrl.value = $event), onUrlUpdated],
                    disabled: isSaving.value || isSendingTest.value,
                    label: "URL"
                  }, null, 8, ["modelValue", "disabled"])]),
                  _: 1
                }, 512), [[vShow, openAction.value === OpenAction.LinkToUrl]]), withDirectives(createVNode(unref(ConditionalWell), null, {
                  default: withCtx(() => [createVNode(unref(PagePicker), {
                    modelValue: mobilePage.value,
                    "onUpdate:modelValue": [_cache[6] || (_cache[6] = $event => mobilePage.value = $event), onMobilePageUpdated],
                    disabled: isSaving.value || isSendingTest.value,
                    label: "Mobile Page",
                    siteType: unref(SiteType).Mobile
                  }, null, 8, ["modelValue", "disabled", "siteType"]), createVNode(unref(KeyValueList), {
                    modelValue: mobilePageQueryStringItems.value,
                    "onUpdate:modelValue": [_cache[7] || (_cache[7] = $event => mobilePageQueryStringItems.value = $event), onMobilePageQueryStringItemsUpdated],
                    disabled: isSaving.value || isSendingTest.value,
                    label: "Mobile Page Query String",
                    keyPlaceholder: "Key",
                    valuePlaceholder: "Value"
                  }, null, 8, ["modelValue", "disabled"])]),
                  _: 1
                }, 512), [[vShow, openAction.value === OpenAction.SpecificPage]]), withDirectives(createVNode(unref(ConditionalWell), null, {
                  default: withCtx(() => [createVNode(unref(StructuredContentEditor), {
                    modelValue: unref(internalPushOpenMessageJson),
                    "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => isRef(internalPushOpenMessageJson) ? internalPushOpenMessageJson.value = $event : null),
                    disabled: isSaving.value || isSendingTest.value,
                    label: "Additional Information"
                  }, null, 8, ["modelValue", "disabled"])]),
                  _: 1
                }, 512), [[vShow, openAction.value === OpenAction.ShowDetails]])])])]),
                _: 1
              })]), createElementVNode("div", _hoisted_19$1, [createElementVNode("div", _hoisted_20$1, [createVNode(unref(script$b), {
                previewAsType: unref(internalPreviewAsType),
                "onUpdate:previewAsType": _cache[10] || (_cache[10] = $event => isRef(internalPreviewAsType) ? internalPreviewAsType.value = $event : null),
                previewAsPersonAlias: unref(internalPreviewAsPersonAlias),
                "onUpdate:previewAsPersonAlias": _cache[11] || (_cache[11] = $event => isRef(internalPreviewAsPersonAlias) ? internalPreviewAsPersonAlias.value = $event : null),
                personalizationSegment: unref(internalPreviewAsPersonalizationSegment),
                "onUpdate:personalizationSegment": _cache[12] || (_cache[12] = $event => isRef(internalPreviewAsPersonalizationSegment) ? internalPreviewAsPersonalizationSegment.value = $event : null),
                isPreviewLoading: isPreviewLoading.value,
                personalizationSegments: __props.personalizationSegments
              }, null, 8, ["previewAsType", "previewAsPersonAlias", "personalizationSegment", "isPreviewLoading", "personalizationSegments"])]), createVNode(unref(PushNotificationMobilePreview), {
                class: normalizeClass(unref(breakpointHelper).breakpoint),
                isLoading: isPreviewLoading.value,
                pushTitle: unref(internalPushTitle),
                pushMessage: messagePreview.value
              }, null, 8, ["class", "isLoading", "pushTitle", "pushMessage"])])])])]),
              footerActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                disabled: isSaving.value || isSendingTest.value,
                onClick: _cache[13] || (_cache[13] = $event => onPreviousClicked())
              }, {
                default: withCtx(() => [createTextVNode("Previous")]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowLeft']])]),
              footerSecondaryActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                btnType: "primary",
                disabled: isSaving.value || isSendingTest.value,
                form: formId,
                type: "submit"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.nextStepTitle ? "Next: ".concat(__props.nextStepTitle) : 'Next'), 1)]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowRight']])]),
              _: 1
            }), createVNode(unref(script$d), {
              isVisible: isSaving.value || isSendingTest.value,
              targetSelector: ".push-notification-editor-step"
            }, null, 8, ["isVisible"])]);
          };
        }
      });

      var css_248z$3 = "[data-v-50ff2db1] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}.panel-body-contents[data-v-50ff2db1]{flex:1;overflow-x:hidden;overflow-y:auto}[data-v-50ff2db1] .panel-sub-header{background-color:var(--color-interface-softer);border-color:var(--color-interface-soft)}.preview-as-wrapper[data-v-50ff2db1]{background-color:var(--color-interface-softest);margin-left:calc(0px - var(--panel-body-padding));margin-right:calc(0px - var(--panel-body-padding));padding:var(--spacing-medium);padding-left:var(--panel-body-padding);padding-right:var(--panel-body-padding)}.push-notification-editor-panel-title[data-v-50ff2db1]{align-items:center;display:flex;justify-content:space-between}.push-notification-editor-panel-title-right[data-v-50ff2db1]{align-items:center;display:flex;flex-direction:row;gap:var(--spacing-medium)}.btn-dismiss-alert[data-v-50ff2db1]{font-size:var(--font-size-xsmall)}.btn-dismiss-alert.close i[data-v-50ff2db1]{display:inline-block}[data-v-50ff2db1] .confirmation-preview-panel{margin-left:calc(0px - var(--panel-body-padding));margin-right:calc(0px - var(--panel-body-padding))}[data-v-50ff2db1] .confirmation-preview-panel.xs{background:none;margin-bottom:0;margin-top:0;padding:0}";
      styleInject(css_248z$3);

      script$8.__scopeId = "data-v-50ff2db1";
      script$8.__file = "src/Communication/CommunicationEntryWizard/pushNotificationEditorStep.partial.obs";

      var script$7 = defineComponent({
        __name: 'savedStep.partial',
        props: {
          finalMessage: {
            type: String,
            required: true
          },
          finalMessageAlertType: {
            type: String,
            required: true
          },
          hasDetailBlockOnCurrentPage: {
            type: Boolean,
            required: true
          }
        },
        emits: ["viewCommunication"],
        setup(__props) {
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(Panel), {
              hasTitle: false
            }, createSlots({
              default: withCtx(() => [createVNode(unref(NotificationBox), {
                alertType: __props.finalMessageAlertType
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.finalMessage), 1)]),
                _: 1
              }, 8, ["alertType"])]),
              _: 2
            }, [__props.hasDetailBlockOnCurrentPage ? {
              name: "footerActions",
              fn: withCtx(() => [createVNode(unref(RockButton), {
                btnType: "primary",
                onClick: _cache[0] || (_cache[0] = $event => _ctx.$emit('viewCommunication'))
              }, {
                default: withCtx(() => [createTextVNode("View Communication")]),
                _: 1
              })]),
              key: "0"
            } : undefined]), 1024);
          };
        }
      });

      script$7.__file = "src/Communication/CommunicationEntryWizard/savedStep.partial.obs";

      var _hoisted_1$4 = {
        class: "row"
      };
      var _hoisted_2$4 = {
        class: "col-sm-6"
      };
      var _hoisted_3$3 = {
        class: "col-sm-6"
      };
      var script$6 = defineComponent({
        __name: 'saveCommunicationTemplateModal.partial',
        props: {
          modelValue: {
            type: Boolean,
            required: true
          },
          api: {
            type: Object,
            required: false
          },
          communicationTemplate: {
            type: Object,
            required: true
          },
          bodyWidth: {
            type: Number
          }
        },
        emits: ["save", "saveAs", "cancel", "update:modelValue"],
        setup(__props, _ref) {
          var _props$communicationT;
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var internalValue = useVModelPassthrough(props, "modelValue", emit);
          var saveError = ref();
          var isSaving = ref(false);
          var mode = ref("saveAs");
          var name = ref(props.communicationTemplate.name ? truncate("Copy of ".concat(props.communicationTemplate.name), 100) : "");
          var description = ref((_props$communicationT = props.communicationTemplate.description) !== null && _props$communicationT !== void 0 ? _props$communicationT : "");
          var category = ref(props.communicationTemplate.category);
          var isStarter = ref(props.communicationTemplate.isStarter);
          var modes = computed(() => {
            if (props.communicationTemplate.isSystem) {
              return [{
                text: "Save As New Template",
                value: get("saveAs")
              }];
            } else {
              return [{
                text: "Overwrite Existing Template",
                value: get("save")
              }, {
                text: "Save As New Template",
                value: get("saveAs")
              }];
            }
          });
          var originalName = computed(() => {
            var _props$communicationT2;
            return (_props$communicationT2 = props.communicationTemplate.name) !== null && _props$communicationT2 !== void 0 ? _props$communicationT2 : "";
          });
          var originalDescription = computed(() => {
            var _props$communicationT3;
            return (_props$communicationT3 = props.communicationTemplate.description) !== null && _props$communicationT3 !== void 0 ? _props$communicationT3 : "";
          });
          var originalCategoryText = computed(() => {
            var _props$communicationT4, _props$communicationT5;
            return (_props$communicationT4 = (_props$communicationT5 = props.communicationTemplate.category) === null || _props$communicationT5 === void 0 ? void 0 : _props$communicationT5.text) !== null && _props$communicationT4 !== void 0 ? _props$communicationT4 : "";
          });
          function getFileName(name) {
            return "communication_template_preview_".concat(name.replace(" ", "_"), ".png");
          }
          function useTemporaryRenderElement(callback) {
            var tempRenderElement;
            try {
              var _props$communicationT6, _props$communicationT7;
              tempRenderElement = document.createElement("iframe");
              tempRenderElement.onload = _asyncToGenerator(function* () {
                var _tempRenderElement;
                yield callback(tempRenderElement.contentDocument.body);
                (_tempRenderElement = tempRenderElement) === null || _tempRenderElement === void 0 || _tempRenderElement.remove();
              });
              tempRenderElement.srcdoc = (_props$communicationT6 = (_props$communicationT7 = props.communicationTemplate) === null || _props$communicationT7 === void 0 ? void 0 : _props$communicationT7.message) !== null && _props$communicationT6 !== void 0 ? _props$communicationT6 : "";
              document.body.append(tempRenderElement);
            } catch (_unused) {
              var _tempRenderElement2;
              (_tempRenderElement2 = tempRenderElement) === null || _tempRenderElement2 === void 0 || _tempRenderElement2.remove();
            }
          }
          function onSaveClicked() {
            return _onSaveClicked.apply(this, arguments);
          }
          function _onSaveClicked() {
            _onSaveClicked = _asyncToGenerator(function* () {
              saveError.value = null;
              useTemporaryRenderElement(function () {
                var _ref3 = _asyncToGenerator(function* (tempElement) {
                  if (!props.api) {
                    saveError.value = "You don't have access to create the template preview image.";
                    return;
                  }
                  try {
                    var _props$bodyWidth;
                    isSaving.value = true;
                    saveError.value = null;
                    var thumbnailInfo = yield props.api.createBinaryFileImageFromElement({
                      element: tempElement,
                      fileName: getFileName(name.value),
                      elementWidth: (_props$bodyWidth = props.bodyWidth) !== null && _props$bodyWidth !== void 0 ? _props$bodyWidth : undefined,
                      binaryFileTypeGuid: BinaryFiletype.Default
                    });
                    var bag = _objectSpread2(_objectSpread2({}, props.communicationTemplate), {}, {
                      imageFile: thumbnailInfo.binaryFile
                    });
                    var blockActionCallbacks = {
                      onError(error) {
                        isSaving.value = false;
                        saveError.value = error !== null && error !== void 0 ? error : "Unable to save the template.";
                      },
                      onSuccess() {
                        internalValue.value = false;
                        isSaving.value = false;
                      }
                    };
                    if (mode.value === "saveAs") {
                      bag.category = category.value;
                      bag.name = name.value;
                      bag.description = description.value;
                      bag.isStarter = isStarter.value;
                      emit("saveAs", bag, blockActionCallbacks);
                    } else {
                      emit("save", bag, blockActionCallbacks);
                    }
                  } catch (_unused2) {
                    isSaving.value = false;
                    saveError.value = "You don't have access to create the template preview image.";
                  }
                });
                return function (_x) {
                  return _ref3.apply(this, arguments);
                };
              }());
            });
            return _onSaveClicked.apply(this, arguments);
          }
          function onCancelClicked() {
            internalValue.value = false;
            emit("cancel");
          }
          watch(internalValue, newValue => {
            if (newValue) {
              var _props$communicationT8;
              name.value = props.communicationTemplate.name ? truncate("Copy of ".concat(props.communicationTemplate.name), 100) : "";
              description.value = (_props$communicationT8 = props.communicationTemplate.description) !== null && _props$communicationT8 !== void 0 ? _props$communicationT8 : "";
              category.value = props.communicationTemplate.category;
              isStarter.value = props.communicationTemplate.isStarter;
            } else {
              name.value = "";
              description.value = "";
              category.value = null;
              isStarter.value = false;
            }
          });
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(Modal), {
              modelValue: unref(internalValue),
              "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => isRef(internalValue) ? internalValue.value = $event : null),
              cancelText: isSaving.value ? '' : 'Cancel',
              isSaveButtonDisabled: isSaving.value,
              isCloseButtonHidden: isSaving.value,
              saveText: "Save",
              title: "Save As Template",
              onSave: onSaveClicked,
              onCloseModal: onCancelClicked
            }, {
              default: withCtx(() => [modes.value.length > 1 ? (openBlock(), createBlock(unref(ButtonGroup), {
                key: 0,
                modelValue: mode.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => mode.value = $event),
                items: modes.value
              }, null, 8, ["modelValue", "items"])) : createCommentVNode("v-if", true), mode.value === 'saveAs' ? (openBlock(), createElementBlock(Fragment, {
                key: 1
              }, [createVNode(unref(TextBox), {
                modelValue: name.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => name.value = $event),
                disabled: isSaving.value,
                label: "Name",
                placeholder: "New Template",
                rules: "required"
              }, null, 8, ["modelValue", "disabled"]), createVNode(unref(TextBox), {
                modelValue: description.value,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => description.value = $event),
                disabled: isSaving.value,
                label: "Description",
                textMode: "multiline"
              }, null, 8, ["modelValue", "disabled"]), createElementVNode("div", _hoisted_1$4, [createElementVNode("div", _hoisted_2$4, [createVNode(unref(CategoryPicker), {
                modelValue: category.value,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => category.value = $event),
                blankValue: "Select Category",
                disabled: isSaving.value,
                entityTypeGuid: unref(EntityType).CommunicationTemplate,
                label: "Category",
                rules: "required"
              }, null, 8, ["modelValue", "disabled", "entityTypeGuid"])]), createElementVNode("div", _hoisted_3$3, [createVNode(unref(CheckBox), {
                modelValue: isStarter.value,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => isStarter.value = $event),
                help: "Starter templates appear at the top of the selection screen for the selected category.",
                label: "Starter"
              }, null, 8, ["modelValue"])])])], 64)) : mode.value === 'save' ? (openBlock(), createElementBlock(Fragment, {
                key: 2
              }, [createVNode(unref(StaticFormControl), {
                modelValue: originalName.value,
                label: "Name"
              }, null, 8, ["modelValue"]), createVNode(unref(StaticFormControl), {
                modelValue: originalDescription.value,
                label: "Description"
              }, null, 8, ["modelValue"]), createVNode(unref(StaticFormControl), {
                modelValue: originalCategoryText.value,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => originalCategoryText.value = $event),
                label: "Category"
              }, null, 8, ["modelValue"])], 64)) : (openBlock(), createElementBlock(Fragment, {
                key: 3
              }, [createCommentVNode("v-if", true), createTextVNode(" Please close this window and try again. ")], 64)), saveError.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 4,
                alertType: "warning"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(saveError.value), 1)]),
                _: 1
              })) : createCommentVNode("v-if", true)]),
              _: 1
            }, 8, ["modelValue", "cancelText", "isSaveButtonDisabled", "isCloseButtonHidden"]);
          };
        }
      });

      script$6.__file = "src/Communication/CommunicationEntryWizard/saveCommunicationTemplateModal.partial.obs";

      var _hoisted_1$3 = {
        class: "panel"
      };
      var _hoisted_2$3 = createElementVNode("div", {
        class: "panel-heading"
      }, [createElementVNode("p", null, "Your communication is being created. This may take some time for a large number of recipients...")], -1);
      var _hoisted_3$2 = {
        class: "panel-body"
      };
      var _hoisted_4$2 = createElementVNode("span", {
        class: "mr-1"
      }, [createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-spin"
      })], -1);
      var _hoisted_5$2 = {
        key: 0,
        class: "mt-1"
      };
      var script$5 = defineComponent({
        __name: 'sendingStep.partial',
        props: {
          sendingProgressMessage: {
            type: String,
            required: true
          },
          completionPercentage: {
            type: Number,
            required: true
          }
        },
        setup(__props) {
          var props = __props;
          var isProgressBarShown = ref(false);
          var message = computed(() => {
            return props.sendingProgressMessage || "Loading...";
          });
          onMounted(() => {
            setTimeout(() => {
              isProgressBarShown.value = true;
            }, 5000);
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1$3, [_hoisted_2$3, createElementVNode("div", _hoisted_3$2, [createElementVNode("div", null, [_hoisted_4$2, createElementVNode("span", null, toDisplayString(message.value), 1)]), isProgressBarShown.value ? (openBlock(), createElementBlock("div", _hoisted_5$2, [createVNode(unref(ProgressBar), {
              percent: __props.completionPercentage,
              showCompletionText: true
            }, null, 8, ["percent"])])) : createCommentVNode("v-if", true)])]);
          };
        }
      });

      script$5.__file = "src/Communication/CommunicationEntryWizard/sendingStep.partial.obs";

      var script$4 = defineComponent({
        __name: 'sentStep.partial',
        props: {
          allowedMediums: {
            type: Object,
            required: true
          },
          communicationType: {
            type: Number,
            required: true
          },
          finalMessage: {
            type: String,
            required: true
          },
          finalMessageAlertType: {
            type: String,
            required: true
          },
          hasDetailBlockOnCurrentPage: {
            type: Boolean,
            required: true
          }
        },
        emits: ["saveEmailAnalytics", "cancelEmailAnalytics", "viewCommunication", "newCommunication"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var emit = __emit;
          var isEmailAnalyticsEnabled = ref(false);
          var daysFromNow = ref(1);
          var isAnalyticsSaving = ref(false);
          var isAnalyticsSaved = ref(false);
          var isAnalyticsCancelling = ref(false);
          var errorMessage = ref();
          function onSaveEmailAnayltics() {
            errorMessage.value = null;
            isAnalyticsSaving.value = true;
            isAnalyticsSaved.value = false;
            emit("saveEmailAnalytics", daysFromNow.value, {
              onSuccess() {
                isAnalyticsSaving.value = false;
                isAnalyticsSaved.value = true;
              },
              onError(error) {
                errorMessage.value = error;
                isAnalyticsSaving.value = false;
              }
            });
          }
          function onCancelEmailAnalytics() {
            errorMessage.value = null;
            isAnalyticsCancelling.value = true;
            emit("cancelEmailAnalytics", {
              onSuccess() {
                isAnalyticsSaved.value = false;
                isAnalyticsCancelling.value = false;
              },
              onError(error) {
                errorMessage.value = error;
                isAnalyticsCancelling.value = false;
              }
            });
          }
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(Panel), {
              hasTitle: false
            }, {
              footerActions: withCtx(() => [__props.hasDetailBlockOnCurrentPage ? (openBlock(), createBlock(unref(RockButton), {
                key: 0,
                btnType: "primary",
                onClick: _cache[2] || (_cache[2] = $event => _ctx.$emit('viewCommunication'))
              }, {
                default: withCtx(() => [createTextVNode("View Communication")]),
                _: 1
              })) : createCommentVNode("v-if", true), createVNode(unref(RockButton), {
                onClick: _cache[3] || (_cache[3] = $event => _ctx.$emit('newCommunication'))
              }, {
                default: withCtx(() => [createTextVNode("Create New Communication")]),
                _: 1
              })]),
              default: withCtx(() => [createVNode(unref(NotificationBox), {
                alertType: __props.finalMessageAlertType
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.finalMessage), 1)]),
                _: 1
              }, 8, ["alertType"]), __props.communicationType === unref(CommunicationType).Email || __props.communicationType === unref(CommunicationType).RecipientPreference && __props.allowedMediums.includes(unref(CommunicationType).Email) ? (openBlock(), createBlock(unref(ConditionalWell), {
                key: 0
              }, {
                default: withCtx(() => [!isAnalyticsSaved.value ? (openBlock(), createElementBlock(Fragment, {
                  key: 0
                }, [createVNode(unref(Switch), {
                  modelValue: isEmailAnalyticsEnabled.value,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isEmailAnalyticsEnabled.value = $event),
                  help: "Turn this on to receive an email with basic performance analytics. Note: analytics only available for email medium.",
                  label: "Email Performance Analytics To Me",
                  text: isEmailAnalyticsEnabled.value ? 'No' : 'Yes'
                }, null, 8, ["modelValue", "text"]), isEmailAnalyticsEnabled.value ? (openBlock(), createBlock(unref(RockForm), {
                  key: 0,
                  onSubmit: onSaveEmailAnayltics
                }, {
                  default: withCtx(() => [createVNode(unref(NumberBox), {
                    modelValue: daysFromNow.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => daysFromNow.value = $event),
                    help: "This date/time will be the trigger for the report to send. Required if enabled.",
                    label: "Days From Now",
                    rules: "required"
                  }, null, 8, ["modelValue"]), errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
                    key: 0,
                    alertType: "danger"
                  }, {
                    default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
                    _: 1
                  })) : createCommentVNode("v-if", true), createVNode(unref(RockButton), {
                    btnType: "link",
                    class: "text-primary",
                    type: "submit"
                  }, {
                    default: withCtx(() => [createTextVNode("Save")]),
                    _: 1
                  })]),
                  _: 1
                })) : createCommentVNode("v-if", true)], 64)) : (openBlock(), createElementBlock(Fragment, {
                  key: 1
                }, [createElementVNode("p", null, "You will receive a reminder email in " + toDisplayString(daysFromNow.value) + " " + toDisplayString(unref(pluralize)("day", daysFromNow.value)) + " to assess the impact of your message in terms of opens and click-throughs.", 1), errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
                  key: 0,
                  alertType: "danger"
                }, {
                  default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
                  _: 1
                })) : createCommentVNode("v-if", true), createVNode(unref(RockButton), {
                  btnType: "link",
                  onClick: onCancelEmailAnalytics
                }, {
                  default: withCtx(() => [createTextVNode("Cancel")]),
                  _: 1
                })], 64))]),
                _: 1
              })) : createCommentVNode("v-if", true)]),
              _: 1
            });
          };
        }
      });

      script$4.__file = "src/Communication/CommunicationEntryWizard/sentStep.partial.obs";

      var _withScopeId$1 = n => (pushScopeId("data-v-13d4c4c9"), n = n(), popScopeId(), n);
      var _hoisted_1$2 = {
        class: "sms-editor-step"
      };
      var _hoisted_2$2 = {
        class: "sms-editor-panel-title"
      };
      var _hoisted_3$1 = {
        class: "sms-editor-panel-title-right"
      };
      var _hoisted_4$1 = _withScopeId$1(() => createElementVNode("i", {
        class: "ti ti-x",
        "aria-hidden": "true"
      }, null, -1));
      var _hoisted_5$1 = [_hoisted_4$1];
      var _hoisted_6$1 = {
        class: "panel-body-contents"
      };
      var _hoisted_7$1 = {
        class: "row d-sm-flex"
      };
      var _hoisted_8$1 = {
        class: "col-xs-12 col-sm-5"
      };
      var _hoisted_9$1 = {
        class: "row"
      };
      var _hoisted_10$1 = {
        class: "col-sm-12"
      };
      var _hoisted_11$1 = {
        class: "row"
      };
      var _hoisted_12$1 = {
        class: "col-sm-12"
      };
      var _hoisted_13$1 = {
        class: "row"
      };
      var _hoisted_14$1 = {
        class: "col-sm-12"
      };
      var _hoisted_15$1 = {
        class: "col-xs-12 col-sm-7"
      };
      var _hoisted_16$1 = {
        class: "preview-as-wrapper"
      };
      var _hoisted_17$1 = _withScopeId$1(() => createElementVNode("i", {
        class: "ti ti-send"
      }, null, -1));
      var script$3 = defineComponent({
        __name: 'smsEditorStep.partial',
        props: {
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          attachmentBinaryFileTypeGuid: {
            type: String,
            required: true
          },
          maxImageWidth: {
            type: Number,
            required: true
          },
          mergeFields: {
            type: Object,
            required: true
          },
          message: {
            type: String,
            required: true
          },
          nextStepTitle: {
            type: String,
            required: true
          },
          personalizationSegments: {
            type: Array,
            required: true
          },
          previewAsPersonAlias: {
            type: Object,
            required: true
          },
          previewAsPersonalizationSegment: {
            type: Object,
            required: true
          },
          previewAsType: {
            type: String,
            required: true
          },
          previewProcessor: {
            type: Object,
            required: true
          },
          recipientsLabel: {
            type: String,
            required: true
          },
          shortLinkCheckToken: {
            type: Object,
            required: true
          },
          shortLinkGetPageId: {
            type: Object,
            required: true
          },
          shortLinkSites: {
            type: Object,
            required: true
          },
          shortLinkTokenMinLength: {
            type: Number
          },
          smsAcceptedMimeTypes: {
            type: Object,
            required: true
          },
          smsAttachmentBinaryFiles: {
            type: Object,
            required: true
          },
          smsAttachmentLinks: {
            type: Object,
            required: true
          },
          smsFromNumbers: {
            type: Object,
            required: true
          },
          smsFromNumberName: {
            type: String,
            required: true
          },
          smsFromSystemPhoneNumberGuid: {
            type: String,
            required: true
          },
          smsMediaSizeLimitBytes: {
            type: Number,
            required: true
          },
          smsSupportedMimeTypes: {
            type: Object,
            required: true
          },
          testSmsPhoneNumber: {
            type: String,
            required: true
          },
          title: {
            type: String,
            required: true
          }
        },
        emits: ["nextStep", "previousStep", "sendTestCommunication", "saveCommunication", "update:communicationTemplateGuid", "update:message", "update:previewAsPersonAlias", "update:previewAsPersonalizationSegment", "update:previewAsType", "update:smsFromSystemPhoneNumberGuid", "update:smsAttachmentBinaryFiles", "update:testSmsPhoneNumber"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var breakpointHelper = useBreakpointHelper();
          var isSaving = ref(false);
          var isSendingTest = ref(false);
          var isSendTestModalShown = ref(false);
          var isSaveSuccessMessageShown = ref(false);
          var currentAttachment = ref();
          var saveElement = ref();
          var mimeTypeAlertType = ref("default");
          var mimeTypeMessageHtml = ref();
          var attachmentSizeMessage = ref();
          var submitTrigger = ref(false);
          var submitAction = ref("next");
          var isPreviewLoading = ref(false);
          var internalPreviewAsPersonAlias = useVModelPassthrough(props, "previewAsPersonAlias", emit);
          var internalPreviewAsPersonalizationSegment = useVModelPassthrough(props, "previewAsPersonalizationSegment", emit);
          var internalPreviewAsType = useVModelPassthrough(props, "previewAsType", emit);
          var messagePreview = ref("");
          var internalMessage = useVModelPassthrough(props, "message", emit);
          var internalSmsFromSystemPhoneNumberGuid = useVModelPassthrough(props, "smsFromSystemPhoneNumberGuid", emit);
          var internalTestSmsPhoneNumber = useVModelPassthrough(props, "testSmsPhoneNumber", emit);
          var internalSmsAttachmentBinaryFiles = useVModelPassthrough(props, "smsAttachmentBinaryFiles", emit);
          var commonMergeFields = ["Person.FirstName^First Name|ti ti-user", "Person.NickName^Nick Name|ti ti-user", "Person.FullName^Full Name|ti ti-user"];
          var refreshPreviewRequestKey = computed(() => {
            var _internalPreviewAsPer, _internalPreviewAsPer2, _internalPreviewAsPer3, _internalPreviewAsPer4;
            return internalPreviewAsType.value === "Preview As Person" ? "person:".concat((_internalPreviewAsPer = (_internalPreviewAsPer2 = internalPreviewAsPersonAlias.value) === null || _internalPreviewAsPer2 === void 0 ? void 0 : _internalPreviewAsPer2.value) !== null && _internalPreviewAsPer !== void 0 ? _internalPreviewAsPer : "") : "segment:".concat((_internalPreviewAsPer3 = (_internalPreviewAsPer4 = internalPreviewAsPersonalizationSegment.value) === null || _internalPreviewAsPer4 === void 0 ? void 0 : _internalPreviewAsPer4.value) !== null && _internalPreviewAsPer3 !== void 0 ? _internalPreviewAsPer3 : "");
          });
          var smsAttachmentFileProcessor = computed(() => {
            var resizer = resizeImageFileProcessor({
              maxWidth: props.maxImageWidth
            });
            function getSupportedImageTypes() {
              var _props$smsSupportedMi, _props$smsSupportedMi2;
              return (_props$smsSupportedMi = (_props$smsSupportedMi2 = props.smsSupportedMimeTypes) === null || _props$smsSupportedMi2 === void 0 ? void 0 : _props$smsSupportedMi2.map(mt => mt.toLowerCase()).filter(mt => mt.startsWith("image/")).map(mt => mt.split("/")[1])) !== null && _props$smsSupportedMi !== void 0 ? _props$smsSupportedMi : [];
            }
            return function () {
              var _ref2 = _asyncToGenerator(function* (file) {
                var _props$smsSupportedMi3, _props$smsAcceptedMim;
                if ((_props$smsSupportedMi3 = props.smsSupportedMimeTypes) !== null && _props$smsSupportedMi3 !== void 0 && _props$smsSupportedMi3.some(mt => mt.toLowerCase() === file.type.toLowerCase())) {
                  mimeTypeMessageHtml.value = null;
                } else if ((_props$smsAcceptedMim = props.smsAcceptedMimeTypes) !== null && _props$smsAcceptedMim !== void 0 && _props$smsAcceptedMim.some(mt => mt.toLowerCase() === file.type.toLowerCase())) {
                  var supportedImageTypes = getSupportedImageTypes();
                  mimeTypeAlertType.value = "info";
                  mimeTypeMessageHtml.value = "When sending attachments with MMS; ".concat(supportedImageTypes.length ? asCommaAnd(supportedImageTypes) : "no", " images are supported by all carriers. Files of type <small>").concat(file.type, "</small> are also accepted, but support is dependent upon each carrier and device. So make sure to test sending this to different carriers and phone types to see if it will work as expected.");
                } else {
                  var _supportedImageTypes = getSupportedImageTypes();
                  mimeTypeAlertType.value = "warning";
                  mimeTypeMessageHtml.value = "When sending attachments with MMS; ".concat(_supportedImageTypes.length ? asCommaAnd(_supportedImageTypes) : "no", " images are supported by all carriers. However, files of type <small>").concat(file.type, "</small> might not be accepted, and support is dependent upon each carrier and device. So make sure to test sending this to different carriers and phone types to see if it will work as expected.");
                }
                var resizedFile = resizer(file);
                if (isPromise(resizedFile)) {
                  resizedFile = yield resizedFile;
                }
                if (resizedFile.size > props.smsMediaSizeLimitBytes) {
                  attachmentSizeMessage.value = "The attached file is ".concat(resizedFile.size / 1024 / 1024, "MB, which is over the ").concat(props.smsMediaSizeLimitBytes / 1024 / 1024, "MB media size limit.");
                } else {
                  attachmentSizeMessage.value = null;
                }
                return resizedFile;
              });
              return function (_x) {
                return _ref2.apply(this, arguments);
              };
            }();
          });
          var smsFromSystemPhoneNumberGuidOrEmptyString = computed({
            get() {
              var _internalSmsFromSyste;
              return (_internalSmsFromSyste = internalSmsFromSystemPhoneNumberGuid.value) !== null && _internalSmsFromSyste !== void 0 ? _internalSmsFromSyste : "";
            },
            set(value) {
              internalSmsFromSystemPhoneNumberGuid.value = toGuidOrNull(value);
            }
          });
          var testSmsPhoneNumberOrEmptyString = computed({
            get() {
              var _internalTestSmsPhone;
              return (_internalTestSmsPhone = internalTestSmsPhoneNumber.value) !== null && _internalTestSmsPhone !== void 0 ? _internalTestSmsPhone : "";
            },
            set(value) {
              internalTestSmsPhoneNumber.value = value || null;
            }
          });
          function onSendTestClicked() {
            submitAction.value = "sendTest";
            submitTrigger.value = true;
          }
          function onNextClicked() {
            submitAction.value = "next";
            submitTrigger.value = true;
          }
          function onFormSubmitted() {
            switch (submitAction.value) {
              case "next":
                emit("nextStep");
                break;
              case "sendTest":
                isSendTestModalShown.value = true;
                break;
            }
          }
          function onSendTestCommunication() {
            if (isSendingTest.value) {
              return;
            }
            isSendingTest.value = true;
            emit("sendTestCommunication", {
              onSuccess() {
                isSendingTest.value = false;
              },
              onError() {
                isSendingTest.value = false;
              }
            });
            isSendTestModalShown.value = false;
          }
          function onPreviousClicked() {
            emit("previousStep");
          }
          function onSaveCommunication() {
            if (isSaving.value) {
              return;
            }
            isSaving.value = true;
            emit("saveCommunication", {
              onSuccess() {
                isSaveSuccessMessageShown.value = true;
                isSaving.value = false;
              },
              onError() {
                isSaving.value = false;
              }
            });
          }
          function onAttachmentAdded(attachment) {
            if (isNullish(attachment)) {
              attachmentSizeMessage.value = null;
              mimeTypeMessageHtml.value = null;
              return;
            }
            internalSmsAttachmentBinaryFiles.value = [attachment];
          }
          function updatePreview() {
            return _updatePreview.apply(this, arguments);
          }
          function _updatePreview() {
            _updatePreview = _asyncToGenerator(function* () {
              var _internalPreviewAsPer5, _internalPreviewAsPer6;
              isPreviewLoading.value = true;
              var previewAsPersonAliasGuid = internalPreviewAsType.value === PreviewAsType.Person ? toGuidOrNull((_internalPreviewAsPer5 = internalPreviewAsPersonAlias.value) === null || _internalPreviewAsPer5 === void 0 ? void 0 : _internalPreviewAsPer5.value) : null;
              var previewAsPersonalizationSegmentId = internalPreviewAsType.value === PreviewAsType.Segment ? toNumberOrNull((_internalPreviewAsPer6 = internalPreviewAsPersonalizationSegment.value) === null || _internalPreviewAsPer6 === void 0 ? void 0 : _internalPreviewAsPer6.value) : null;
              var result = yield props.previewProcessor(internalMessage.value, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId);
              messagePreview.value = result !== null && result !== void 0 ? result : "";
              isPreviewLoading.value = false;
            });
            return _updatePreview.apply(this, arguments);
          }
          var updatePreviewDebounced = debounceAsync(function () {
            var _ref3 = _asyncToGenerator(function* (cancellationToken) {
              if (cancellationToken.isCancellationRequested) {
                return;
              }
              yield updatePreview();
            });
            return function (_x2) {
              return _ref3.apply(this, arguments);
            };
          }(), {
            delay: 500
          });
          watch(saveElement, element => {
            if (element) {
              tooltip(element);
            }
          });
          watch(internalMessage, _asyncToGenerator(function* () {
            yield updatePreviewDebounced();
          }));
          watch(refreshPreviewRequestKey, _asyncToGenerator(function* () {
            yield updatePreview();
          }));
          updatePreview();
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1$2, [createVNode(unref(Panel), {
              hasFullscreen: "",
              panelBodyCssClass: "panel-body-wizard",
              type: "block"
            }, {
              title: withCtx(() => [createElementVNode("div", _hoisted_2$2, [createElementVNode("span", null, toDisplayString(__props.title), 1), createElementVNode("div", _hoisted_3$1, [isSaveSuccessMessageShown.value ? (openBlock(), createBlock(unref(HighlightLabel), {
                key: 0,
                labelType: "success",
                dismissible: true
              }, {
                default: withCtx(() => [createTextVNode(" The communication has been saved. "), createElementVNode("button", {
                  type: "button",
                  class: "close btn-dismiss-alert",
                  "aria-label": "Hide This Alert",
                  onClick: _cache[0] || (_cache[0] = withModifiers($event => isSaveSuccessMessageShown.value = false, ["prevent"]))
                }, [..._hoisted_5$1])]),
                _: 1
              })) : createCommentVNode("v-if", true), createVNode(unref(HighlightLabel), {
                labelType: "info"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.recipientsLabel), 1)]),
                _: 1
              })])])]),
              headerActions: withCtx(() => [createElementVNode("span", {
                class: "action panel-action-save clickable",
                onClick: onSaveCommunication
              }, [createElementVNode("i", {
                ref_key: "saveElement",
                ref: saveElement,
                "data-toggle": "tooltip",
                title: "Save Draft",
                class: "ti ti-device-floppy"
              }, null, 512)])]),
              default: withCtx(() => [createElementVNode("div", _hoisted_6$1, [createVNode(unref(RockForm), {
                submit: submitTrigger.value,
                "onUpdate:submit": _cache[7] || (_cache[7] = $event => submitTrigger.value = $event),
                onSubmit: onFormSubmitted
              }, {
                default: withCtx(() => [createElementVNode("div", _hoisted_7$1, [createElementVNode("div", _hoisted_8$1, [createElementVNode("div", _hoisted_9$1, [createElementVNode("div", _hoisted_10$1, [createVNode(unref(DropDownList), {
                  modelValue: smsFromSystemPhoneNumberGuidOrEmptyString.value,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => smsFromSystemPhoneNumberGuidOrEmptyString.value = $event),
                  disabled: isSaving.value || isSendingTest.value,
                  help: "The number to originate message from (configured under Admin Tools > Communications > System Phone Numbers).",
                  items: __props.smsFromNumbers,
                  label: "From Number",
                  rules: "required",
                  showBlankItem: false
                }, null, 8, ["modelValue", "disabled", "items"])])]), createElementVNode("div", _hoisted_11$1, [createElementVNode("div", _hoisted_12$1, [createVNode(unref(SmsMessageEditor), {
                  modelValue: unref(internalMessage),
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => isRef(internalMessage) ? internalMessage.value = $event : null),
                  disabled: isSaving.value || isSendingTest.value,
                  editorHeight: 185,
                  isCharacterCountShown: true,
                  mergeFields: __props.mergeFields,
                  commonMergeFields: commonMergeFields,
                  rules: "required",
                  shortLinkCheckToken: __props.shortLinkCheckToken,
                  shortLinkGetPageId: __props.shortLinkGetPageId,
                  shortLinkSites: __props.shortLinkSites,
                  shortLinkTokenMinLength: __props.shortLinkTokenMinLength,
                  toolbarLabel: "Message"
                }, null, 8, ["modelValue", "disabled", "mergeFields", "shortLinkCheckToken", "shortLinkGetPageId", "shortLinkSites", "shortLinkTokenMinLength"])])]), createElementVNode("div", _hoisted_13$1, [createElementVNode("div", _hoisted_14$1, [createVNode(unref(FileUploader), {
                  modelValue: currentAttachment.value,
                  "onUpdate:modelValue": [_cache[3] || (_cache[3] = $event => currentAttachment.value = $event), onAttachmentAdded],
                  binaryFileTypeGuid: __props.attachmentBinaryFileTypeGuid,
                  disabled: isSaving.value || isSendingTest.value,
                  label: "Attachments",
                  fileProcessor: smsAttachmentFileProcessor.value,
                  uploadAsTemporary: false
                }, null, 8, ["modelValue", "binaryFileTypeGuid", "disabled", "fileProcessor"]), attachmentSizeMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
                  key: 0
                }, {
                  default: withCtx(() => [createTextVNode(toDisplayString(attachmentSizeMessage.value), 1)]),
                  _: 1
                })) : createCommentVNode("v-if", true), mimeTypeMessageHtml.value ? (openBlock(), createBlock(unref(NotificationBox), {
                  key: 1,
                  alertType: mimeTypeAlertType.value,
                  innerHTML: mimeTypeMessageHtml.value
                }, null, 8, ["alertType", "innerHTML"])) : createCommentVNode("v-if", true)])])]), createElementVNode("div", _hoisted_15$1, [createElementVNode("div", _hoisted_16$1, [createVNode(unref(script$b), {
                  previewAsType: unref(internalPreviewAsType),
                  "onUpdate:previewAsType": _cache[4] || (_cache[4] = $event => isRef(internalPreviewAsType) ? internalPreviewAsType.value = $event : null),
                  previewAsPersonAlias: unref(internalPreviewAsPersonAlias),
                  "onUpdate:previewAsPersonAlias": _cache[5] || (_cache[5] = $event => isRef(internalPreviewAsPersonAlias) ? internalPreviewAsPersonAlias.value = $event : null),
                  personalizationSegment: unref(internalPreviewAsPersonalizationSegment),
                  "onUpdate:personalizationSegment": _cache[6] || (_cache[6] = $event => isRef(internalPreviewAsPersonalizationSegment) ? internalPreviewAsPersonalizationSegment.value = $event : null),
                  isPreviewLoading: isPreviewLoading.value,
                  personalizationSegments: __props.personalizationSegments
                }, null, 8, ["previewAsType", "previewAsPersonAlias", "personalizationSegment", "isPreviewLoading", "personalizationSegments"])]), createVNode(unref(SmsMobilePreview), {
                  class: normalizeClass(unref(breakpointHelper).breakpoint),
                  isLoading: isPreviewLoading.value,
                  smsAttachmentLinks: __props.smsAttachmentLinks,
                  smsFromNumberName: __props.smsFromNumberName,
                  smsMessage: messagePreview.value
                }, null, 8, ["class", "isLoading", "smsAttachmentLinks", "smsFromNumberName", "smsMessage"])])]), createVNode(unref(script$d), {
                  isVisible: isSaving.value || isSendingTest.value,
                  targetSelector: ".sms-editor-step"
                }, null, 8, ["isVisible"])]),
                _: 1
              }, 8, ["submit"])])]),
              footerActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                disabled: isSaving.value || isSendingTest.value,
                onClick: onPreviousClicked
              }, {
                default: withCtx(() => [createTextVNode("Previous")]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowLeft']])]),
              footerSecondaryActions: withCtx(() => [createVNode(unref(RockButton), {
                disabled: isSaving.value || isSendingTest.value,
                onClick: onSendTestClicked
              }, {
                default: withCtx(() => [_hoisted_17$1, createTextVNode(" Send Test ")]),
                _: 1
              }, 8, ["disabled"]), withDirectives((openBlock(), createBlock(unref(RockButton), {
                btnType: "primary",
                disabled: isSaving.value || isSendingTest.value,
                onClick: onNextClicked
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.nextStepTitle ? "Next: ".concat(__props.nextStepTitle) : 'Next'), 1)]),
                _: 1
              }, 8, ["disabled"])), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowRight']])]),
              _: 1
            }), createVNode(unref(Modal), {
              modelValue: isSendTestModalShown.value,
              "onUpdate:modelValue": _cache[9] || (_cache[9] = $event => isSendTestModalShown.value = $event),
              saveText: "Send",
              onSave: onSendTestCommunication
            }, {
              default: withCtx(() => [createVNode(unref(PhoneNumberBox), {
                modelValue: testSmsPhoneNumberOrEmptyString.value,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => testSmsPhoneNumberOrEmptyString.value = $event),
                help: "This will temporarily change your SMS number during the test, but it will be changed back after the test is complete.",
                label: "SMS Number",
                rules: "required"
              }, null, 8, ["modelValue"])]),
              _: 1
            }, 8, ["modelValue"])]);
          };
        }
      });

      var css_248z$2 = "[data-v-13d4c4c9] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}.panel-body-contents[data-v-13d4c4c9]{flex:1;overflow-x:hidden;overflow-y:auto}[data-v-13d4c4c9] .panel-sub-header{background-color:var(--color-interface-softer);border-color:var(--color-interface-soft)}.sms-editor-panel-title[data-v-13d4c4c9]{align-items:center;display:flex;justify-content:space-between}.sms-editor-panel-title-right[data-v-13d4c4c9]{align-items:center;display:flex;flex-direction:row;gap:var(--spacing-medium)}.btn-dismiss-alert[data-v-13d4c4c9]{font-size:var(--font-size-xsmall)}.btn-dismiss-alert.close i[data-v-13d4c4c9]{display:inline-block}.preview-as-wrapper[data-v-13d4c4c9]{background-color:var(--color-interface-softest);padding:var(--spacing-medium);padding-left:var(--panel-body-padding);padding-right:var(--panel-body-padding)}.preview-as-wrapper[data-v-13d4c4c9],[data-v-13d4c4c9] .confirmation-preview-panel{margin-left:calc(0px - var(--panel-body-padding));margin-right:calc(0px - var(--panel-body-padding))}[data-v-13d4c4c9] .confirmation-preview-panel.xs{background:none;margin-bottom:0;margin-top:0;padding:0}";
      styleInject(css_248z$2);

      script$3.__scopeId = "data-v-13d4c4c9";
      script$3.__file = "src/Communication/CommunicationEntryWizard/smsEditorStep.partial.obs";

      var _hoisted_1$1 = {
        class: "d-sm-flex flex-row justify-content-between align-items-center"
      };
      var _hoisted_2$1 = {
        class: "label label-info"
      };
      var script$2 = defineComponent({
        __name: 'recipientModal.partial',
        props: {
          modelValue: {
            type: Object,
            required: true
          },
          communicationListGroupName: {
            type: String
          },
          disabled: {
            type: Boolean,
            default: false
          },
          disabledMessage: {
            type: String,
            required: false
          },
          getTooltipRef: {
            type: Function,
            default: _ => ""
          },
          isAddingIndividualsToRecipientListsDisabled: {
            type: Boolean,
            required: true
          },
          isDeletingIndividualsFromRecipientListsDisabled: {
            type: Boolean,
            required: true
          },
          isBulkCommunication: {
            type: Boolean,
            default: false
          },
          recipients: {
            type: Object,
            required: true
          }
        },
        emits: ["update:modelValue", "update:recipients"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var invokeBlockAction = useInvokeBlockActionHelper();
          var breakpointHelper = useBreakpointHelper();
          var props = __props;
          var emit = __emit;
          var isRegex = /\/(.+)\/(.*)/;
          var recipientsGridDefinition = {
            enableLaunchWorkflow: false,
            enableStickyHeader: false,
            fields: [createFieldDefinition(getStringKey("name")), createFieldDefinition(getStringKey("isEmailAllowed")), createFieldDefinition(getStringKey("isSmsAllowed")), createFieldDefinition(getStringKey("isPushAllowed"))]
          };
          var emptyListItemBag = {};
          var internalIsOpen = useVModelPassthrough(props, "modelValue", emit);
          var recipientTextFilter = ref("");
          var recipientTextFilterTemp = ref("");
          var personPickerSelection = ref();
          var pendingItems = ref([...props.recipients]);
          var internalRecipients = useVModelPassthrough(props, "recipients", emit);
          var title = computed(() => {
            if (!isManualCommunicationList.value) {
              return "Communication List Recipients";
            } else {
              if (!props.isAddingIndividualsToRecipientListsDisabled) {
                return "Add / Remove Recipients";
              } else {
                return "View / Remove Recipients";
              }
            }
          });
          var recipientsGridData = computed(() => ({
            rows: filteredRecipients.value
          }));
          var filteredRecipients = computed(() => {
            var textFilter = recipientTextFilter.value;
            if (!textFilter) {
              return pendingItems.value;
            }
            var regex = tryGetRegExp(textFilter);
            if (regex) {
              return pendingItems.value.filter(recipient => recipient.name && regex.test(recipient.name) || recipient.email && regex.test(recipient.email) || recipient.smsNumber && regex.test(recipient.smsNumber));
            } else {
              var textFilterLowerCase = textFilter.toLocaleLowerCase();
              return pendingItems.value.filter(recipient => recipient.name && recipient.name.toLocaleLowerCase().indexOf(textFilterLowerCase) >= 0 || recipient.email && recipient.email.toLocaleLowerCase().indexOf(textFilterLowerCase) >= 0 || recipient.smsNumber && recipient.smsNumber.toLocaleLowerCase().indexOf(textFilterLowerCase) >= 0);
            }
          });
          var isManualCommunicationList = computed(() => {
            if (props.communicationListGroupName) {
              return false;
            } else {
              return true;
            }
          });
          function getStringKey(key) {
            return key;
          }
          function getRecipientKey(key) {
            return getStringKey(key);
          }
          function createFieldDefinition(name) {
            return {
              name
            };
          }
          function getEmailTextCssClass(recipient) {
            if (!recipient.isEmailAllowed) {
              return "text-danger";
            } else {
              return "";
            }
          }
          function getSmsTextCssClass(recipient) {
            if (!recipient.isSmsAllowed) {
              return "text-danger";
            } else {
              return "";
            }
          }
          function getPushTextCssClass(recipient) {
            if (!recipient.isPushAllowed) {
              return "text-danger";
            } else {
              return "";
            }
          }
          function getEmailAddress(recipient) {
            if (!recipient || props.isBulkCommunication && recipient.isBulkEmailAllowed || !props.isBulkCommunication && recipient.isEmailAllowed) {
              return (recipient === null || recipient === void 0 ? void 0 : recipient.email) || "No Email";
            }
            if (!recipient.email) {
              return "No Email";
            } else if (!recipient.isEmailActive) {
              return "Inactive Email";
            } else {
              return "Email Not Allowed";
            }
          }
          function getSmsNumber(recipient) {
            if (!recipient || recipient.isSmsAllowed) {
              return recipient !== null && recipient !== void 0 && recipient.smsNumber ? formatPhoneNumber(recipient.smsNumber) : "No SMS Number";
            }
            if (!recipient.smsNumber) {
              return "No SMS Number";
            } else {
              return "SMS Not Allowed";
            }
          }
          function getPushStatus(recipient) {
            if (!recipient || recipient.isPushAllowed) {
              return "";
            }
            return "No Push Device";
          }
          function tryGetRegExp(pattern) {
            try {
              var match = pattern.match(isRegex);
              if (match && match.length) {
                return new RegExp(match[1], match[2]);
              }
            } catch (_unused) {}
          }
          function clear() {
            personPickerSelection.value = emptyListItemBag;
            recipientTextFilterTemp.value = "";
            recipientTextFilter.value = "";
          }
          function onRemoveRecipientClicked(personAliasGuid) {
            if (!personAliasGuid) {
              return;
            }
            var updatedPendingItems = [...pendingItems.value];
            var index = updatedPendingItems.findIndex(i => i.personAliasGuid === personAliasGuid);
            if (index !== -1) {
              updatedPendingItems.splice(index, 1);
              pendingItems.value = updatedPendingItems;
            }
          }
          function onPersonPicked(_x) {
            return _onPersonPicked.apply(this, arguments);
          }
          function _onPersonPicked() {
            _onPersonPicked = _asyncToGenerator(function* (value) {
              if (!(value !== null && value !== void 0 && value.value)) {
                return;
              }
              var result = yield invokeBlockAction.getRecipient(value.value);
              if (!(result !== null && result !== void 0 && result.isSuccess) || !result.data) {
                console.error("An unexpected error occurred while retrieving information about the selected person:", result === null || result === void 0 ? void 0 : result.errorMessage);
                return;
              }
              var updatedPendingItems = [...pendingItems.value];
              var index = updatedPendingItems.findIndex(i => {
                var _result$data;
                return i.personAliasGuid === ((_result$data = result.data) === null || _result$data === void 0 ? void 0 : _result$data.personAliasGuid);
              });
              if (index === -1) {
                updatedPendingItems.push(result.data);
                pendingItems.value = updatedPendingItems;
              }
              personPickerSelection.value = emptyListItemBag;
            });
            return _onPersonPicked.apply(this, arguments);
          }
          function onSaveClicked() {
            if (isManualCommunicationList.value) {
              internalRecipients.value = pendingItems.value;
            }
            internalIsOpen.value = false;
            clear();
          }
          function onCloseModal() {
            clear();
          }
          function onRemoveAllClicked() {
            pendingItems.value = [];
          }
          watch(internalIsOpen, (newValue, oldValue) => {
            if (newValue && !oldValue) {
              pendingItems.value = [...props.recipients];
            }
          });
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(Modal), {
              modelValue: unref(internalIsOpen),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(internalIsOpen) ? internalIsOpen.value = $event : null),
              cancelText: isManualCommunicationList.value ? 'Cancel' : '',
              clickBackdropToClose: false,
              isSaveButtonDisabled: __props.disabled,
              saveText: isManualCommunicationList.value ? 'Save' : 'OK',
              title: title.value,
              onSave: onSaveClicked,
              onCloseModal: onCloseModal
            }, {
              default: withCtx(() => [createElementVNode("div", {
                class: normalizeClass("recipient-modal-body ".concat(unref(breakpointHelper).breakpoint))
              }, [isManualCommunicationList.value ? (openBlock(), createElementBlock(Fragment, {
                key: 0
              }, [!__props.isAddingIndividualsToRecipientListsDisabled ? (openBlock(), createElementBlock(Fragment, {
                key: 0
              }, [createVNode(unref(SectionHeader), {
                title: "Recipient List",
                description: "Below is a listing of your current recipients. You can add or remove individuals from this list before continuing."
              }), createElementVNode("div", _hoisted_1$1, [createVNode(unref(PersonPicker), {
                modelValue: personPickerSelection.value,
                disabled: __props.disabled,
                label: "Person",
                "onUpdate:modelValue": onPersonPicked
              }, null, 8, ["modelValue", "disabled"]), createElementVNode("div", _hoisted_2$1, "Recipients: " + toDisplayString(pendingItems.value.length), 1)])], 64)) : (openBlock(), createBlock(unref(SectionHeader), {
                key: 1,
                title: "Recipient List",
                description: "Below is a listing of your current recipients."
              }))], 64)) : (openBlock(), createBlock(unref(NotificationBox), {
                key: 1,
                alertType: "info"
              }, {
                default: withCtx(() => [createTextVNode(" Below are the current members of the \"" + toDisplayString(__props.communicationListGroupName) + "\" List with segment filters applied. If this message is sent at a future date, it is possible that the list may change between now and then. ", 1)]),
                _: 1
              })), createVNode(unref(Grid), {
                definition: recipientsGridDefinition,
                data: recipientsGridData.value,
                itemTerm: "Recipient",
                class: "recipient-manager-grid",
                disablePreferences: true,
                keyField: getStringKey('personAliasGuid'),
                rowClass: "recipient-modal-row"
              }, {
                default: withCtx(() => [createVNode(unref(Column), {
                  name: getRecipientKey('name'),
                  field: getRecipientKey('name'),
                  title: "Name",
                  filter: unref(textValueFilter)
                }, {
                  format: withCtx(_ref2 => {
                    var row = _ref2.row;
                    return [createElementVNode("div", null, toDisplayString(row.name), 1)];
                  }),
                  _: 1
                }, 8, ["name", "field", "filter"]), createVNode(unref(Column), {
                  name: getRecipientKey('isEmailAllowed'),
                  field: getRecipientKey('isEmailAllowed'),
                  title: "Email"
                }, {
                  format: withCtx(_ref3 => {
                    var row = _ref3.row;
                    return [createElementVNode("span", {
                      class: normalizeClass(['communication-medium-status', getEmailTextCssClass(row)])
                    }, toDisplayString(getEmailAddress(row)), 3)];
                  }),
                  _: 1
                }, 8, ["name", "field"]), createVNode(unref(Column), {
                  name: getRecipientKey('isSmsAllowed'),
                  field: getRecipientKey('isSmsAllowed'),
                  title: "SMS"
                }, {
                  format: withCtx(_ref4 => {
                    var row = _ref4.row;
                    return [createElementVNode("span", {
                      class: normalizeClass(['communication-medium-status', getSmsTextCssClass(row)])
                    }, toDisplayString(getSmsNumber(row)), 3)];
                  }),
                  _: 1
                }, 8, ["name", "field"]), createVNode(unref(Column), {
                  name: getRecipientKey('isPushAllowed'),
                  field: getRecipientKey('isPushAllowed'),
                  title: "Push"
                }, {
                  format: withCtx(_ref5 => {
                    var row = _ref5.row;
                    return [createElementVNode("span", {
                      class: normalizeClass(['communication-medium-status', getPushTextCssClass(row)])
                    }, toDisplayString(getPushStatus(row)), 3)];
                  }),
                  _: 1
                }, 8, ["name", "field"]), !__props.isDeletingIndividualsFromRecipientListsDisabled ? (openBlock(), createBlock(unref(DeleteColumn), {
                  key: 0,
                  name: "removeRecipient",
                  itemClass: "grid-columncommand remove-button",
                  disableConfirmation: true,
                  onClick: onRemoveRecipientClicked
                })) : createCommentVNode("v-if", true)]),
                _: 1
              }, 8, ["data", "keyField"]), isManualCommunicationList.value ? (openBlock(), createBlock(unref(RockButton), {
                key: 2,
                btnSize: "xs",
                class: "btn-primary btn-remove",
                onClick: onRemoveAllClicked
              }, {
                default: withCtx(() => [createTextVNode("Remove All")]),
                _: 1
              })) : createCommentVNode("v-if", true)], 2)]),
              _: 1
            }, 8, ["modelValue", "cancelText", "isSaveButtonDisabled", "saveText", "title"]);
          };
        }
      });

      var css_248z$1 = ".communication-medium-status[data-v-93a34632]{white-space:nowrap}.recipient-modal-body[data-v-93a34632]:not(.xs) .recipient-modal-row .remove-button{visibility:hidden}.recipient-modal-body[data-v-93a34632]:not(.xs) .recipient-modal-row:hover .remove-button{visibility:visible}.recipient-manager-grid[data-v-93a34632] .grid-body{height:400px;max-height:400px;overflow:auto}.recipient-manager-grid[data-v-93a34632] .grid-title-heading{display:none}.btn-remove[data-v-93a34632],.btn-remove[data-v-93a34632]:active,.btn-remove[data-v-93a34632]:hover{background-color:var(--color-interface-softest);border:1px solid var(--color-primary);color:var(--color-primary)}";
      styleInject(css_248z$1);

      script$2.__scopeId = "data-v-93a34632";
      script$2.__file = "src/Communication/CommunicationEntryWizard/recipientModal.partial.obs";

      var _withScopeId = n => (pushScopeId("data-v-4d4a084c"), n = n(), popScopeId(), n);
      var _hoisted_1 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      }, null, -1));
      var _hoisted_2 = {
        key: 0,
        class: "ml-2"
      };
      var _hoisted_3 = ["href"];
      var _hoisted_4 = {
        class: "panel-body-contents"
      };
      var _hoisted_5 = {
        class: "wizard-start-container"
      };
      var _hoisted_6 = {
        class: "wizard-start"
      };
      var _hoisted_7 = _withScopeId(() => createElementVNode("label", {
        class: "text-md"
      }, "Recipients", -1));
      var _hoisted_8 = {
        class: "row"
      };
      var _hoisted_9 = {
        class: "col-sm-5"
      };
      var _hoisted_10 = {
        key: 0,
        class: "col-sm-5"
      };
      var _hoisted_11 = {
        class: "row"
      };
      var _hoisted_12 = {
        class: "col-sm-5"
      };
      var _hoisted_13 = {
        class: "communication-list-group-container"
      };
      var _hoisted_14 = {
        class: "communication-list-container"
      };
      var _hoisted_15 = {
        key: 0,
        class: "form-group"
      };
      var _hoisted_16 = _withScopeId(() => createElementVNode("div", {
        class: "control-wrapper"
      }, " Manual Recipient List ", -1));
      var _hoisted_17 = {
        class: "form-group"
      };
      var _hoisted_18 = {
        class: "control-wrapper"
      };
      var _hoisted_19 = {
        key: 0,
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      };
      var _hoisted_20 = {
        key: 1,
        class: "ti ti-eye"
      };
      var _hoisted_21 = {
        class: "col-sm-5"
      };
      var _hoisted_22 = {
        key: 0,
        class: "row"
      };
      var _hoisted_23 = {
        class: "col-sm-5"
      };
      var _hoisted_24 = {
        key: 0
      };
      var _hoisted_25 = {
        class: "row"
      };
      var _hoisted_26 = {
        class: "col-sm-12"
      };
      var _hoisted_27 = {
        class: "row"
      };
      var _hoisted_28 = {
        class: "col-sm-12"
      };
      var _hoisted_29 = {
        key: 0,
        class: "form-group"
      };
      var _hoisted_30 = _withScopeId(() => createElementVNode("label", {
        class: "text-md"
      }, "Medium", -1));
      var _hoisted_31 = {
        class: "mediums-section"
      };
      var _hoisted_32 = {
        class: "medium-content"
      };
      var _hoisted_33 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-mail ti-2x"
      }, null, -1));
      var _hoisted_34 = _withScopeId(() => createElementVNode("h5", null, "Email", -1));
      var _hoisted_35 = _withScopeId(() => createElementVNode("small", null, "Send an email to everyone in your targeted segment.", -1));
      var _hoisted_36 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      }, null, -1));
      var _hoisted_37 = {
        class: "medium-content"
      };
      var _hoisted_38 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-device-mobile-message ti-2x"
      }, null, -1));
      var _hoisted_39 = _withScopeId(() => createElementVNode("h5", null, "SMS", -1));
      var _hoisted_40 = _withScopeId(() => createElementVNode("small", null, "Send a text message to your targeted segment.", -1));
      var _hoisted_41 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      }, null, -1));
      var _hoisted_42 = {
        class: "medium-content"
      };
      var _hoisted_43 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-bell ti-2x"
      }, null, -1));
      var _hoisted_44 = _withScopeId(() => createElementVNode("h5", null, "Push Notifications", -1));
      var _hoisted_45 = _withScopeId(() => createElementVNode("small", null, "Notify targeted segment via the church app.", -1));
      var _hoisted_46 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      }, null, -1));
      var _hoisted_47 = {
        class: "medium-content"
      };
      var _hoisted_48 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-user ti-2x"
      }, null, -1));
      var _hoisted_49 = _withScopeId(() => createElementVNode("h5", null, "Personal Preference", -1));
      var _hoisted_50 = _withScopeId(() => createElementVNode("small", null, "Notify targeted segment via person's preferred channel.", -1));
      var _hoisted_51 = _withScopeId(() => createElementVNode("i", {
        class: "ti ti-rotate-clockwise-2 ti-pulse"
      }, null, -1));
      var _hoisted_52 = _withScopeId(() => createElementVNode("label", {
        class: "text-md"
      }, "Schedule", -1));
      var _hoisted_53 = {
        class: "row"
      };
      var _hoisted_54 = {
        class: "col-sm-5"
      };
      var _hoisted_55 = {
        key: 0
      };
      var manualRecipientList = "manual";
      var script$1 = defineComponent({
        __name: 'wizardStartStep.partial',
        props: {
          allowedMediums: {
            type: Object,
            required: true
          },
          areNavigationShortcutsDisabled: {
            type: Boolean,
            required: true
          },
          communicationId: {
            type: Number,
            required: true
          },
          communicationListGroupGuid: {
            type: String,
            required: true
          },
          communicationListGroups: {
            type: Object,
            required: true
          },
          communicationName: {
            type: String,
            required: true
          },
          communicationTopicValue: {
            type: String,
            required: true
          },
          communicationTopicValues: {
            type: Object,
            required: true
          },
          communicationType: {
            type: Number,
            required: true
          },
          emailRecipientCount: {
            type: Number,
            required: true
          },
          excludeDuplicateRecipientAddress: {
            type: Boolean,
            required: true
          },
          futureSendDateTime: {
            type: String,
            required: true
          },
          individualRecipientPersonAliasGuids: {
            type: Object,
            required: true
          },
          isAddingIndividualsToRecipientListsDisabled: {
            type: Boolean,
            required: true
          },
          isDeletingIndividualsToRecipientListsDisabled: {
            type: Boolean,
            required: true
          },
          isBulkCommunication: {
            type: Boolean,
            required: true
          },
          isBulkCommunicationForced: {
            type: Boolean,
            required: true
          },
          isDuplicatePreventionOptionShown: {
            type: Boolean,
            required: true
          },
          isFetchingRecipients: {
            type: Boolean,
            required: true
          },
          isIncompatibleCommunicationTemplateNotificationShown: {
            type: Boolean,
            required: true
          },
          isUseSimpleEditorButtonShown: {
            type: Boolean,
            required: true
          },
          nextStepTitle: {
            type: String,
            required: true
          },
          personalizationSegments: {
            type: Object,
            required: true
          },
          personalizationSegmentItems: {
            type: Object,
            required: true
          },
          personalPreferenceRecipientCount: {
            type: Number,
            required: true
          },
          pushNotificationRecipientCount: {
            type: Number,
            required: true
          },
          recipientCount: {
            type: Number,
            required: true
          },
          recipients: {
            type: Object,
            required: true
          },
          recipientsLabel: {
            type: String,
            required: true
          },
          segmentCriteria: {
            type: Number,
            required: true
          },
          simpleCommunicationPageUrl: {
            type: String,
            required: true
          },
          smsRecipientCount: {
            type: Number,
            required: true
          },
          title: {
            type: String,
            required: true
          }
        },
        emits: ["nextStep", "recipientListModified", "update:communicationListGroupGuid", "update:communicationTopicValue", "update:communicationName", "update:communicationType", "update:excludeDuplicateRecipientAddress", "update:futureSendDateTime", "update:individualRecipientPersonAliasGuids", "update:isBulkCommunication", "update:personalizationSegments", "update:recipients", "update:segmentCriteria"],
        setup(__props, _ref) {
          var _props$communicationL;
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var segmentCriteria = [{
            value: "".concat(get(SegmentCriteria.All)),
            text: "All Segment Filters"
          }, {
            value: "".concat(get(SegmentCriteria.Any)),
            text: "Any Segment Filters"
          }];
          var formId = "wizard-start-step-form-".concat(newGuid());
          var wizardStartStepElement = ref();
          var noRecipientsNotificationContainerElement = ref();
          var noMediumsContainerElement = ref();
          var isNoRecipientsNotificationShown = ref(false);
          var isRecipientModalShown = ref(false);
          var internalCommunicationName = useVModelPassthrough(props, "communicationName", emit);
          var internalCommunicationTopicValue = useVModelPassthrough(props, "communicationTopicValue", emit);
          var internalCommunicationType = useVModelPassthrough(props, "communicationType", emit);
          var internalExcludeDuplicateRecipientAddress = useVModelPassthrough(props, "excludeDuplicateRecipientAddress", emit);
          var internalFutureSendDateTime = useVModelPassthrough(props, "futureSendDateTime", emit);
          var internalIndividualRecipientPersonAliasGuids = useVModelPassthrough(props, "individualRecipientPersonAliasGuids", emit);
          var internalIsBulkCommunication = useVModelPassthrough(props, "isBulkCommunication", emit);
          var internalRecipients = useVModelPassthrough(props, "recipients", emit);
          var internalPersonalizationSegments = useVModelPassthrough(props, "personalizationSegments", emit);
          var internalSegmentCriteria = useVModelPassthrough(props, "segmentCriteria", emit);
          var selectedSendTimePreference = ref(internalFutureSendDateTime.value ? "later" : "now");
          var selectedCommunicationListGuidOrManualOrEmptyString = ref(!isNullish(internalIndividualRecipientPersonAliasGuids.value) || !isNullish(props.communicationId) && isNullish(props.communicationListGroupGuid) ? manualRecipientList : (_props$communicationL = props.communicationListGroupGuid) !== null && _props$communicationL !== void 0 ? _props$communicationL : "");
          var communicationListGroupItems = computed(() => {
            return [{
              value: manualRecipientList,
              text: "Manual Recipient List"
            }, ...props.communicationListGroups];
          });
          var segmentCriteriaAsString = computed({
            get() {
              return "".concat(internalSegmentCriteria.value);
            },
            set(value) {
              if (Object.keys(SegmentCriteriaDescription).includes(value)) {
                internalSegmentCriteria.value = Number(value);
              } else {
                internalSegmentCriteria.value = SegmentCriteria.All;
              }
            }
          });
          var internalSimpleCommunicationPageUrl = computed(() => {
            if (!props.simpleCommunicationPageUrl) {
              return;
            } else {
              return appendQueryParameters(props.simpleCommunicationPageUrl);
            }
          });
          var communicationTopicValueGuidOrEmptyString = computed({
            get() {
              var _internalCommunicatio, _internalCommunicatio2;
              return (_internalCommunicatio = (_internalCommunicatio2 = internalCommunicationTopicValue.value) === null || _internalCommunicatio2 === void 0 ? void 0 : _internalCommunicatio2.value) !== null && _internalCommunicatio !== void 0 ? _internalCommunicatio : "";
            },
            set(newValue) {
              internalCommunicationTopicValue.value = props.communicationTopicValues.find(v => areEqual(newValue, v.value));
            }
          });
          var personalizationSegmentIdsAsStrings = computed({
            get() {
              var _internalPersonalizat;
              return Enumerable.from((_internalPersonalizat = internalPersonalizationSegments.value) !== null && _internalPersonalizat !== void 0 ? _internalPersonalizat : []).where(p => !!p.value).select(p => p.value).toArray();
            },
            set(newValue) {
              internalPersonalizationSegments.value = Enumerable.from(props.personalizationSegmentItems).where(p => !!p.value).where(p => newValue.includes(p.value)).toArray();
            }
          });
          function appendQueryParameters(url) {
            var currentParams = new URLSearchParams(window.location.search);
            var targetUrl = new URL(url, window.location.origin);
            currentParams.forEach((value, key) => {
              if (!targetUrl.searchParams.has(key)) {
                targetUrl.searchParams.append(key, value);
              }
            });
            return targetUrl.toString();
          }
          function getTooltipRef(recipient, communicationType) {
            return computed(() => {
              if (communicationType === CommunicationType.Email) {
                if (!recipient || props.isBulkCommunication && recipient.isBulkEmailAllowed || !props.isBulkCommunication && recipient.isEmailAllowed) {
                  return "";
                }
                if (!recipient.email) {
                  var _recipient$name;
                  return "".concat((_recipient$name = recipient.name) !== null && _recipient$name !== void 0 ? _recipient$name : "This recipient", " doesn't have an email address.");
                } else if (!recipient.isEmailActive) {
                  var _recipient$name2;
                  return "".concat((_recipient$name2 = recipient.name) !== null && _recipient$name2 !== void 0 ? _recipient$name2 : "This recipient", " has an inactive email.");
                } else {
                  var _recipient$name3, _recipient$emailPrefe;
                  return "".concat((_recipient$name3 = recipient.name) !== null && _recipient$name3 !== void 0 ? _recipient$name3 : "This recipient", " has email preference set to \"").concat(splitCase((_recipient$emailPrefe = recipient.emailPreference) !== null && _recipient$emailPrefe !== void 0 ? _recipient$emailPrefe : ""), "\".");
                }
              } else if (communicationType === CommunicationType.SMS) {
                var _recipient$name4;
                if (!recipient || recipient.isSmsAllowed) {
                  return "";
                }
                return "".concat((_recipient$name4 = recipient.name) !== null && _recipient$name4 !== void 0 ? _recipient$name4 : "This recipient", " doesn't have a phone number with SMS enabled.");
              } else if (communicationType === CommunicationType.PushNotification) {
                var _recipient$name5;
                if (!recipient || recipient.isPushAllowed) {
                  return "";
                }
                return "".concat((_recipient$name5 = recipient.name) !== null && _recipient$name5 !== void 0 ? _recipient$name5 : "This recipient", " doesn't have a phone number with notifications enabled.");
              } else {
                return "";
              }
            });
          }
          function onFormSubmitted() {
            if (props.recipientCount <= 0) {
              isNoRecipientsNotificationShown.value = true;
              nextTick(() => {
                if (noRecipientsNotificationContainerElement.value) {
                  scrollElementStartToTop(noRecipientsNotificationContainerElement.value);
                }
              });
            } else if (!props.allowedMediums.length) {
              nextTick(() => {
                if (noMediumsContainerElement.value) {
                  scrollElementStartToTop(noMediumsContainerElement.value);
                }
              });
            } else {
              isNoRecipientsNotificationShown.value = false;
              emit("nextStep");
            }
          }
          function onSendTimePreferenceUpdated() {
            if (selectedSendTimePreference.value !== "later") {
              internalFutureSendDateTime.value = null;
            }
          }
          function onListGroupGuidUpdated() {
            if (selectedCommunicationListGuidOrManualOrEmptyString.value === manualRecipientList) {
              internalIndividualRecipientPersonAliasGuids.value = [];
              internalPersonalizationSegments.value = [];
              emit("update:communicationListGroupGuid", null);
            } else {
              internalIndividualRecipientPersonAliasGuids.value = null;
              emit("update:communicationListGroupGuid", toGuidOrNull(selectedCommunicationListGuidOrManualOrEmptyString.value));
            }
          }
          function onRecipientsUpdated() {
            internalIndividualRecipientPersonAliasGuids.value = internalRecipients.value.map(r => r.personAliasGuid);
            emit("recipientListModified");
          }
          watch(() => props.communicationListGroupGuid, value => {
            var _value;
            value = (_value = value) !== null && _value !== void 0 ? _value : "";
            if (isNullish(internalIndividualRecipientPersonAliasGuids.value) && selectedCommunicationListGuidOrManualOrEmptyString.value !== value) {
              selectedCommunicationListGuidOrManualOrEmptyString.value = value;
            }
          });
          watch(() => props.recipientCount, value => {
            if (value > 0) {
              isNoRecipientsNotificationShown.value = false;
            }
          });
          return (_ctx, _cache) => {
            var _props$communication;
            return openBlock(), createElementBlock("div", {
              ref_key: "wizardStartStepElement",
              ref: wizardStartStepElement,
              class: "wizard-start-step"
            }, [createVNode(unref(Panel), {
              title: __props.title,
              type: "block",
              panelBodyCssClass: "panel-body-wizard"
            }, {
              headerActions: withCtx(() => [createElementVNode("div", null, [createVNode(unref(HighlightLabel), {
                labelType: "info"
              }, {
                default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock(Fragment, {
                  key: 0
                }, [_hoisted_1, createTextVNode(" Recipients")], 64)) : (openBlock(), createElementBlock(Fragment, {
                  key: 1
                }, [createTextVNode(toDisplayString(__props.recipientsLabel), 1)], 64))]),
                _: 1
              })]), __props.isUseSimpleEditorButtonShown && internalSimpleCommunicationPageUrl.value ? (openBlock(), createElementBlock("div", _hoisted_2, [createVNode(unref(HighlightLabel), {
                labelType: "default"
              }, {
                default: withCtx(() => [createElementVNode("a", {
                  href: internalSimpleCommunicationPageUrl.value
                }, "Use Simple Editor", 8, _hoisted_3)]),
                _: 1
              })])) : createCommentVNode("v-if", true)]),
              default: withCtx(() => [createElementVNode("div", _hoisted_4, [createElementVNode("div", {
                ref_key: "noMediumsContainerElement",
                ref: noMediumsContainerElement
              }, [!__props.allowedMediums.length ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: "warning"
              }, {
                default: withCtx(() => [createTextVNode(" There are no active Email, SMS, or Push communication transports configured. ")]),
                _: 1
              })) : createCommentVNode("v-if", true)], 512), createElementVNode("div", {
                ref_key: "noRecipientsNotificationContainerElement",
                ref: noRecipientsNotificationContainerElement
              }, [isNoRecipientsNotificationShown.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: "warning",
                heading: "No Recipients Selected"
              }, {
                default: withCtx(() => [createTextVNode(" You cannot continue until you select a Communication List or configure a Manual List with recipients. ")]),
                _: 1
              })) : createCommentVNode("v-if", true)], 512), __props.isIncompatibleCommunicationTemplateNotificationShown ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: "info"
              }, {
                default: withCtx(() => [createTextVNode(" This message uses a template that isn't compatible with the Email Wizard. If you proceed with the wizard, the email's main content will be replaced when a compatible template is chosen. To preserve the existing content, select 'Use Simple Editor' to edit the email with the basic editor instead. ")]),
                _: 1
              })) : createCommentVNode("v-if", true), createVNode(unref(RockForm), {
                id: formId,
                onSubmit: onFormSubmitted
              }, {
                default: withCtx(() => {
                  var _props$individualRec;
                  return [createElementVNode("div", _hoisted_5, [createElementVNode("div", _hoisted_6, [_hoisted_7, createElementVNode("div", _hoisted_8, [createElementVNode("div", _hoisted_9, [createVNode(unref(TextBox), {
                    modelValue: unref(internalCommunicationName),
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(internalCommunicationName) ? internalCommunicationName.value = $event : null),
                    help: "This name is used internally to describe the communication. It is not sent as a part of the communication.",
                    label: "Communication Name",
                    rules: "required"
                  }, null, 8, ["modelValue"])]), __props.communicationTopicValues.length ? (openBlock(), createElementBlock("div", _hoisted_10, [createVNode(unref(DropDownList), {
                    modelValue: communicationTopicValueGuidOrEmptyString.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => communicationTopicValueGuidOrEmptyString.value = $event),
                    help: "This internal field allows you to associate this communication with a defined communication topic or campaign.",
                    items: __props.communicationTopicValues,
                    label: "Topic",
                    showBlankItem: true
                  }, null, 8, ["modelValue", "items"])])) : createCommentVNode("v-if", true)]), createElementVNode("div", _hoisted_11, [createElementVNode("div", _hoisted_12, [createElementVNode("div", _hoisted_13, [createElementVNode("div", _hoisted_14, [__props.communicationId && (_props$individualRec = __props.individualRecipientPersonAliasGuids) !== null && _props$individualRec !== void 0 && _props$individualRec.length ? (openBlock(), createElementBlock("div", _hoisted_15, [createVNode(unref(RockLabel), null, {
                    default: withCtx(() => [createTextVNode("Communication List")]),
                    _: 1
                  }), _hoisted_16])) : (openBlock(), createBlock(unref(DropDownList), {
                    key: 1,
                    modelValue: selectedCommunicationListGuidOrManualOrEmptyString.value,
                    "onUpdate:modelValue": [_cache[2] || (_cache[2] = $event => selectedCommunicationListGuidOrManualOrEmptyString.value = $event), onListGroupGuidUpdated],
                    help: "Choose a list of people to send your communication to. These lists are defined in Settings/Communication Settings.",
                    items: communicationListGroupItems.value,
                    label: "Communication List",
                    rules: "required",
                    showBlankItem: communicationListGroupItems.value.length > 1
                  }, null, 8, ["modelValue", "items", "showBlankItem"]))]), createElementVNode("div", _hoisted_17, [createVNode(unref(RockLabel), null, {
                    default: withCtx(() => [createTextVNode(" ")]),
                    _: 1
                  }), createElementVNode("div", _hoisted_18, [createVNode(unref(RockButton), {
                    btnSize: "sm",
                    disabled: __props.isFetchingRecipients,
                    onClick: _cache[3] || (_cache[3] = $event => isRecipientModalShown.value = true)
                  }, {
                    default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock("i", _hoisted_19)) : (openBlock(), createElementBlock("i", _hoisted_20)), createTextVNode(" View List ")]),
                    _: 1
                  }, 8, ["disabled"])])])])]), createElementVNode("div", _hoisted_21, [!__props.isBulkCommunicationForced ? (openBlock(), createBlock(unref(Switch), {
                    key: 0,
                    modelValue: unref(internalIsBulkCommunication),
                    "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => isRef(internalIsBulkCommunication) ? internalIsBulkCommunication.value = $event : null),
                    label: "Bulk Communication",
                    text: unref(internalIsBulkCommunication) ? 'Yes' : 'No'
                  }, null, 8, ["modelValue", "text"])) : createCommentVNode("v-if", true)])]), selectedCommunicationListGuidOrManualOrEmptyString.value !== manualRecipientList && __props.personalizationSegmentItems.length ? (openBlock(), createElementBlock("div", _hoisted_22, [createElementVNode("div", _hoisted_23, [createVNode(unref(ConditionalWell), {
                    class: "segments-section"
                  }, {
                    default: withCtx(() => [createVNode(unref(DropDownList), {
                      modelValue: personalizationSegmentIdsAsStrings.value,
                      "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => personalizationSegmentIdsAsStrings.value = $event),
                      enhanceForLongLists: "",
                      items: __props.personalizationSegmentItems,
                      label: "Select Segments",
                      multiple: true
                    }, null, 8, ["modelValue", "items"]), createVNode(unref(TransitionVerticalCollapse), null, {
                      default: withCtx(() => [unref(internalPersonalizationSegments) && unref(internalPersonalizationSegments).length > 1 ? (openBlock(), createElementBlock("div", _hoisted_24, [createVNode(unref(RadioButtonList), {
                        modelValue: segmentCriteriaAsString.value,
                        "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => segmentCriteriaAsString.value = $event),
                        items: segmentCriteria,
                        horizontal: true,
                        label: "Recipients Must Meet"
                      }, null, 8, ["modelValue"])])) : createCommentVNode("v-if", true)]),
                      _: 1
                    })]),
                    _: 1
                  })])])) : createCommentVNode("v-if", true), createElementVNode("div", _hoisted_25, [createElementVNode("div", _hoisted_26, [__props.isDuplicatePreventionOptionShown ? (openBlock(), createBlock(unref(Switch), {
                    key: 0,
                    modelValue: unref(internalExcludeDuplicateRecipientAddress),
                    "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => isRef(internalExcludeDuplicateRecipientAddress) ? internalExcludeDuplicateRecipientAddress.value = $event : null),
                    help: "Prevent communications from being sent to people with the same email/SMS addresses. Two people who share an address will not receive a personalized communication, only one of them will.",
                    label: "Prevent Duplicate Email/SMS Addresses",
                    text: unref(internalExcludeDuplicateRecipientAddress) ? 'Yes' : 'No'
                  }, null, 8, ["modelValue", "text"])) : createCommentVNode("v-if", true)])]), createElementVNode("div", _hoisted_27, [createElementVNode("div", _hoisted_28, [__props.allowedMediums.length ? (openBlock(), createElementBlock("div", _hoisted_29, [_hoisted_30, createElementVNode("div", _hoisted_31, [__props.allowedMediums.includes(unref(CommunicationType).Email) ? (openBlock(), createElementBlock("div", {
                    key: 0,
                    class: normalizeClass(['medium', {
                      'selected': unref(internalCommunicationType) === unref(CommunicationType).Email
                    }]),
                    onClick: _cache[8] || (_cache[8] = $event => internalCommunicationType.value = unref(CommunicationType).Email)
                  }, [createElementVNode("div", _hoisted_32, [_hoisted_33, _hoisted_34, _hoisted_35, createVNode(unref(HighlightLabel), {
                    labelType: "info"
                  }, {
                    default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock(Fragment, {
                      key: 0
                    }, [createTextVNode("Reachable Audience: "), _hoisted_36], 64)) : (openBlock(), createElementBlock(Fragment, {
                      key: 1
                    }, [createTextVNode("Reachable Audience: " + toDisplayString(__props.emailRecipientCount), 1)], 64))]),
                    _: 1
                  }), createElementVNode("i", {
                    class: normalizeClass(unref(internalCommunicationType) === unref(CommunicationType).Email ? 'ti ti-circle-dot' : 'ti ti-circle')
                  }, null, 2)])], 2)) : createCommentVNode("v-if", true), __props.allowedMediums.includes(unref(CommunicationType).SMS) ? (openBlock(), createElementBlock("div", {
                    key: 1,
                    class: normalizeClass(['medium', {
                      'selected': unref(internalCommunicationType) === unref(CommunicationType).SMS
                    }]),
                    onClick: _cache[9] || (_cache[9] = $event => internalCommunicationType.value = unref(CommunicationType).SMS)
                  }, [createElementVNode("div", _hoisted_37, [_hoisted_38, _hoisted_39, _hoisted_40, createVNode(unref(HighlightLabel), {
                    labelType: "info"
                  }, {
                    default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock(Fragment, {
                      key: 0
                    }, [createTextVNode("Reachable Audience: "), _hoisted_41], 64)) : (openBlock(), createElementBlock(Fragment, {
                      key: 1
                    }, [createTextVNode("Reachable Audience: " + toDisplayString(__props.smsRecipientCount), 1)], 64))]),
                    _: 1
                  }), createElementVNode("i", {
                    class: normalizeClass(unref(internalCommunicationType) === unref(CommunicationType).SMS ? 'ti ti-circle-dot' : 'ti ti-circle')
                  }, null, 2)])], 2)) : createCommentVNode("v-if", true), __props.allowedMediums.includes(unref(CommunicationType).PushNotification) ? (openBlock(), createElementBlock("div", {
                    key: 2,
                    class: normalizeClass(['medium', {
                      'selected': unref(internalCommunicationType) === unref(CommunicationType).PushNotification
                    }]),
                    onClick: _cache[10] || (_cache[10] = $event => internalCommunicationType.value = unref(CommunicationType).PushNotification)
                  }, [createElementVNode("div", _hoisted_42, [_hoisted_43, _hoisted_44, _hoisted_45, createVNode(unref(HighlightLabel), {
                    labelType: "info"
                  }, {
                    default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock(Fragment, {
                      key: 0
                    }, [createTextVNode("Reachable Audience: "), _hoisted_46], 64)) : (openBlock(), createElementBlock(Fragment, {
                      key: 1
                    }, [createTextVNode("Reachable Audience: " + toDisplayString(__props.pushNotificationRecipientCount), 1)], 64))]),
                    _: 1
                  }), createElementVNode("i", {
                    class: normalizeClass(unref(internalCommunicationType) === unref(CommunicationType).PushNotification ? 'ti ti-circle-dot' : 'ti ti-circle')
                  }, null, 2)])], 2)) : createCommentVNode("v-if", true), __props.allowedMediums.includes(unref(CommunicationType).RecipientPreference) ? (openBlock(), createElementBlock("div", {
                    key: 3,
                    class: normalizeClass(['medium', {
                      'selected': unref(internalCommunicationType) === unref(CommunicationType).RecipientPreference
                    }]),
                    onClick: _cache[11] || (_cache[11] = $event => internalCommunicationType.value = unref(CommunicationType).RecipientPreference)
                  }, [createElementVNode("div", _hoisted_47, [_hoisted_48, _hoisted_49, _hoisted_50, createVNode(unref(HighlightLabel), {
                    labelType: "info"
                  }, {
                    default: withCtx(() => [__props.isFetchingRecipients ? (openBlock(), createElementBlock(Fragment, {
                      key: 0
                    }, [createTextVNode("Reachable Audience: "), _hoisted_51], 64)) : (openBlock(), createElementBlock(Fragment, {
                      key: 1
                    }, [createTextVNode("Reachable Audience: " + toDisplayString(__props.personalPreferenceRecipientCount), 1)], 64))]),
                    _: 1
                  }), createElementVNode("i", {
                    class: normalizeClass(unref(internalCommunicationType) === unref(CommunicationType).RecipientPreference ? 'ti ti-circle-dot' : 'ti ti-circle')
                  }, null, 2)])], 2)) : createCommentVNode("v-if", true)])])) : createCommentVNode("v-if", true)])]), _hoisted_52, createElementVNode("div", _hoisted_53, [createElementVNode("div", _hoisted_54, [createVNode(unref(RadioButtonList), {
                    modelValue: selectedSendTimePreference.value,
                    "onUpdate:modelValue": [_cache[12] || (_cache[12] = $event => selectedSendTimePreference.value = $event), onSendTimePreferenceUpdated],
                    items: [{
                      value: 'now',
                      text: 'Now'
                    }, {
                      value: 'later',
                      text: 'Later'
                    }],
                    horizontal: true,
                    label: "When to Send",
                    rules: "required"
                  }, null, 8, ["modelValue"]), createVNode(unref(TransitionVerticalCollapse), null, {
                    default: withCtx(() => [selectedSendTimePreference.value === 'later' ? (openBlock(), createElementBlock("div", _hoisted_55, [createVNode(unref(DateTimePicker), {
                      modelValue: unref(internalFutureSendDateTime),
                      "onUpdate:modelValue": _cache[13] || (_cache[13] = $event => isRef(internalFutureSendDateTime) ? internalFutureSendDateTime.value = $event : null),
                      label: "Date & Time",
                      rules: "required"
                    }, null, 8, ["modelValue"])])) : createCommentVNode("v-if", true)]),
                    _: 1
                  })])])])])];
                }),
                _: 1
              })])]),
              footerSecondaryActions: withCtx(() => [withDirectives((openBlock(), createBlock(unref(RockButton), {
                btnType: "primary",
                form: formId,
                type: "submit"
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(__props.nextStepTitle ? "Next: ".concat(__props.nextStepTitle) : 'Next'), 1)]),
                _: 1
              })), [[unref(vShortcut), !__props.areNavigationShortcutsDisabled && 'ArrowRight']])]),
              _: 1
            }, 8, ["title"]), createVNode(unref(script$2), {
              modelValue: isRecipientModalShown.value,
              "onUpdate:modelValue": _cache[14] || (_cache[14] = $event => isRecipientModalShown.value = $event),
              excludeDuplicateRecipientAddress: unref(internalExcludeDuplicateRecipientAddress),
              "onUpdate:excludeDuplicateRecipientAddress": _cache[15] || (_cache[15] = $event => isRef(internalExcludeDuplicateRecipientAddress) ? internalExcludeDuplicateRecipientAddress.value = $event : null),
              recipients: unref(internalRecipients),
              "onUpdate:recipients": [_cache[16] || (_cache[16] = $event => isRef(internalRecipients) ? internalRecipients.value = $event : null), onRecipientsUpdated],
              communicationListGroupName: (_props$communication = __props.communicationListGroups.find(f => f.value === selectedCommunicationListGuidOrManualOrEmptyString.value)) === null || _props$communication === void 0 ? void 0 : _props$communication.text,
              getTooltipRef: getTooltipRef,
              isAddingIndividualsToRecipientListsDisabled: __props.isAddingIndividualsToRecipientListsDisabled,
              isDeletingIndividualsFromRecipientListsDisabled: __props.isDeletingIndividualsToRecipientListsDisabled,
              isBulkCommunication: __props.isBulkCommunication,
              isDuplicatePreventionOptionShown: __props.isDuplicatePreventionOptionShown
            }, null, 8, ["modelValue", "excludeDuplicateRecipientAddress", "recipients", "communicationListGroupName", "isAddingIndividualsToRecipientListsDisabled", "isDeletingIndividualsFromRecipientListsDisabled", "isBulkCommunication", "isDuplicatePreventionOptionShown"])], 512);
          };
        }
      });

      var css_248z = "@import \"/Styles/RockFont/style.css\";@import \"/Styles/Blocks/Shared/Devices.css\";.mediums-section[data-v-4d4a084c]{display:grid;gap:var(--spacing-large);grid-template-columns:repeat(auto-fill,minmax(200px,250px));grid-template-rows:auto auto auto auto auto;padding-left:2px}.medium[data-v-4d4a084c]{border:1px solid var(--color-interface-soft);border-radius:var(--rounded-small);cursor:pointer;display:grid;gap:var(--spacing-xsmall);grid-row:span 5;grid-template-rows:subgrid;padding:var(--spacing-medium);text-align:center;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}.medium.selected[data-v-4d4a084c]{border:var(--focus-state-border);box-shadow:var(--focus-state-shadow)}.medium-content[data-v-4d4a084c]{display:grid;gap:var(--spacing-xsmall);grid-row:span 5;grid-template-rows:subgrid}.medium-content .label[data-v-4d4a084c]{margin-left:auto;margin-right:auto;width:fit-content}.medium-content small[data-v-4d4a084c]{color:var(--color-interface-medium)}.medium-content h5[data-v-4d4a084c]{margin:0}.medium-content i[data-v-4d4a084c]{color:var(--color-interface-stronger)}.medium .ti-circle-dot[data-v-4d4a084c]{color:var(--color-primary)}.wizard-start-container[data-v-4d4a084c]{display:flex;flex-direction:column;height:100%}.communication-list-group-container[data-v-4d4a084c]{display:flex;flex-direction:row;gap:var(--spacing-xsmall)}.communication-list-container[data-v-4d4a084c]{flex:1}[data-v-4d4a084c] .panel-body-wizard{display:flex;flex:1;flex-direction:column;overflow:hidden}.panel-body-contents[data-v-4d4a084c]{flex:1;overflow-x:hidden;overflow-y:auto}";
      styleInject(css_248z);

      script$1.__scopeId = "data-v-4d4a084c";
      script$1.__file = "src/Communication/CommunicationEntryWizard/wizardStartStep.partial.obs";

      var script = exports('default', defineComponent({
        __name: 'communicationEntryWizard',
        setup(__props) {
          var _config$recipients, _config$templates, _config$communication, _config$communication2, _config$communication3, _config$communication4, _config$communication5, _config$communication6, _config$communication7, _config$communication8, _config$communication9, _config$communication10, _ref, _config$communication11, _config$communication12, _config$communication13, _config$communication14, _config$communication15, _config$communication16, _config$communication17, _config$communication18, _config$communication19, _config$communication20, _config$communication21, _config$communication22, _config$communication23, _config$communication24, _config$communication25, _config$communication26, _config$communication27, _config$communication28, _config$communication29, _config$communication30, _config$communication31, _config$communication32, _config$communication33, _config$communication34, _config$communication35, _config$communication36, _config$communication37, _config$communication38, _config$communication39, _config$communication40, _config$communication41, _config$communication42, _config$communication43, _config$communication44, _config$communication45, _config$communication46, _config$communication47, _config$communication48, _config$communication49, _config$communication50, _config$communication51, _config$communication52, _config$communication53, _config$communication54, _config$communication55, _config$communication56, _config$communication57, _config$communication58;
          var config = useConfigurationValues();
          var securityGrant = getSecurityGrant(config.securityGrantToken);
          provideSecurityGrant(securityGrant);
          var personPreferencesHelper = usePersonPreferencesHelper();
          var invokeBlockAction = useInvokeBlockActionHelper();
          var stepTransitions = {
            "Configure Communication": () => "Choose Template",
            "Choose Template": () => {
              switch (communicationType.value) {
                case CommunicationType.Email:
                  return "Email Settings";
                case CommunicationType.SMS:
                  return "SMS Editor";
                case CommunicationType.PushNotification:
                  return "Push Notification Editor";
                case CommunicationType.RecipientPreference:
                  if (allowedMediums.value.includes(CommunicationType.Email)) {
                    return "Email Settings";
                  } else if (allowedMediums.value.includes(CommunicationType.SMS)) {
                    return "SMS Editor";
                  } else {
                    return null;
                  }
                default:
                  console.error("Unknown communication type: ".concat(communicationType.value));
                  return null;
              }
            },
            "Email Settings": () => "Email Builder",
            "Email Builder": () => {
              if (communicationType.value === CommunicationType.RecipientPreference) {
                if (allowedMediums.value.includes(CommunicationType.SMS)) {
                  return "SMS Editor";
                } else {
                  return "Review & Confirm";
                }
              } else {
                return "Review & Confirm";
              }
            },
            "SMS Editor": () => "Review & Confirm",
            "Push Notification Editor": () => "Review & Confirm",
            "Review & Confirm": () => {
              if (reviewAndConfirmNextAction.value === "save") {
                return "Communication Saved";
              } else {
                return "Sending Communication";
              }
            },
            "Sending Communication": () => "Communication Queued",
            "Communication Queued": () => null,
            "Communication Saved": () => null
          };
          var messagePreviewCache = useCache({
            maxSize: 10
          });
          var steps = [];
          var previousSteps = steps.length > 1 ? steps.slice(0, steps.length - 1) : [];
          var step = ref(steps.length ? steps[steps.length - 1] : "Configure Communication");
          var recipients = ref((_config$recipients = config.recipients) !== null && _config$recipients !== void 0 ? _config$recipients : []);
          var isFetchingRecipients = ref(false);
          var communicationEntryWizardElement = ref();
          var sendingProgressMessage = ref("");
          var sendingCompletionPercentage = ref(0);
          var isFetchingCommunicationTemplate = ref(false);
          var communicationTemplateDetail = ref(config.communicationTemplateDetail);
          var saveAsCommunicationTemplateDetail = ref(config.communicationTemplateDetail);
          var saveAsCommunicationTemplateBodyWidth = ref();
          var saveAsCommunicationTemplateApi = shallowRef(null);
          var hasDetailBlockOnCurrentPage = ref(config.hasDetailBlockOnCurrentPage);
          var finalMessage = ref("");
          var finalMessageAlertType = ref(AlertType.Default);
          var wasNextButtonClickedOnce = ref(false);
          var wasRecipientListModifiedOnce = ref(false);
          var reviewAndConfirmNextAction = ref("send");
          var wasCommunicationTemplateChanged = ref(false);
          var isSaveCommunicationTemplateModalShown = ref(false);
          var communicationTemplates = ref((_config$templates = config.templates) !== null && _config$templates !== void 0 ? _config$templates : []);
          var previewAsType = ref(PreviewAsType.Person);
          var previewAsPersonAlias = ref();
          var previewAsPersonalizationSegment = ref();
          var bccEmails = ref((_config$communication = (_config$communication2 = config.communication) === null || _config$communication2 === void 0 ? void 0 : _config$communication2.bccEmails) !== null && _config$communication !== void 0 ? _config$communication : "");
          var ccEmails = ref((_config$communication3 = (_config$communication4 = config.communication) === null || _config$communication4 === void 0 ? void 0 : _config$communication4.ccEmails) !== null && _config$communication3 !== void 0 ? _config$communication3 : "");
          var communicationId = ref((_config$communication5 = config.communication) === null || _config$communication5 === void 0 ? void 0 : _config$communication5.communicationId);
          var communicationGuid = ref((_config$communication6 = (_config$communication7 = config.communication) === null || _config$communication7 === void 0 ? void 0 : _config$communication7.communicationGuid) !== null && _config$communication6 !== void 0 ? _config$communication6 : newGuid());
          var communicationListGroupGuid = ref((_config$communication8 = config.communication) === null || _config$communication8 === void 0 ? void 0 : _config$communication8.communicationListGroupGuid);
          var communicationName = ref((_config$communication9 = (_config$communication10 = config.communication) === null || _config$communication10 === void 0 ? void 0 : _config$communication10.communicationName) !== null && _config$communication9 !== void 0 ? _config$communication9 : "");
          var communicationTemplateGuid = ref((_ref = (_config$communication11 = (_config$communication12 = config.communication) === null || _config$communication12 === void 0 ? void 0 : _config$communication12.communicationTemplateGuid) !== null && _config$communication11 !== void 0 ? _config$communication11 : (_config$communication13 = config.communicationTemplateDetail) === null || _config$communication13 === void 0 ? void 0 : _config$communication13.guid) !== null && _ref !== void 0 ? _ref : personPreferencesHelper.getCommunicationTemplateGuid());
          var communicationTopicValue = ref((_config$communication14 = config.communication) === null || _config$communication14 === void 0 ? void 0 : _config$communication14.communicationTopicValue);
          var communicationType = ref((_config$communication15 = (_config$communication16 = config.communication) === null || _config$communication16 === void 0 ? void 0 : _config$communication16.communicationType) !== null && _config$communication15 !== void 0 ? _config$communication15 : CommunicationType.Email);
          var emailAttachmentBinaryFiles = ref((_config$communication17 = config.communication) === null || _config$communication17 === void 0 ? void 0 : _config$communication17.emailAttachmentBinaryFiles);
          var enabledLavaCommands = ref((_config$communication18 = config.communication) === null || _config$communication18 === void 0 ? void 0 : _config$communication18.enabledLavaCommands);
          var excludeDuplicateRecipientAddress = ref((_config$communication19 = (_config$communication20 = config.communication) === null || _config$communication20 === void 0 ? void 0 : _config$communication20.excludeDuplicateRecipientAddress) !== null && _config$communication19 !== void 0 ? _config$communication19 : false);
          var fromEmail = ref((_config$communication21 = (_config$communication22 = config.communication) === null || _config$communication22 === void 0 ? void 0 : _config$communication22.fromEmail) !== null && _config$communication21 !== void 0 ? _config$communication21 : "");
          var fromName = ref((_config$communication23 = (_config$communication24 = config.communication) === null || _config$communication24 === void 0 ? void 0 : _config$communication24.fromName) !== null && _config$communication23 !== void 0 ? _config$communication23 : "");
          var futureSendDateTime = ref((_config$communication25 = config.communication) === null || _config$communication25 === void 0 ? void 0 : _config$communication25.futureSendDateTime);
          var individualRecipientPersonAliasGuids = ref((_config$communication26 = config.communication) === null || _config$communication26 === void 0 ? void 0 : _config$communication26.individualRecipientPersonAliasGuids);
          var isBulkCommunication = ref((_config$communication27 = (_config$communication28 = config.communication) === null || _config$communication28 === void 0 ? void 0 : _config$communication28.isBulkCommunication) !== null && _config$communication27 !== void 0 ? _config$communication27 : false);
          var message = ref((_config$communication29 = (_config$communication30 = config.communication) === null || _config$communication30 === void 0 ? void 0 : _config$communication30.message) !== null && _config$communication29 !== void 0 ? _config$communication29 : "");
          var personalizationSegments = ref((_config$communication31 = config.communication) === null || _config$communication31 === void 0 ? void 0 : _config$communication31.personalizationSegments);
          var pushData = ref((_config$communication32 = config.communication) === null || _config$communication32 === void 0 ? void 0 : _config$communication32.pushData);
          var pushImageBinaryFileGuid = ref((_config$communication33 = config.communication) === null || _config$communication33 === void 0 ? void 0 : _config$communication33.pushImageBinaryFileGuid);
          var pushMessage = ref((_config$communication34 = (_config$communication35 = config.communication) === null || _config$communication35 === void 0 ? void 0 : _config$communication35.pushMessage) !== null && _config$communication34 !== void 0 ? _config$communication34 : "");
          var pushOpenAction = ref((_config$communication36 = (_config$communication37 = config.communication) === null || _config$communication37 === void 0 ? void 0 : _config$communication37.pushOpenAction) !== null && _config$communication36 !== void 0 ? _config$communication36 : PushOpenAction.NoAction);
          var pushOpenMessage = ref((_config$communication38 = (_config$communication39 = config.communication) === null || _config$communication39 === void 0 ? void 0 : _config$communication39.pushOpenMessage) !== null && _config$communication38 !== void 0 ? _config$communication38 : "");
          var pushOpenMessageJson = ref((_config$communication40 = (_config$communication41 = config.communication) === null || _config$communication41 === void 0 ? void 0 : _config$communication41.pushOpenMessageJson) !== null && _config$communication40 !== void 0 ? _config$communication40 : undefined);
          var pushTitle = ref((_config$communication42 = (_config$communication43 = config.communication) === null || _config$communication43 === void 0 ? void 0 : _config$communication43.pushTitle) !== null && _config$communication42 !== void 0 ? _config$communication42 : "");
          var replyToEmail = ref((_config$communication44 = (_config$communication45 = config.communication) === null || _config$communication45 === void 0 ? void 0 : _config$communication45.replyToEmail) !== null && _config$communication44 !== void 0 ? _config$communication44 : "");
          var segmentCriteria = ref((_config$communication46 = (_config$communication47 = config.communication) === null || _config$communication47 === void 0 ? void 0 : _config$communication47.segmentCriteria) !== null && _config$communication46 !== void 0 ? _config$communication46 : SegmentCriteria.All);
          var smsAttachmentBinaryFiles = ref((_config$communication48 = config.communication) === null || _config$communication48 === void 0 ? void 0 : _config$communication48.smsAttachmentBinaryFiles);
          var smsFromSystemPhoneNumberGuid = ref((_config$communication49 = config.communication) === null || _config$communication49 === void 0 ? void 0 : _config$communication49.smsFromSystemPhoneNumberGuid);
          var smsMessage = ref((_config$communication50 = (_config$communication51 = config.communication) === null || _config$communication51 === void 0 ? void 0 : _config$communication51.smsMessage) !== null && _config$communication50 !== void 0 ? _config$communication50 : "");
          var status = ref((_config$communication52 = (_config$communication53 = config.communication) === null || _config$communication53 === void 0 ? void 0 : _config$communication53.status) !== null && _config$communication52 !== void 0 ? _config$communication52 : CommunicationStatus.Transient);
          var subject = ref((_config$communication54 = (_config$communication55 = config.communication) === null || _config$communication55 === void 0 ? void 0 : _config$communication55.subject) !== null && _config$communication54 !== void 0 ? _config$communication54 : "");
          var testSmsPhoneNumber = ref((_config$communication56 = config.communication) === null || _config$communication56 === void 0 ? void 0 : _config$communication56.testSmsPhoneNumber);
          var testEmailAddress = ref((_config$communication57 = (_config$communication58 = config.communication) === null || _config$communication58 === void 0 ? void 0 : _config$communication58.testEmailAddress) !== null && _config$communication57 !== void 0 ? _config$communication57 : "");
          var isBulkCommunicationForced = computed(() => {
            var isNewCommunication = () => isNullish(communicationId.value) || communicationId.value === 0;
            var isTransientCommunication = () => status.value === CommunicationStatus.Transient;
            var isEmailCommunication = () => allowedMediums.value.includes(CommunicationType.Email) && (communicationType.value === CommunicationType.Email || communicationType.value === CommunicationType.RecipientPreference);
            var isBulkEmailThresholdExceeded = () => !isNullish(config.bulkEmailThreshold) && emailRecipients.value.length > config.bulkEmailThreshold;
            return (isNewCommunication() || isTransientCommunication()) && isEmailCommunication() && isBulkEmailThresholdExceeded();
          });
          var allowedMediums = computed(() => {
            var _config$mediums;
            var allowedCommunicationTypes = [];
            function tryAdd(allowedCommunicationType) {
              if (!allowedCommunicationTypes.includes(allowedCommunicationType)) {
                allowedCommunicationTypes.push(allowedCommunicationType);
              }
            }
            if ((_config$mediums = config.mediums) !== null && _config$mediums !== void 0 && _config$mediums.length) {
              var _iterator = _createForOfIteratorHelper(config.mediums.filter(medium => !!medium.value).map(medium => medium.value)),
                _step;
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var mediumGuid = _step.value;
                  if (areEqual(mediumGuid, EntityType.CommunicationMediumEmail)) {
                    tryAdd(CommunicationType.Email);
                  } else if (areEqual(mediumGuid, EntityType.CommunicationMediumSms)) {
                    tryAdd(CommunicationType.SMS);
                  } else if (areEqual(mediumGuid, EntityType.CommunicationMediumPushNotification)) {
                    tryAdd(CommunicationType.PushNotification);
                  } else if ((mediumGuid === null || mediumGuid === void 0 ? void 0 : mediumGuid.toLocaleLowerCase()) === "recipient preference") {
                    tryAdd(CommunicationType.RecipientPreference);
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }
            return allowedCommunicationTypes;
          });
          var communicationTemplateListItems = computed(() => {
            if (!communicationTemplates.value) {
              return [];
            } else {
              return communicationTemplates.value.map(t => ({
                text: t.name,
                value: t.guid
              }));
            }
          });
          var nextStep = computed(() => {
            var _stepTransitions$step;
            return (_stepTransitions$step = stepTransitions[step.value]) === null || _stepTransitions$step === void 0 ? void 0 : _stepTransitions$step.call(stepTransitions);
          });
          var emailRecipients = computed(() => {
            return recipients.value.filter(r => r.isEmailAllowed);
          });
          var smsRecipients = computed(() => {
            return recipients.value.filter(r => r.isSmsAllowed);
          });
          var pushNotificationRecipients = computed(() => {
            return recipients.value.filter(r => r.isPushAllowed);
          });
          var personalPreferenceRecipients = computed(() => {
            return recipients.value.filter(r => r.isEmailAllowed || r.isSmsAllowed);
          });
          var selectedMediumRecipients = computed(() => {
            switch (communicationType.value) {
              case CommunicationType.Email:
                return emailRecipients.value;
              case CommunicationType.SMS:
                return smsRecipients.value;
              case CommunicationType.PushNotification:
                return pushNotificationRecipients.value;
              case CommunicationType.RecipientPreference:
              default:
                return personalPreferenceRecipients.value;
            }
          });
          var communicationListGroupName = computed(() => {
            if (communicationListGroupGuid.value) {
              var _config$communication59;
              var communicationListGroup = (_config$communication59 = config.communicationListGroups) === null || _config$communication59 === void 0 ? void 0 : _config$communication59.find(c => areEqual(c.value, communicationListGroupGuid.value));
              return communicationListGroup === null || communicationListGroup === void 0 ? void 0 : communicationListGroup.text;
            } else {
              return null;
            }
          });
          var personalizationSegmentItems = computed(() => {
            var _config$personalizati, _personalizationSegme;
            var authorizedPersonalizationSegments = (_config$personalizati = config.personalizationSegments) !== null && _config$personalizati !== void 0 ? _config$personalizati : [];
            var communicationPersonalizationSegments = (_personalizationSegme = personalizationSegments.value) !== null && _personalizationSegme !== void 0 ? _personalizationSegme : [];
            return Enumerable.from(authorizedPersonalizationSegments).concat(communicationPersonalizationSegments).distinctBy(c => c.value).toArray();
          });
          var personalizationSegmentNames = computed(() => {
            if (!personalizationSegments.value) {
              return personalizationSegments.value;
            }
            return Enumerable.from(personalizationSegments.value).select(c => c.text).ofType(t => !isNullOrWhiteSpace(t)).toArray();
          });
          var emailAttachmentNames = computed(() => {
            var _emailAttachmentBinar;
            if ((_emailAttachmentBinar = emailAttachmentBinaryFiles.value) !== null && _emailAttachmentBinar !== void 0 && _emailAttachmentBinar.length) {
              var names = emailAttachmentBinaryFiles.value.map(e => e.text).filter(t => !!t).map(t => t);
              return names.length ? names : null;
            } else {
              return null;
            }
          });
          var smsAttachmentNames = computed(() => {
            var _smsAttachmentBinaryF;
            if ((_smsAttachmentBinaryF = smsAttachmentBinaryFiles.value) !== null && _smsAttachmentBinaryF !== void 0 && _smsAttachmentBinaryF.length) {
              var names = smsAttachmentBinaryFiles.value.map(e => e.text).filter(t => !!t).map(t => t);
              return names.length ? names : null;
            } else {
              return null;
            }
          });
          var smsFromNumberName = computed(() => {
            if (smsAttachmentBinaryFiles.value) {
              var _config$smsFromNumber, _t$text;
              var t = (_config$smsFromNumber = config.smsFromNumbers) === null || _config$smsFromNumber === void 0 ? void 0 : _config$smsFromNumber.find(n => {
                return areEqual(smsFromSystemPhoneNumberGuid.value, n.value);
              });
              return (_t$text = t === null || t === void 0 ? void 0 : t.text) !== null && _t$text !== void 0 ? _t$text : "";
            } else {
              return "";
            }
          });
          var smsAttachmentLinks = computed(() => {
            var _smsAttachmentBinaryF2;
            if ((_smsAttachmentBinaryF2 = smsAttachmentBinaryFiles.value) !== null && _smsAttachmentBinaryF2 !== void 0 && _smsAttachmentBinaryF2.length) {
              return smsAttachmentBinaryFiles.value.map(binaryFileAttachment => {
                var _toGuidOrNull, _binaryFileAttachment;
                var binaryFileGuid = (_toGuidOrNull = toGuidOrNull(binaryFileAttachment === null || binaryFileAttachment === void 0 ? void 0 : binaryFileAttachment.value)) !== null && _toGuidOrNull !== void 0 ? _toGuidOrNull : emptyGuid;
                return {
                  fileName: (_binaryFileAttachment = binaryFileAttachment.text) !== null && _binaryFileAttachment !== void 0 ? _binaryFileAttachment : "",
                  binaryFileGuid,
                  url: "/GetFile.ashx?guid=".concat(binaryFileGuid, "&fileName=").concat(binaryFileAttachment.text)
                };
              });
            } else {
              return [];
            }
          });
          var emailRecipientsLabel = computed(() => {
            return getRecipientsLabel(emailRecipients.value.length);
          });
          var pushNotificationRecipientsLabel = computed(() => {
            return getRecipientsLabel(pushNotificationRecipients.value.length);
          });
          var selectedMediumRecipientsLabel = computed(() => {
            return getRecipientsLabel(selectedMediumRecipients.value.length);
          });
          var smsRecipientsLabel = computed(() => {
            return getRecipientsLabel(smsRecipients.value.length);
          });
          var isIncompatibleCommunicationTemplateNotificationShown = computed(() => {
            return !isNullish(communicationId.value) && communicationId.value > 0 && !isNullOrWhiteSpace(message.value) && !isNullish(communicationTemplateDetail.value) && !communicationTemplateDetail.value.isWizardSupported;
          });
          var isUseSimpleEditorButtonShown = computed(() => {
            var _config$navigationUrl;
            if (!((_config$navigationUrl = config.navigationUrls) !== null && _config$navigationUrl !== void 0 && _config$navigationUrl["SimpleCommunicationPage"]) || wasNextButtonClickedOnce.value || wasRecipientListModifiedOnce.value) {
              return false;
            } else {
              return true;
            }
          });
          var emailTo = computed(() => {
            if (communicationListGroupName.value) {
              return communicationListGroupName.value;
            } else {
              var _emailRecipients$valu;
              return (_emailRecipients$valu = emailRecipients.value[0]) === null || _emailRecipients$valu === void 0 ? void 0 : _emailRecipients$valu.email;
            }
          });
          function getRecipientsLabel(recipientCount) {
            return "".concat(recipientCount, " ").concat(pluralize("Recipient", recipientCount));
          }
          var tokenSource = new CancellationTokenSource();
          var cmanager = {
            get token() {
              return tokenSource.token;
            },
            refreshToken() {
              tokenSource.cancel();
              tokenSource = new CancellationTokenSource();
              return tokenSource.token;
            }
          };
          function getRecipients() {
            return _getRecipients.apply(this, arguments);
          }
          function _getRecipients() {
            _getRecipients = _asyncToGenerator(function* () {
              var ctoken = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : CancellationTokenNone;
              if (!ctoken.isCancellationRequested) {
                isFetchingRecipients.value = true;
              }
              var result = yield invokeBlockAction.getRecipients(getCommunicationBag(), ctoken);
              if (!ctoken.isCancellationRequested) {
                isFetchingRecipients.value = false;
              }
              return result;
            });
            return _getRecipients.apply(this, arguments);
          }
          function replaceQueryParam(key, value) {
            if (typeof window !== "undefined" && window.location) {
              var url = new URL(window.location.href);
              url.searchParams.set(key, value);
              history.replaceState(null, "", url.toString());
            }
          }
          function scrollToTopOfBlock() {
            if (communicationEntryWizardElement.value) {
              scrollElementStartToTop(communicationEntryWizardElement.value);
            }
          }
          function setStep(value) {
            if (value !== step.value) {
              previousSteps.push(step.value);
              step.value = value;
              nextTick(scrollToTopOfBlock);
            }
          }
          function getCommunicationBag() {
            return {
              communicationId: communicationId.value,
              communicationGuid: communicationGuid.value,
              communicationListGroupGuid: communicationListGroupGuid.value,
              communicationName: communicationName.value,
              communicationTemplateGuid: communicationTemplateGuid.value,
              communicationTopicValue: communicationTopicValue.value,
              communicationType: communicationType.value,
              enabledLavaCommands: enabledLavaCommands.value,
              excludeDuplicateRecipientAddress: excludeDuplicateRecipientAddress.value,
              futureSendDateTime: futureSendDateTime.value,
              individualRecipientPersonAliasGuids: individualRecipientPersonAliasGuids.value,
              isBulkCommunication: isBulkCommunication.value,
              personalizationSegments: personalizationSegments.value,
              segmentCriteria: segmentCriteria.value,
              status: status.value,
              ccEmails: ccEmails.value || null,
              bccEmails: bccEmails.value || null,
              fromEmail: fromEmail.value || null,
              fromName: fromName.value || null,
              message: message.value || null,
              replyToEmail: replyToEmail.value || null,
              subject: subject.value || null,
              emailAttachmentBinaryFiles: emailAttachmentBinaryFiles.value,
              testEmailAddress: testEmailAddress.value || null,
              smsAttachmentBinaryFiles: smsAttachmentBinaryFiles.value,
              smsFromSystemPhoneNumberGuid: smsFromSystemPhoneNumberGuid.value,
              smsMessage: smsMessage.value || null,
              testSmsPhoneNumber: testSmsPhoneNumber.value,
              pushData: pushData.value,
              pushImageBinaryFileGuid: pushImageBinaryFileGuid.value,
              pushMessage: pushMessage.value || null,
              pushOpenAction: pushOpenAction.value,
              pushOpenMessage: pushOpenMessage.value || null,
              pushOpenMessageJson: pushOpenMessageJson.value,
              pushTitle: pushTitle.value || null
            };
          }
          function updateFieldsFromCommunicationBag(bag) {
            var _bag$communicationNam, _bag$communicationTyp, _bag$excludeDuplicate, _bag$isBulkCommunicat, _bag$personalizationS, _bag$segmentCriteria, _bag$status, _bag$bccEmails, _bag$ccEmails, _bag$fromEmail, _bag$fromName, _bag$message, _bag$replyToEmail, _bag$subject, _bag$testEmailAddress, _bag$pushOpenAction, _bag$pushOpenMessageJ, _bag$pushTitle, _bag$pushOpenMessage;
            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            communicationGuid.value = bag.communicationGuid;
            communicationId.value = bag.communicationId;
            communicationListGroupGuid.value = bag.communicationListGroupGuid;
            communicationName.value = (_bag$communicationNam = bag.communicationName) !== null && _bag$communicationNam !== void 0 ? _bag$communicationNam : "";
            communicationTemplateGuid.value = bag.communicationTemplateGuid;
            communicationTopicValue.value = bag.communicationTopicValue;
            communicationType.value = (_bag$communicationTyp = bag.communicationType) !== null && _bag$communicationTyp !== void 0 ? _bag$communicationTyp : CommunicationType.Email;
            enabledLavaCommands.value = bag.enabledLavaCommands;
            excludeDuplicateRecipientAddress.value = (_bag$excludeDuplicate = bag.excludeDuplicateRecipientAddress) !== null && _bag$excludeDuplicate !== void 0 ? _bag$excludeDuplicate : false;
            futureSendDateTime.value = bag.futureSendDateTime;
            individualRecipientPersonAliasGuids.value = bag.individualRecipientPersonAliasGuids;
            isBulkCommunication.value = (_bag$isBulkCommunicat = bag.isBulkCommunication) !== null && _bag$isBulkCommunicat !== void 0 ? _bag$isBulkCommunicat : false;
            personalizationSegments.value = (_bag$personalizationS = bag.personalizationSegments) !== null && _bag$personalizationS !== void 0 ? _bag$personalizationS : [];
            segmentCriteria.value = (_bag$segmentCriteria = bag.segmentCriteria) !== null && _bag$segmentCriteria !== void 0 ? _bag$segmentCriteria : SegmentCriteria.All;
            status.value = (_bag$status = bag.status) !== null && _bag$status !== void 0 ? _bag$status : CommunicationStatus.Transient;
            bccEmails.value = (_bag$bccEmails = bag.bccEmails) !== null && _bag$bccEmails !== void 0 ? _bag$bccEmails : "";
            ccEmails.value = (_bag$ccEmails = bag.ccEmails) !== null && _bag$ccEmails !== void 0 ? _bag$ccEmails : "";
            emailAttachmentBinaryFiles.value = bag.emailAttachmentBinaryFiles;
            fromEmail.value = (_bag$fromEmail = bag.fromEmail) !== null && _bag$fromEmail !== void 0 ? _bag$fromEmail : "";
            fromName.value = (_bag$fromName = bag.fromName) !== null && _bag$fromName !== void 0 ? _bag$fromName : "";
            message.value = (_bag$message = bag.message) !== null && _bag$message !== void 0 ? _bag$message : "";
            replyToEmail.value = (_bag$replyToEmail = bag.replyToEmail) !== null && _bag$replyToEmail !== void 0 ? _bag$replyToEmail : "";
            subject.value = (_bag$subject = bag.subject) !== null && _bag$subject !== void 0 ? _bag$subject : "";
            testEmailAddress.value = (_bag$testEmailAddress = bag.testEmailAddress) !== null && _bag$testEmailAddress !== void 0 ? _bag$testEmailAddress : "";
            smsAttachmentBinaryFiles.value = bag.smsAttachmentBinaryFiles;
            smsFromSystemPhoneNumberGuid.value = bag.smsFromSystemPhoneNumberGuid;
            testSmsPhoneNumber.value = bag.testSmsPhoneNumber;
            if (!options.ignoreSmsMessage) {
              var _bag$smsMessage;
              smsMessage.value = (_bag$smsMessage = bag.smsMessage) !== null && _bag$smsMessage !== void 0 ? _bag$smsMessage : "";
            }
            pushData.value = bag.pushData;
            pushOpenAction.value = (_bag$pushOpenAction = bag.pushOpenAction) !== null && _bag$pushOpenAction !== void 0 ? _bag$pushOpenAction : PushOpenAction.NoAction;
            pushOpenMessageJson.value = (_bag$pushOpenMessageJ = bag.pushOpenMessageJson) !== null && _bag$pushOpenMessageJ !== void 0 ? _bag$pushOpenMessageJ : undefined;
            pushTitle.value = (_bag$pushTitle = bag.pushTitle) !== null && _bag$pushTitle !== void 0 ? _bag$pushTitle : "";
            pushImageBinaryFileGuid.value = bag.pushImageBinaryFileGuid;
            pushOpenMessage.value = (_bag$pushOpenMessage = bag.pushOpenMessage) !== null && _bag$pushOpenMessage !== void 0 ? _bag$pushOpenMessage : "";
            if (!options.ignorePushMessage) {
              var _bag$pushMessage;
              pushMessage.value = (_bag$pushMessage = bag.pushMessage) !== null && _bag$pushMessage !== void 0 ? _bag$pushMessage : "";
            }
          }
          function startRealTime() {
            return _startRealTime.apply(this, arguments);
          }
          function _startRealTime() {
            _startRealTime = _asyncToGenerator(function* () {
              var topic = yield getTopic("Rock.RealTime.Topics.TaskActivityProgressTopic");
              topic.onDisconnected(_asyncToGenerator(function* () {
                yield startRealTime();
              }));
              topic.on("updateTaskProgress", onSendProgressUpdated);
              topic.on("taskStarted", onSendStarted);
              topic.on("taskCompleted", onSendCompleted);
              yield invokeBlockAction.subscribeToRealTime({
                connectionId: topic.connectionId,
                communicationGuid: communicationGuid.value
              });
            });
            return _startRealTime.apply(this, arguments);
          }
          function moveToNextStep() {
            if (nextStep.value) {
              setStep(nextStep.value);
            }
          }
          function onShortLinkCheckToken(_x, _x2) {
            return _onShortLinkCheckToken.apply(this, arguments);
          }
          function _onShortLinkCheckToken() {
            _onShortLinkCheckToken = _asyncToGenerator(function* (token, siteId) {
              var bag = {
                siteId,
                token
              };
              var result = yield invokeBlockAction.checkShortLinkToken(bag);
              if (result.isSuccess && result.data) {
                return result.data;
              } else {
                return token;
              }
            });
            return _onShortLinkCheckToken.apply(this, arguments);
          }
          function onShortLinkGetPageId(_x3) {
            return _onShortLinkGetPageId.apply(this, arguments);
          }
          function _onShortLinkGetPageId() {
            _onShortLinkGetPageId = _asyncToGenerator(function* (pageGuid) {
              var result = yield invokeBlockAction.getShortLinkPageId(pageGuid);
              if (result.isSuccess) {
                return result.data;
              } else {
                return null;
              }
            });
            return _onShortLinkGetPageId.apply(this, arguments);
          }
          function onOverwriteExistingCommunicationTemplate(_x4, _x5) {
            return _onOverwriteExistingCommunicationTemplate.apply(this, arguments);
          }
          function _onOverwriteExistingCommunicationTemplate() {
            _onOverwriteExistingCommunicationTemplate = _asyncToGenerator(function* (bag, blockActionCallbacks) {
              var _result$data, _result$data2;
              var result = yield invokeBlockAction.saveCommunicationTemplate(bag);
              if (result.isSuccess && (_result$data = result.data) !== null && _result$data !== void 0 && _result$data.communicationTemplateDetail && (_result$data2 = result.data) !== null && _result$data2 !== void 0 && _result$data2.communicationTemplateListItem) {
                var _newGuid = result.data.communicationTemplateDetail.guid;
                communicationTemplateDetail.value = result.data.communicationTemplateDetail;
                communicationTemplateGuid.value = _newGuid;
                communicationTemplates.value = [...communicationTemplates.value.filter(ct => !areEqual(ct.guid, _newGuid)), result.data.communicationTemplateListItem];
                blockActionCallbacks.onSuccess();
              } else {
                var _result$errorMessage;
                blockActionCallbacks.onError((_result$errorMessage = result.errorMessage) !== null && _result$errorMessage !== void 0 ? _result$errorMessage : "An error occurred while saving.");
              }
            });
            return _onOverwriteExistingCommunicationTemplate.apply(this, arguments);
          }
          function onSaveAsNewCommunicationTemplate(_x6, _x7) {
            return _onSaveAsNewCommunicationTemplate.apply(this, arguments);
          }
          function _onSaveAsNewCommunicationTemplate() {
            _onSaveAsNewCommunicationTemplate = _asyncToGenerator(function* (bag, blockActionCallbacks) {
              var _result$data3, _result$data4;
              var result = yield invokeBlockAction.saveAsCommunicationTemplate(bag);
              if (result.isSuccess && (_result$data3 = result.data) !== null && _result$data3 !== void 0 && _result$data3.communicationTemplateDetail && (_result$data4 = result.data) !== null && _result$data4 !== void 0 && _result$data4.communicationTemplateListItem) {
                blockActionCallbacks.onSuccess();
                var _newGuid2 = result.data.communicationTemplateDetail.guid;
                communicationTemplateDetail.value = result.data.communicationTemplateDetail;
                communicationTemplateGuid.value = _newGuid2;
                communicationTemplates.value = [...communicationTemplates.value.filter(ct => !areEqual(ct.guid, _newGuid2)), result.data.communicationTemplateListItem];
              } else {
                var _result$errorMessage2;
                blockActionCallbacks.onError((_result$errorMessage2 = result.errorMessage) !== null && _result$errorMessage2 !== void 0 ? _result$errorMessage2 : "An error occurred while saving.");
              }
            });
            return _onSaveAsNewCommunicationTemplate.apply(this, arguments);
          }
          function onNextStepClicked() {
            wasNextButtonClickedOnce.value = true;
            moveToNextStep();
          }
          function onPreviousStepClicked() {
            var _previousSteps$pop;
            step.value = (_previousSteps$pop = previousSteps.pop()) !== null && _previousSteps$pop !== void 0 ? _previousSteps$pop : "Configure Communication";
            nextTick(scrollToTopOfBlock);
          }
          function onCommunicationListGroupGuidUpdated(_x8) {
            return _onCommunicationListGroupGuidUpdated.apply(this, arguments);
          }
          function _onCommunicationListGroupGuidUpdated() {
            _onCommunicationListGroupGuidUpdated = _asyncToGenerator(function* (_value) {
              wasRecipientListModifiedOnce.value = false;
              yield updateRecipients();
            });
            return _onCommunicationListGroupGuidUpdated.apply(this, arguments);
          }
          var debouncedGetRecipients = debounceAsync(getRecipients, {
            delay: 500
          });
          function debouncedUpdateRecipients() {
            return _debouncedUpdateRecipients.apply(this, arguments);
          }
          function _debouncedUpdateRecipients() {
            _debouncedUpdateRecipients = _asyncToGenerator(function* () {
              var result = yield debouncedGetRecipients();
              if (result !== null && result !== void 0 && result.isSuccess && !isNullish(result.data)) {
                recipients.value = result.data;
              } else {
                var _result$errorMessage3;
                recipients.value = [];
                console.error((_result$errorMessage3 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage3 !== void 0 ? _result$errorMessage3 : "Unable to get recipient count.");
              }
            });
            return _debouncedUpdateRecipients.apply(this, arguments);
          }
          function updateRecipients() {
            return _updateRecipients.apply(this, arguments);
          }
          function _updateRecipients() {
            _updateRecipients = _asyncToGenerator(function* () {
              var token = cmanager.refreshToken();
              var result = yield getRecipients(token);
              if (result !== null && result !== void 0 && result.isSuccess && !isNullish(result.data)) {
                recipients.value = result.data;
              } else {
                var _result$errorMessage4;
                recipients.value = [];
                console.error((_result$errorMessage4 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage4 !== void 0 ? _result$errorMessage4 : "Unable to get recipient count.");
              }
            });
            return _updateRecipients.apply(this, arguments);
          }
          function onSaveAsTemplate(_ref2, api) {
            var html = _ref2.html,
              bodyWidth = _ref2.bodyWidth;
            if (!communicationTemplateDetail.value) {
              throw new Error("The source template is required.");
            }
            saveAsCommunicationTemplateApi.value = api;
            saveAsCommunicationTemplateBodyWidth.value = bodyWidth;
            saveAsCommunicationTemplateDetail.value = _objectSpread2(_objectSpread2({}, communicationTemplateDetail.value), {}, {
              message: html
            });
            isSaveCommunicationTemplateModalShown.value = true;
          }
          function onSendTestEmail(_x9, _x10) {
            return _onSendTestEmail.apply(this, arguments);
          }
          function _onSendTestEmail() {
            _onSendTestEmail = _asyncToGenerator(function* (message, callbacks) {
              var bag = getCommunicationBag();
              bag.communicationType = CommunicationType.Email;
              bag.message = message;
              var result = yield invokeBlockAction.sendTest(bag);
              if (result !== null && result !== void 0 && result.isSuccess) {
                callbacks.onSuccess();
              } else {
                var _result$errorMessage5;
                var errorMessage = (_result$errorMessage5 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage5 !== void 0 ? _result$errorMessage5 : "The test communication failed to send.";
                console.error(errorMessage);
                callbacks.onError(errorMessage);
              }
            });
            return _onSendTestEmail.apply(this, arguments);
          }
          function previewEmailProcessor(_x11, _x12, _x13) {
            return _previewEmailProcessor.apply(this, arguments);
          }
          function _previewEmailProcessor() {
            _previewEmailProcessor = _asyncToGenerator(function* (previewHtml, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId) {
              var hash = yield createHashSha256("email:".concat(previewHtml, ":").concat(previewAsPersonAliasGuid !== null && previewAsPersonAliasGuid !== void 0 ? previewAsPersonAliasGuid : "", ":").concat(previewAsPersonalizationSegmentId !== null && previewAsPersonalizationSegmentId !== void 0 ? previewAsPersonalizationSegmentId : ""));
              if (messagePreviewCache.has(hash)) {
                var cached = messagePreviewCache.get(hash);
                previewAsPersonAlias.value = cached.wasRequestedPersonFound ? cached.previewAsPersonAlias : null;
                return cached.messagePreview;
              } else {
                message.value = previewHtml;
                var result = yield invokeBlockAction.getEmailPreviewHtml(getCommunicationBag(), previewAsPersonAliasGuid, previewAsPersonalizationSegmentId);
                if (result.isSuccess && result.data) {
                  if (result.data.communication) {
                    updateFieldsFromCommunicationBag(result.data.communication);
                  }
                  messagePreviewCache.set(hash, result.data);
                  previewAsPersonAlias.value = result.data.wasRequestedPersonFound ? result.data.previewAsPersonAlias : null;
                  return result.data.messagePreview;
                } else {
                  var _result$errorMessage6, _result$errorMessage7;
                  messagePreviewCache.remove(hash);
                  console.error((_result$errorMessage6 = result.errorMessage) !== null && _result$errorMessage6 !== void 0 ? _result$errorMessage6 : "An error occurred.");
                  previewAsPersonAlias.value = null;
                  return (_result$errorMessage7 = result.errorMessage) !== null && _result$errorMessage7 !== void 0 ? _result$errorMessage7 : "An error occurred.";
                }
              }
            });
            return _previewEmailProcessor.apply(this, arguments);
          }
          function previewPushProcessor(_x14, _x15, _x16) {
            return _previewPushProcessor.apply(this, arguments);
          }
          function _previewPushProcessor() {
            _previewPushProcessor = _asyncToGenerator(function* (message, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId) {
              var hash = yield createHashSha256("push:".concat(message, ":").concat(previewAsPersonAliasGuid !== null && previewAsPersonAliasGuid !== void 0 ? previewAsPersonAliasGuid : "", ":").concat(previewAsPersonalizationSegmentId !== null && previewAsPersonalizationSegmentId !== void 0 ? previewAsPersonalizationSegmentId : ""));
              if (messagePreviewCache.has(hash)) {
                var cached = messagePreviewCache.get(hash);
                previewAsPersonAlias.value = cached.wasRequestedPersonFound ? cached.previewAsPersonAlias : null;
                return cached.messagePreview;
              } else {
                pushMessage.value = message;
                var result = yield invokeBlockAction.getPushPreview(getCommunicationBag(), previewAsPersonAliasGuid, previewAsPersonalizationSegmentId);
                if (result.isSuccess && result.data) {
                  if (result.data.communication) {
                    updateFieldsFromCommunicationBag(result.data.communication, {
                      ignorePushMessage: true
                    });
                  }
                  messagePreviewCache.set(hash, result.data);
                  previewAsPersonAlias.value = result.data.wasRequestedPersonFound === false ? null : result.data.previewAsPersonAlias;
                  return result.data.messagePreview;
                } else {
                  var _result$errorMessage8, _result$errorMessage9;
                  messagePreviewCache.remove(hash);
                  console.error((_result$errorMessage8 = result.errorMessage) !== null && _result$errorMessage8 !== void 0 ? _result$errorMessage8 : "An error occurred.");
                  previewAsPersonAlias.value = null;
                  return (_result$errorMessage9 = result.errorMessage) !== null && _result$errorMessage9 !== void 0 ? _result$errorMessage9 : "An error occurred.";
                }
              }
            });
            return _previewPushProcessor.apply(this, arguments);
          }
          function previewSmsProcessor(_x17, _x18, _x19) {
            return _previewSmsProcessor.apply(this, arguments);
          }
          function _previewSmsProcessor() {
            _previewSmsProcessor = _asyncToGenerator(function* (message, previewAsPersonAliasGuid, previewAsPersonalizationSegmentId) {
              var hash = yield createHashSha256("sms:".concat(message, ":").concat(previewAsPersonAliasGuid !== null && previewAsPersonAliasGuid !== void 0 ? previewAsPersonAliasGuid : "", ":").concat(previewAsPersonalizationSegmentId !== null && previewAsPersonalizationSegmentId !== void 0 ? previewAsPersonalizationSegmentId : ""));
              if (messagePreviewCache.has(hash)) {
                var cached = messagePreviewCache.get(hash);
                previewAsPersonAlias.value = cached.wasRequestedPersonFound ? cached.previewAsPersonAlias : null;
                return cached.messagePreview;
              } else {
                smsMessage.value = message;
                var result = yield invokeBlockAction.getSmsPreview(getCommunicationBag(), previewAsPersonAliasGuid, previewAsPersonalizationSegmentId);
                if (result.isSuccess && result.data) {
                  if (result.data.communication) {
                    updateFieldsFromCommunicationBag(result.data.communication, {
                      ignoreSmsMessage: true
                    });
                  }
                  messagePreviewCache.set(hash, result.data);
                  previewAsPersonAlias.value = result.data.wasRequestedPersonFound === false ? null : result.data.previewAsPersonAlias;
                  return result.data.messagePreview;
                } else {
                  var _result$errorMessage10, _result$errorMessage11;
                  messagePreviewCache.remove(hash);
                  console.error((_result$errorMessage10 = result.errorMessage) !== null && _result$errorMessage10 !== void 0 ? _result$errorMessage10 : "An error occurred.");
                  previewAsPersonAlias.value = null;
                  return (_result$errorMessage11 = result.errorMessage) !== null && _result$errorMessage11 !== void 0 ? _result$errorMessage11 : "An error occurred.";
                }
              }
            });
            return _previewSmsProcessor.apply(this, arguments);
          }
          function onSendTestSms(_x20) {
            return _onSendTestSms.apply(this, arguments);
          }
          function _onSendTestSms() {
            _onSendTestSms = _asyncToGenerator(function* (callbacks) {
              var bag = getCommunicationBag();
              bag.communicationType = CommunicationType.SMS;
              var result = yield invokeBlockAction.sendTest(bag);
              if (result !== null && result !== void 0 && result.isSuccess) {
                callbacks.onSuccess();
              } else {
                var _result$errorMessage12;
                console.error((_result$errorMessage12 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage12 !== void 0 ? _result$errorMessage12 : "The test communication failed to send.");
                callbacks.onError();
              }
            });
            return _onSendTestSms.apply(this, arguments);
          }
          function onReviewAndConfirmSaveCommunication(_x21) {
            return _onReviewAndConfirmSaveCommunication.apply(this, arguments);
          }
          function _onReviewAndConfirmSaveCommunication() {
            _onReviewAndConfirmSaveCommunication = _asyncToGenerator(function* (callbacks) {
              var _result$data5;
              var result = yield invokeBlockAction.save(getCommunicationBag());
              if (result !== null && result !== void 0 && result.isSuccess && result !== null && result !== void 0 && (_result$data5 = result.data) !== null && _result$data5 !== void 0 && (_result$data5 = _result$data5.communication) !== null && _result$data5 !== void 0 && _result$data5.communicationId) {
                updateFieldsFromCommunicationBag(result.data.communication);
                callbacks.onSuccess();
                reviewAndConfirmNextAction.value = "save";
                finalMessage.value = "The communication has been saved.";
                finalMessageAlertType.value = "success";
                moveToNextStep();
              } else {
                var _result$errorMessage13;
                console.error((_result$errorMessage13 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage13 !== void 0 ? _result$errorMessage13 : "The test communication failed to save.");
                callbacks.onError();
              }
            });
            return _onReviewAndConfirmSaveCommunication.apply(this, arguments);
          }
          function onSaveCommunication(_x22) {
            return _onSaveCommunication.apply(this, arguments);
          }
          function _onSaveCommunication() {
            _onSaveCommunication = _asyncToGenerator(function* (callbacks) {
              var _result$data6;
              var result = yield invokeBlockAction.save(getCommunicationBag());
              if (result !== null && result !== void 0 && result.isSuccess && result !== null && result !== void 0 && (_result$data6 = result.data) !== null && _result$data6 !== void 0 && (_result$data6 = _result$data6.communication) !== null && _result$data6 !== void 0 && _result$data6.communicationId) {
                updateFieldsFromCommunicationBag(result.data.communication);
                callbacks.onSuccess();
              } else {
                var _result$errorMessage14;
                console.error((_result$errorMessage14 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage14 !== void 0 ? _result$errorMessage14 : "The test communication failed to save.");
                callbacks.onError();
              }
            });
            return _onSaveCommunication.apply(this, arguments);
          }
          function onCommunicationTemplateGuidUpdated(_x23) {
            return _onCommunicationTemplateGuidUpdated.apply(this, arguments);
          }
          function _onCommunicationTemplateGuidUpdated() {
            _onCommunicationTemplateGuidUpdated = _asyncToGenerator(function* (value) {
              try {
                wasCommunicationTemplateChanged.value = true;
                communicationTemplateDetail.value = null;
                if (value) {
                  isFetchingCommunicationTemplate.value = true;
                  var result = yield invokeBlockAction.getCommunicationTemplate(value);
                  if (!(result !== null && result !== void 0 && result.isSuccess) || !result.data) {
                    var _result$errorMessage15;
                    console.error((_result$errorMessage15 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage15 !== void 0 ? _result$errorMessage15 : "unable to select communication template");
                  }
                  communicationTemplateDetail.value = result === null || result === void 0 ? void 0 : result.data;
                }
              } finally {
                isFetchingCommunicationTemplate.value = false;
              }
            });
            return _onCommunicationTemplateGuidUpdated.apply(this, arguments);
          }
          function populateFromCommunicationTemplateDetail(bag) {
            var _bag$fromEmail2, _bag$fromName2, _bag$subject2, _bag$replyToEmail2, _bag$ccEmails2, _bag$bccEmails2, _bag$message2, _bag$smsMessage2, _bag$pushMessage2, _bag$pushOpenAction2, _bag$pushOpenMessage2, _bag$pushOpenMessageJ2, _bag$pushTitle2;
            fromEmail.value = (_bag$fromEmail2 = bag.fromEmail) !== null && _bag$fromEmail2 !== void 0 ? _bag$fromEmail2 : "";
            fromName.value = (_bag$fromName2 = bag.fromName) !== null && _bag$fromName2 !== void 0 ? _bag$fromName2 : "";
            emailAttachmentBinaryFiles.value = bag.emailAttachmentBinaryFiles;
            subject.value = (_bag$subject2 = bag.subject) !== null && _bag$subject2 !== void 0 ? _bag$subject2 : "";
            if ((_bag$replyToEmail2 = bag.replyToEmail) !== null && _bag$replyToEmail2 !== void 0 && _bag$replyToEmail2.trim()) {
              replyToEmail.value = bag.replyToEmail;
            }
            if ((_bag$ccEmails2 = bag.ccEmails) !== null && _bag$ccEmails2 !== void 0 && _bag$ccEmails2.trim()) {
              ccEmails.value = bag.ccEmails;
            }
            if ((_bag$bccEmails2 = bag.bccEmails) !== null && _bag$bccEmails2 !== void 0 && _bag$bccEmails2.trim()) {
              bccEmails.value = bag.bccEmails;
            }
            message.value = (_bag$message2 = bag.message) !== null && _bag$message2 !== void 0 ? _bag$message2 : "";
            smsAttachmentBinaryFiles.value = bag.smsAttachmentBinaryFiles;
            if (bag.smsFromSystemPhoneNumberGuid) {
              smsFromSystemPhoneNumberGuid.value = bag.smsFromSystemPhoneNumberGuid;
            }
            if ((_bag$smsMessage2 = bag.smsMessage) !== null && _bag$smsMessage2 !== void 0 && _bag$smsMessage2.trim()) {
              smsMessage.value = bag.smsMessage;
            }
            pushData.value = bag.pushData;
            pushImageBinaryFileGuid.value = bag.pushImageBinaryFileGuid;
            pushMessage.value = (_bag$pushMessage2 = bag.pushMessage) !== null && _bag$pushMessage2 !== void 0 ? _bag$pushMessage2 : "";
            pushOpenAction.value = (_bag$pushOpenAction2 = bag.pushOpenAction) !== null && _bag$pushOpenAction2 !== void 0 ? _bag$pushOpenAction2 : PushOpenAction.NoAction;
            pushOpenMessage.value = (_bag$pushOpenMessage2 = bag.pushOpenMessage) !== null && _bag$pushOpenMessage2 !== void 0 ? _bag$pushOpenMessage2 : "";
            pushOpenMessageJson.value = (_bag$pushOpenMessageJ2 = bag.pushOpenMessageJson) !== null && _bag$pushOpenMessageJ2 !== void 0 ? _bag$pushOpenMessageJ2 : undefined;
            pushTitle.value = (_bag$pushTitle2 = bag.pushTitle) !== null && _bag$pushTitle2 !== void 0 ? _bag$pushTitle2 : "";
          }
          function onChooseTemplateNextClicked() {
            return _onChooseTemplateNextClicked.apply(this, arguments);
          }
          function _onChooseTemplateNextClicked() {
            _onChooseTemplateNextClicked = _asyncToGenerator(function* () {
              try {
                if (communicationTemplateDetail.value) {
                  if (wasCommunicationTemplateChanged.value) {
                    populateFromCommunicationTemplateDetail(communicationTemplateDetail.value);
                  }
                  communicationTemplateGuid.value = communicationTemplateDetail.value.guid;
                  yield personPreferencesHelper.setCommuncationTemplateGuid(communicationTemplateDetail.value.guid);
                  onNextStepClicked();
                } else {
                  console.warn("A communication template was not selected or hasn't finished loading.");
                }
              } finally {
                wasCommunicationTemplateChanged.value = false;
              }
            });
            return _onChooseTemplateNextClicked.apply(this, arguments);
          }
          function onSendCommunication(_x24) {
            return _onSendCommunication.apply(this, arguments);
          }
          function _onSendCommunication() {
            _onSendCommunication = _asyncToGenerator(function* (callbacks) {
              var result = yield invokeBlockAction.send(getCommunicationBag());
              if (result !== null && result !== void 0 && result.isSuccess) {
                var _result$data$hasDetai, _result$data7;
                callbacks.onSuccess();
                hasDetailBlockOnCurrentPage.value = (_result$data$hasDetai = (_result$data7 = result.data) === null || _result$data7 === void 0 ? void 0 : _result$data7.hasDetailBlockOnCurrentPage) !== null && _result$data$hasDetai !== void 0 ? _result$data$hasDetai : false;
              } else {
                var _result$errorMessage16;
                console.error((_result$errorMessage16 = result === null || result === void 0 ? void 0 : result.errorMessage) !== null && _result$errorMessage16 !== void 0 ? _result$errorMessage16 : "The test communication failed to send.");
                callbacks.onError();
              }
            });
            return _onSendCommunication.apply(this, arguments);
          }
          function onSendStarted(_bag) {
            sendingProgressMessage.value = "Loading...";
            sendingCompletionPercentage.value = 0;
            moveToNextStep();
          }
          function onSendProgressUpdated(bag) {
            sendingProgressMessage.value = bag.message || "Loading...";
            sendingCompletionPercentage.value = bag.completionPercentage;
          }
          function onSendCompleted(bag) {
            var _bag$data, _bag$message3, _bag$errors, _bag$warnings;
            sendingCompletionPercentage.value = 100;
            if ((_bag$data = bag.data) !== null && _bag$data !== void 0 && _bag$data["communicationId"]) {
              communicationId.value = bag.data["communicationId"];
            }
            finalMessage.value = (_bag$message3 = bag.message) !== null && _bag$message3 !== void 0 ? _bag$message3 : "Communication has been queued for sending.";
            if ((_bag$errors = bag.errors) !== null && _bag$errors !== void 0 && _bag$errors.length) {
              finalMessageAlertType.value = AlertType.Danger;
            } else if ((_bag$warnings = bag.warnings) !== null && _bag$warnings !== void 0 && _bag$warnings.length) {
              finalMessageAlertType.value = AlertType.Warning;
            } else {
              finalMessageAlertType.value = AlertType.Success;
            }
            if (bag.isFinished) {
              moveToNextStep();
            }
          }
          function onSaveEmailAnalytics(_x25, _x26) {
            return _onSaveEmailAnalytics.apply(this, arguments);
          }
          function _onSaveEmailAnalytics() {
            _onSaveEmailAnalytics = _asyncToGenerator(function* (daysFromNow, callbacks) {
              var result = yield invokeBlockAction.saveMetricsReminder({
                daysUntilReminder: daysFromNow,
                communicationGuid: communicationGuid.value
              });
              if (result !== null && result !== void 0 && result.isSuccess) {
                callbacks.onSuccess();
              } else {
                callbacks.onError(result === null || result === void 0 ? void 0 : result.errorMessage);
              }
            });
            return _onSaveEmailAnalytics.apply(this, arguments);
          }
          function onCancelEmailAnalytics(_x27) {
            return _onCancelEmailAnalytics.apply(this, arguments);
          }
          function _onCancelEmailAnalytics() {
            _onCancelEmailAnalytics = _asyncToGenerator(function* (callbacks) {
              var result = yield invokeBlockAction.cancelMetricsReminder(communicationGuid.value);
              if (result !== null && result !== void 0 && result.isSuccess) {
                callbacks.onSuccess();
              } else {
                callbacks.onError(result === null || result === void 0 ? void 0 : result.errorMessage);
              }
            });
            return _onCancelEmailAnalytics.apply(this, arguments);
          }
          function onViewCommunication() {
            var _communicationId$valu;
            var url = new URL(window.location.href);
            url.searchParams.set("CommunicationId", ((_communicationId$valu = communicationId.value) !== null && _communicationId$valu !== void 0 ? _communicationId$valu : 0).toString());
            window.location.href = url.toString();
          }
          function onNewCommunication() {
            var url = new URL(window.location.href);
            url.search = "";
            window.location.href = url.toString();
          }
          watch(communicationGuid, (newValue, oldValue) => {
            if (!areEqual(newValue, oldValue)) {
              startRealTime();
            }
          });
          watch(communicationId, (newValue, _oldValue) => {
            if (newValue) {
              replaceQueryParam("CommunicationId", newValue.toString());
            }
          });
          watch(isBulkCommunicationForced, newValue => {
            if (newValue) {
              isBulkCommunication.value = true;
            }
          }, {
            immediate: true
          });
          var reloadBlock = useReloadBlock();
          onConfigurationValuesChanged(reloadBlock);
          startRealTime();
          onMounted(_asyncToGenerator(function* () {
            if (!communicationId.value || !communicationTemplateGuid.value) {
              if (communicationTemplateDetail.value) {
                populateFromCommunicationTemplateDetail(communicationTemplateDetail.value);
              } else if (communicationTemplateGuid.value) {
                var result = yield invokeBlockAction.getCommunicationTemplate(communicationTemplateGuid.value);
                if (result !== null && result !== void 0 && result.isSuccess && result.data) {
                  communicationTemplateDetail.value = result.data;
                  populateFromCommunicationTemplateDetail(result.data);
                }
              }
            }
          }));
          onUnmounted(() => {
            messagePreviewCache.clear();
          });
          return (_ctx, _cache) => {
            return !unref(config).isHidden ? (openBlock(), createElementBlock("div", {
              key: 0,
              ref_key: "communicationEntryWizardElement",
              ref: communicationEntryWizardElement,
              class: "communication-entry-wizard"
            }, [createVNode(unref(script$i), null, {
              default: withCtx(() => {
                var _unref$communicationL, _unref$communicationT, _unref$navigationUrls, _unref$mergeFields, _unref$mergeFields2, _unref$smsFromNumbers, _unref$pushApplicatio, _unref$mergeFields3, _communicationTopicVa;
                return [step.value === 'Configure Communication' ? (openBlock(), createBlock(unref(script$1), {
                  key: 0,
                  communicationListGroupGuid: communicationListGroupGuid.value,
                  "onUpdate:communicationListGroupGuid": [_cache[0] || (_cache[0] = $event => communicationListGroupGuid.value = $event), onCommunicationListGroupGuidUpdated],
                  communicationName: communicationName.value,
                  "onUpdate:communicationName": _cache[1] || (_cache[1] = $event => communicationName.value = $event),
                  communicationTopicValue: communicationTopicValue.value,
                  "onUpdate:communicationTopicValue": _cache[2] || (_cache[2] = $event => communicationTopicValue.value = $event),
                  communicationType: communicationType.value,
                  "onUpdate:communicationType": _cache[3] || (_cache[3] = $event => communicationType.value = $event),
                  excludeDuplicateRecipientAddress: excludeDuplicateRecipientAddress.value,
                  "onUpdate:excludeDuplicateRecipientAddress": _cache[4] || (_cache[4] = $event => excludeDuplicateRecipientAddress.value = $event),
                  futureSendDateTime: futureSendDateTime.value,
                  "onUpdate:futureSendDateTime": _cache[5] || (_cache[5] = $event => futureSendDateTime.value = $event),
                  individualRecipientPersonAliasGuids: individualRecipientPersonAliasGuids.value,
                  "onUpdate:individualRecipientPersonAliasGuids": _cache[6] || (_cache[6] = $event => individualRecipientPersonAliasGuids.value = $event),
                  isBulkCommunication: isBulkCommunication.value,
                  "onUpdate:isBulkCommunication": _cache[7] || (_cache[7] = $event => isBulkCommunication.value = $event),
                  personalizationSegments: personalizationSegments.value,
                  "onUpdate:personalizationSegments": [_cache[8] || (_cache[8] = $event => personalizationSegments.value = $event), debouncedUpdateRecipients],
                  recipients: recipients.value,
                  "onUpdate:recipients": _cache[9] || (_cache[9] = $event => recipients.value = $event),
                  segmentCriteria: segmentCriteria.value,
                  "onUpdate:segmentCriteria": [_cache[10] || (_cache[10] = $event => segmentCriteria.value = $event), debouncedUpdateRecipients],
                  allowedMediums: allowedMediums.value,
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  communicationId: communicationId.value,
                  communicationListGroups: (_unref$communicationL = unref(config).communicationListGroups) !== null && _unref$communicationL !== void 0 ? _unref$communicationL : [],
                  communicationTopicValues: (_unref$communicationT = unref(config).communicationTopicValues) !== null && _unref$communicationT !== void 0 ? _unref$communicationT : [],
                  emailRecipientCount: emailRecipients.value.length,
                  isAddingIndividualsToRecipientListsDisabled: unref(config).isAddingIndividualsToRecipientListsDisabled,
                  isBulkCommunicationForced: isBulkCommunicationForced.value,
                  isDeletingIndividualsToRecipientListsDisabled: !!communicationListGroupGuid.value,
                  isDuplicatePreventionOptionShown: unref(config).isDuplicatePreventionOptionShown,
                  isFetchingRecipients: isFetchingRecipients.value,
                  isIncompatibleCommunicationTemplateNotificationShown: isIncompatibleCommunicationTemplateNotificationShown.value,
                  isUseSimpleEditorButtonShown: isUseSimpleEditorButtonShown.value,
                  nextStepTitle: nextStep.value,
                  personalizationSegmentItems: personalizationSegmentItems.value,
                  personalPreferenceRecipientCount: personalPreferenceRecipients.value.length,
                  pushNotificationRecipientCount: pushNotificationRecipients.value.length,
                  recipientCount: selectedMediumRecipients.value.length,
                  recipientsLabel: selectedMediumRecipientsLabel.value,
                  smsRecipientCount: smsRecipients.value.length,
                  simpleCommunicationPageUrl: (_unref$navigationUrls = unref(config).navigationUrls) === null || _unref$navigationUrls === void 0 ? void 0 : _unref$navigationUrls['SimpleCommunicationPage'],
                  title: step.value,
                  onNextStep: onNextStepClicked,
                  onRecipientListModified: _cache[11] || (_cache[11] = $event => wasRecipientListModifiedOnce.value = true)
                }, null, 8, ["communicationListGroupGuid", "communicationName", "communicationTopicValue", "communicationType", "excludeDuplicateRecipientAddress", "futureSendDateTime", "individualRecipientPersonAliasGuids", "isBulkCommunication", "personalizationSegments", "recipients", "segmentCriteria", "allowedMediums", "areNavigationShortcutsDisabled", "communicationId", "communicationListGroups", "communicationTopicValues", "emailRecipientCount", "isAddingIndividualsToRecipientListsDisabled", "isBulkCommunicationForced", "isDeletingIndividualsToRecipientListsDisabled", "isDuplicatePreventionOptionShown", "isFetchingRecipients", "isIncompatibleCommunicationTemplateNotificationShown", "isUseSimpleEditorButtonShown", "nextStepTitle", "personalizationSegmentItems", "personalPreferenceRecipientCount", "pushNotificationRecipientCount", "recipientCount", "recipientsLabel", "smsRecipientCount", "simpleCommunicationPageUrl", "title"])) : step.value === 'Choose Template' ? (openBlock(), createBlock(unref(script$g), {
                  key: 1,
                  communicationTemplateGuid: communicationTemplateGuid.value,
                  "onUpdate:communicationTemplateGuid": [_cache[12] || (_cache[12] = $event => communicationTemplateGuid.value = $event), onCommunicationTemplateGuidUpdated],
                  allowedMediums: allowedMediums.value,
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  communicationTemplateDetail: communicationTemplateDetail.value,
                  communicationTemplates: communicationTemplates.value,
                  communicationType: communicationType.value,
                  isFetchingCommunicationTemplate: isFetchingCommunicationTemplate.value,
                  nextStepTitle: nextStep.value,
                  title: step.value,
                  onNextStep: onChooseTemplateNextClicked,
                  onPreviousStep: onPreviousStepClicked
                }, null, 8, ["communicationTemplateGuid", "allowedMediums", "areNavigationShortcutsDisabled", "communicationTemplateDetail", "communicationTemplates", "communicationType", "isFetchingCommunicationTemplate", "nextStepTitle", "title"])) : step.value === 'Email Settings' ? (openBlock(), createBlock(unref(script$9), {
                  key: 2,
                  bccEmails: bccEmails.value,
                  "onUpdate:bccEmails": _cache[13] || (_cache[13] = $event => bccEmails.value = $event),
                  ccEmails: ccEmails.value,
                  "onUpdate:ccEmails": _cache[14] || (_cache[14] = $event => ccEmails.value = $event),
                  emailAttachmentBinaryFiles: emailAttachmentBinaryFiles.value,
                  "onUpdate:emailAttachmentBinaryFiles": _cache[15] || (_cache[15] = $event => emailAttachmentBinaryFiles.value = $event),
                  fromEmail: fromEmail.value,
                  "onUpdate:fromEmail": _cache[16] || (_cache[16] = $event => fromEmail.value = $event),
                  fromName: fromName.value,
                  "onUpdate:fromName": _cache[17] || (_cache[17] = $event => fromName.value = $event),
                  message: message.value,
                  "onUpdate:message": _cache[18] || (_cache[18] = $event => message.value = $event),
                  replyToEmail: replyToEmail.value,
                  "onUpdate:replyToEmail": _cache[19] || (_cache[19] = $event => replyToEmail.value = $event),
                  subject: subject.value,
                  "onUpdate:subject": _cache[20] || (_cache[20] = $event => subject.value = $event),
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  attachmentBinaryFileTypeGuid: unref(config).attachmentBinaryFileTypeGuid,
                  nextStepTitle: nextStep.value,
                  title: step.value,
                  onNextStep: onNextStepClicked,
                  onPreviousStep: onPreviousStepClicked
                }, null, 8, ["bccEmails", "ccEmails", "emailAttachmentBinaryFiles", "fromEmail", "fromName", "message", "replyToEmail", "subject", "areNavigationShortcutsDisabled", "attachmentBinaryFileTypeGuid", "nextStepTitle", "title"])) : step.value === 'Email Builder' ? (openBlock(), createBlock(unref(script$a), {
                  key: 3,
                  communicationTemplateGuid: communicationTemplateGuid.value,
                  "onUpdate:communicationTemplateGuid": _cache[21] || (_cache[21] = $event => communicationTemplateGuid.value = $event),
                  message: message.value,
                  "onUpdate:message": _cache[22] || (_cache[22] = $event => message.value = $event),
                  previewAsType: previewAsType.value,
                  "onUpdate:previewAsType": _cache[23] || (_cache[23] = $event => previewAsType.value = $event),
                  previewAsPersonAlias: previewAsPersonAlias.value,
                  "onUpdate:previewAsPersonAlias": _cache[24] || (_cache[24] = $event => previewAsPersonAlias.value = $event),
                  previewAsPersonalizationSegment: previewAsPersonalizationSegment.value,
                  "onUpdate:previewAsPersonalizationSegment": _cache[25] || (_cache[25] = $event => previewAsPersonalizationSegment.value = $event),
                  testEmailAddress: testEmailAddress.value,
                  "onUpdate:testEmailAddress": _cache[26] || (_cache[26] = $event => testEmailAddress.value = $event),
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  communicationTemplates: communicationTemplateListItems.value,
                  imageComponentBinaryFileTypeGuid: unref(config).imageComponentBinaryFileTypeGuid,
                  isFetchingRecipients: isFetchingRecipients.value,
                  mergeFields: (_unref$mergeFields = unref(config).mergeFields) !== null && _unref$mergeFields !== void 0 ? _unref$mergeFields : undefined,
                  nextStepTitle: nextStep.value,
                  personalizationSegments: personalizationSegments.value,
                  previewHtmlProcessor: previewEmailProcessor,
                  recipientPersonIds: emailRecipients.value.map(e => e.personId),
                  recipientsLabel: emailRecipientsLabel.value,
                  shortLinkCheckToken: onShortLinkCheckToken,
                  shortLinkGetPageId: onShortLinkGetPageId,
                  shortLinkSites: unref(config).shortLinkSites,
                  shortLinkTokenMinLength: unref(config).minimumShortLinkTokenLength,
                  title: step.value,
                  videoProviderNames: unref(config).videoProviderNames,
                  onNextStep: onNextStepClicked,
                  onPreviousStep: onPreviousStepClicked,
                  onSaveCommunication: onSaveCommunication,
                  onSendTestCommunication: onSendTestEmail,
                  onSaveAsTemplate: onSaveAsTemplate
                }, null, 8, ["communicationTemplateGuid", "message", "previewAsType", "previewAsPersonAlias", "previewAsPersonalizationSegment", "testEmailAddress", "areNavigationShortcutsDisabled", "communicationTemplates", "imageComponentBinaryFileTypeGuid", "isFetchingRecipients", "mergeFields", "nextStepTitle", "personalizationSegments", "recipientPersonIds", "recipientsLabel", "shortLinkSites", "shortLinkTokenMinLength", "title", "videoProviderNames"])) : step.value === 'SMS Editor' ? (openBlock(), createBlock(unref(script$3), {
                  key: 4,
                  previewAsPersonAlias: previewAsPersonAlias.value,
                  "onUpdate:previewAsPersonAlias": _cache[27] || (_cache[27] = $event => previewAsPersonAlias.value = $event),
                  previewAsPersonalizationSegment: previewAsPersonalizationSegment.value,
                  "onUpdate:previewAsPersonalizationSegment": _cache[28] || (_cache[28] = $event => previewAsPersonalizationSegment.value = $event),
                  previewAsType: previewAsType.value,
                  "onUpdate:previewAsType": _cache[29] || (_cache[29] = $event => previewAsType.value = $event),
                  message: smsMessage.value,
                  "onUpdate:message": _cache[30] || (_cache[30] = $event => smsMessage.value = $event),
                  smsAttachmentBinaryFiles: smsAttachmentBinaryFiles.value,
                  "onUpdate:smsAttachmentBinaryFiles": _cache[31] || (_cache[31] = $event => smsAttachmentBinaryFiles.value = $event),
                  smsFromSystemPhoneNumberGuid: smsFromSystemPhoneNumberGuid.value,
                  "onUpdate:smsFromSystemPhoneNumberGuid": _cache[32] || (_cache[32] = $event => smsFromSystemPhoneNumberGuid.value = $event),
                  testSmsPhoneNumber: testSmsPhoneNumber.value,
                  "onUpdate:testSmsPhoneNumber": _cache[33] || (_cache[33] = $event => testSmsPhoneNumber.value = $event),
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  attachmentBinaryFileTypeGuid: unref(config).attachmentBinaryFileTypeGuid,
                  maxImageWidth: unref(config).maxSmsImageWidth,
                  mergeFields: (_unref$mergeFields2 = unref(config).mergeFields) !== null && _unref$mergeFields2 !== void 0 ? _unref$mergeFields2 : undefined,
                  nextStepTitle: nextStep.value,
                  personalizationSegments: personalizationSegments.value,
                  previewProcessor: previewSmsProcessor,
                  recipientsLabel: smsRecipientsLabel.value,
                  shortLinkCheckToken: onShortLinkCheckToken,
                  shortLinkGetPageId: onShortLinkGetPageId,
                  shortLinkSites: unref(config).shortLinkSites,
                  shortLinkTokenMinLength: unref(config).minimumShortLinkTokenLength,
                  smsAcceptedMimeTypes: unref(config).smsAcceptedMimeTypes,
                  smsAttachmentLinks: smsAttachmentLinks.value,
                  smsFromNumberName: smsFromNumberName.value,
                  smsFromNumbers: (_unref$smsFromNumbers = unref(config).smsFromNumbers) !== null && _unref$smsFromNumbers !== void 0 ? _unref$smsFromNumbers : [],
                  smsMediaSizeLimitBytes: unref(config).smsMediaSizeLimitBytes,
                  smsSupportedMimeTypes: unref(config).smsSupportedMimeTypes,
                  title: step.value,
                  onNextStep: onNextStepClicked,
                  onPreviousStep: onPreviousStepClicked,
                  onSaveCommunication: onSaveCommunication,
                  onSendTestCommunication: onSendTestSms
                }, null, 8, ["previewAsPersonAlias", "previewAsPersonalizationSegment", "previewAsType", "message", "smsAttachmentBinaryFiles", "smsFromSystemPhoneNumberGuid", "testSmsPhoneNumber", "areNavigationShortcutsDisabled", "attachmentBinaryFileTypeGuid", "maxImageWidth", "mergeFields", "nextStepTitle", "personalizationSegments", "recipientsLabel", "shortLinkSites", "shortLinkTokenMinLength", "smsAcceptedMimeTypes", "smsAttachmentLinks", "smsFromNumberName", "smsFromNumbers", "smsMediaSizeLimitBytes", "smsSupportedMimeTypes", "title"])) : step.value === 'Push Notification Editor' ? (openBlock(), createBlock(unref(script$8), {
                  key: 5,
                  previewAsPersonAlias: previewAsPersonAlias.value,
                  "onUpdate:previewAsPersonAlias": _cache[34] || (_cache[34] = $event => previewAsPersonAlias.value = $event),
                  previewAsPersonalizationSegment: previewAsPersonalizationSegment.value,
                  "onUpdate:previewAsPersonalizationSegment": _cache[35] || (_cache[35] = $event => previewAsPersonalizationSegment.value = $event),
                  previewAsType: previewAsType.value,
                  "onUpdate:previewAsType": _cache[36] || (_cache[36] = $event => previewAsType.value = $event),
                  pushData: pushData.value,
                  "onUpdate:pushData": _cache[37] || (_cache[37] = $event => pushData.value = $event),
                  pushMessage: pushMessage.value,
                  "onUpdate:pushMessage": _cache[38] || (_cache[38] = $event => pushMessage.value = $event),
                  pushOpenAction: pushOpenAction.value,
                  "onUpdate:pushOpenAction": _cache[39] || (_cache[39] = $event => pushOpenAction.value = $event),
                  pushOpenMessageJson: pushOpenMessageJson.value,
                  "onUpdate:pushOpenMessageJson": _cache[40] || (_cache[40] = $event => pushOpenMessageJson.value = $event),
                  pushTitle: pushTitle.value,
                  "onUpdate:pushTitle": _cache[41] || (_cache[41] = $event => pushTitle.value = $event),
                  applications: (_unref$pushApplicatio = unref(config).pushApplications) !== null && _unref$pushApplicatio !== void 0 ? _unref$pushApplicatio : [],
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  isUsingRockMobilePushTransport: unref(config).isUsingRockMobilePushTransport,
                  mergeFields: (_unref$mergeFields3 = unref(config).mergeFields) !== null && _unref$mergeFields3 !== void 0 ? _unref$mergeFields3 : undefined,
                  nextStepTitle: nextStep.value,
                  personalizationSegments: personalizationSegments.value,
                  previewProcessor: previewPushProcessor,
                  recipientsLabel: pushNotificationRecipientsLabel.value,
                  title: step.value,
                  onNextStep: onNextStepClicked,
                  onPreviousStep: onPreviousStepClicked,
                  onSaveCommunication: onSaveCommunication
                }, null, 8, ["previewAsPersonAlias", "previewAsPersonalizationSegment", "previewAsType", "pushData", "pushMessage", "pushOpenAction", "pushOpenMessageJson", "pushTitle", "applications", "areNavigationShortcutsDisabled", "isUsingRockMobilePushTransport", "mergeFields", "nextStepTitle", "personalizationSegments", "recipientsLabel", "title"])) : step.value === 'Review & Confirm' ? (openBlock(), createBlock(unref(script$c), {
                  key: 6,
                  allowedMediums: allowedMediums.value,
                  areNavigationShortcutsDisabled: unref(config).areNavigationShortcutsDisabled,
                  bccEmails: bccEmails.value,
                  ccEmails: ccEmails.value,
                  communicationListGroupName: communicationListGroupName.value,
                  communicationName: communicationName.value,
                  communicationTopicValueName: (_communicationTopicVa = communicationTopicValue.value) === null || _communicationTopicVa === void 0 ? void 0 : _communicationTopicVa.text,
                  communicationType: communicationType.value,
                  emailAttachmentNames: emailAttachmentNames.value,
                  emailTo: emailTo.value,
                  fromAddress: fromEmail.value,
                  fromName: fromName.value,
                  futureSendDateTime: futureSendDateTime.value,
                  isBulkCommunication: isBulkCommunication.value,
                  message: message.value,
                  previewAsPersonAlias: previewAsPersonAlias.value,
                  previewAsPersonalizationSegment: previewAsPersonalizationSegment.value,
                  previewAsType: previewAsType.value,
                  previewEmailProcessor: previewEmailProcessor,
                  previewPushProcessor: previewPushProcessor,
                  previewSmsProcessor: previewSmsProcessor,
                  pushMessage: pushMessage.value,
                  pushTitle: pushTitle.value,
                  recipientsLabel: selectedMediumRecipientsLabel.value,
                  replyToEmail: replyToEmail.value,
                  segmentNames: personalizationSegmentNames.value,
                  smsAttachmentLinks: smsAttachmentLinks.value,
                  smsAttachmentNames: smsAttachmentNames.value,
                  smsFromNumberName: smsFromNumberName.value,
                  smsMessage: smsMessage.value,
                  subject: subject.value,
                  title: step.value,
                  onSaveCommunication: onReviewAndConfirmSaveCommunication,
                  onSendCommunication: onSendCommunication,
                  onPreviousStep: onPreviousStepClicked
                }, null, 8, ["allowedMediums", "areNavigationShortcutsDisabled", "bccEmails", "ccEmails", "communicationListGroupName", "communicationName", "communicationTopicValueName", "communicationType", "emailAttachmentNames", "emailTo", "fromAddress", "fromName", "futureSendDateTime", "isBulkCommunication", "message", "previewAsPersonAlias", "previewAsPersonalizationSegment", "previewAsType", "pushMessage", "pushTitle", "recipientsLabel", "replyToEmail", "segmentNames", "smsAttachmentLinks", "smsAttachmentNames", "smsFromNumberName", "smsMessage", "subject", "title"])) : step.value === 'Sending Communication' ? (openBlock(), createBlock(unref(script$5), {
                  key: 7,
                  completionPercentage: sendingCompletionPercentage.value,
                  sendingProgressMessage: sendingProgressMessage.value
                }, null, 8, ["completionPercentage", "sendingProgressMessage"])) : step.value === 'Communication Queued' ? (openBlock(), createBlock(unref(script$4), {
                  key: 8,
                  allowedMediums: allowedMediums.value,
                  communicationType: communicationType.value,
                  finalMessage: finalMessage.value,
                  finalMessageAlertType: finalMessageAlertType.value,
                  hasDetailBlockOnCurrentPage: hasDetailBlockOnCurrentPage.value,
                  onSaveEmailAnalytics: onSaveEmailAnalytics,
                  onCancelEmailAnalytics: onCancelEmailAnalytics,
                  onViewCommunication: onViewCommunication,
                  onNewCommunication: onNewCommunication
                }, null, 8, ["allowedMediums", "communicationType", "finalMessage", "finalMessageAlertType", "hasDetailBlockOnCurrentPage"])) : step.value === 'Communication Saved' ? (openBlock(), createBlock(unref(script$7), {
                  key: 9,
                  finalMessage: finalMessage.value,
                  finalMessageAlertType: finalMessageAlertType.value,
                  hasDetailBlockOnCurrentPage: hasDetailBlockOnCurrentPage.value,
                  onViewCommunication: onViewCommunication
                }, null, 8, ["finalMessage", "finalMessageAlertType", "hasDetailBlockOnCurrentPage"])) : createCommentVNode("v-if", true), saveAsCommunicationTemplateDetail.value ? (openBlock(), createBlock(unref(script$6), {
                  key: 10,
                  modelValue: isSaveCommunicationTemplateModalShown.value,
                  "onUpdate:modelValue": _cache[42] || (_cache[42] = $event => isSaveCommunicationTemplateModalShown.value = $event),
                  api: saveAsCommunicationTemplateApi.value,
                  communicationTemplate: saveAsCommunicationTemplateDetail.value,
                  bodyWidth: saveAsCommunicationTemplateBodyWidth.value,
                  onSave: onOverwriteExistingCommunicationTemplate,
                  onSaveAs: onSaveAsNewCommunicationTemplate
                }, null, 8, ["modelValue", "api", "communicationTemplate", "bodyWidth"])) : createCommentVNode("v-if", true)];
              }),
              _: 1
            })], 512)) : createCommentVNode("v-if", true);
          };
        }
      }));

      script.__file = "src/Communication/communicationEntryWizard.obs";

    })
  };
}));
//# sourceMappingURL=communicationEntryWizard.obs.js.map
